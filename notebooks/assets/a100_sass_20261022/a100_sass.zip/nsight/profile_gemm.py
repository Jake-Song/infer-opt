import json, sys, torch
m, k, n = map(int, sys.argv[1:4])
mode = sys.argv[4]
assert torch.cuda.is_available()
assert 'A100' in torch.cuda.get_device_name(0), torch.cuda.get_device_name(0)
torch.manual_seed(42)
dtype = {'fp32_strict': torch.float32, 'tf32_allowed': torch.float32,
         'fp16': torch.float16, 'bf16': torch.bfloat16}[mode]
torch.set_float32_matmul_precision('high' if mode == 'tf32_allowed' else 'highest')
torch.backends.cuda.matmul.allow_tf32 = mode == 'tf32_allowed'
torch.backends.cuda.matmul.allow_fp16_reduced_precision_reduction = False
torch.backends.cuda.matmul.allow_bf16_reduced_precision_reduction = False
a = torch.randn(m, k, device='cuda', dtype=dtype)
b = torch.randn(k, n, device='cuda', dtype=dtype)
c = torch.empty(m, n, device='cuda', dtype=dtype)
with torch.inference_mode():
    for _ in range(20):
        torch.mm(a, b, out=c)
    torch.cuda.synchronize()
    print(json.dumps({'gpu': torch.cuda.get_device_name(0), 'shape': [m,k,n],
                      'mode': mode, 'torch': torch.__version__}), flush=True)
    torch.cuda.cudart().cudaProfilerStart()
    torch.mm(a, b, out=c)
    torch.cuda.synchronize()
    torch.cuda.cudart().cudaProfilerStop()
