from __future__ import annotations

import argparse
import json
from dataclasses import fields
from pathlib import Path

from .config import ModelConfig, RunConfig
from .runner import benchmark, check_cached_decode
from .strategies import available_attention_strategies


def _add_config_arguments(parser: argparse.ArgumentParser) -> None:
    group = parser.add_argument_group("model")
    for field in fields(ModelConfig):
        group.add_argument(f"--{field.name.replace('_', '-')}", type=type(field.default), default=field.default)
    group = parser.add_argument_group("run")
    for field in fields(RunConfig):
        kwargs: dict[str, object] = {"default": field.default}
        if field.name == "strategy":
            kwargs["choices"] = available_attention_strategies()
        elif field.name == "cache":
            kwargs["choices"] = ("contiguous", "paged")
        elif isinstance(field.default, int):
            kwargs["type"] = int
        else:
            kwargs["type"] = str
        group.add_argument(f"--{field.name.replace('_', '-')}", **kwargs)


def _configs(args: argparse.Namespace) -> tuple[ModelConfig, RunConfig]:
    model = ModelConfig(**{field.name: getattr(args, field.name) for field in fields(ModelConfig)})
    run = RunConfig(**{field.name: getattr(args, field.name) for field in fields(RunConfig)})
    if run.prompt_len + run.decode_len > model.max_seq_len:
        raise ValueError("prompt_len + decode_len must not exceed max_seq_len")
    return model, run


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="Decoder-only inference research template")
    subparsers = parser.add_subparsers(dest="command", required=True)
    for command in ("check", "benchmark"):
        child = subparsers.add_parser(command)
        _add_config_arguments(child)
        child.add_argument("--json", action="store_true", help="emit only the JSON result record")
    baseline = subparsers.add_parser("baseline", help="correctness-gated B=1 0.5B prefill/decode sweep")
    baseline.add_argument("--output", type=Path, required=True)
    baseline.add_argument("--prompt-lengths", type=int, nargs="+", default=[128, 512, 2048, 8192])
    baseline.add_argument("--decode-len", type=int, default=128)
    baseline.add_argument("--warmup", type=int, default=3)
    baseline.add_argument("--iterations", type=int, default=10)
    baseline.add_argument("--seed", type=int, default=0)
    baseline.add_argument("--device", default="cuda")
    baseline.add_argument("--dtype", choices=("float32", "float16", "bfloat16"), default="bfloat16")
    baseline.add_argument("--expected-gpu", help="fail if the actual GPU name does not contain this value")
    baseline.add_argument("--budget-minutes", type=float, default=120)
    args = parser.parse_args(argv)
    if args.command == "baseline":
        from .baseline import run_baseline

        options = vars(args).copy()
        options.pop("command")
        options["prompt_lengths"] = tuple(options["prompt_lengths"])
        result = run_baseline(**options)
        print(f"baseline: {result['status']}; results: {args.output}")
        if "error" in result:
            print(result["error"])
        return 0 if result["status"] == "passed" else 1
    model, run = _configs(args)
    result = check_cached_decode(model, run) if args.command == "check" else benchmark(model, run)
    payload = json.dumps(result, sort_keys=True)
    if args.json:
        print(payload)
    elif args.command == "check":
        print(f"cached decode: {'PASS' if result['passed'] else 'FAIL'}; max_abs_error={result['max_abs_error']:.3e}")
        print(f"RESULT_JSON={payload}")
    else:
        prefill, decode = result["prefill"], result["decode"]
        print(f"prefill: {prefill['latency_ms']:.3f} ms/sequence, {prefill['tokens_per_second']:.1f} tokens/s")
        print(f"decode: {decode['latency_ms_per_token']:.3f} ms/token, {decode['tokens_per_second']:.1f} tokens/s")
        print(f"RESULT_JSON={payload}")
    return 0 if args.command != "check" or result["passed"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
