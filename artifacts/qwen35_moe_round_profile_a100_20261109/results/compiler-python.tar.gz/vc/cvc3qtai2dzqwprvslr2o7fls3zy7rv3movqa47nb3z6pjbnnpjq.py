# AOT ID: ['6_inference']
from ctypes import c_void_p, c_long, c_int
import torch
import math
import random
import os
import tempfile
from math import inf, nan
from cmath import nanj
from torch._inductor.hooks import run_intermediate_hooks
from torch._inductor.utils import maybe_profile
from torch._inductor.codegen.memory_planning import _align as align
from torch import device, empty_strided
from torch._inductor.async_compile import AsyncCompile
from torch._inductor.select_algorithm import extern_kernels
import triton
import triton.language as tl
from torch._inductor.runtime.triton_heuristics import start_graph, end_graph
from torch._C import _cuda_getCurrentRawStream as get_raw_stream

aten = torch.ops.aten
inductor_ops = torch.ops.inductor
_quantized = torch.ops._quantized
assert_size_stride = torch._C._dynamo.guards.assert_size_stride
assert_alignment = torch._C._dynamo.guards.assert_alignment
empty_strided_cpu = torch._C._dynamo.guards._empty_strided_cpu
empty_strided_cpu_pinned = torch._C._dynamo.guards._empty_strided_cpu_pinned
empty_strided_cuda = torch._C._dynamo.guards._empty_strided_cuda
empty_strided_xpu = torch._C._dynamo.guards._empty_strided_xpu
empty_strided_mtia = torch._C._dynamo.guards._empty_strided_mtia
reinterpret_tensor = torch._C._dynamo.guards._reinterpret_tensor
alloc_from_pool = torch.ops.inductor._alloc_from_pool
async_compile = AsyncCompile()
empty_strided_p2p = torch._C._distributed_c10d._SymmetricMemory.empty_strided_p2p


# kernel path: /tmp/infer-opt-models/q35moe-round-profile-20261109/inductor/j3/cj3sbjeo7u3yoa6e6eguu2sgpt3nkxrlvjascwti6dyczzzxunai.py
# Topologically Sorted Source Nodes: [index_select, cat], Original ATen: [aten.index_select, aten.cat, aten.copy_]
# Source node to ATen node mapping:
#   cat => cat
#   index_select => index
# Graph fragment:
#   %arg2_1 : Tensor "i64[1][1]cuda:0" = PlaceHolder[target=arg2_1]
#   %arg1_1 : Tensor "i64[1, 2][2, 1]cuda:0" = PlaceHolder[target=arg1_1]
#   %arg3_1 : Tensor "i64[1, 1][1, 1]cuda:0" = PlaceHolder[target=arg3_1]
#   %copy_ : Tensor "i64[1, 2][2, 1]cuda:0" = PlaceHolder[target=copy_]
#   %index : Tensor "i64[1, 1][1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.index.Tensor](args = (%arg1_1, [None, %arg2_1]), kwargs = {})
#   %cat : Tensor "i64[1, 2][2, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.cat.default](args = ([%index, %arg3_1], 1), kwargs = {})
#   %copy_ : Tensor "i64[1, 2][2, 1]cuda:0"[num_users=0] = call_function[target=torch.ops.aten.copy_.default](args = (%arg0_1, %cat), kwargs = {})
#   return %buf0
triton_poi_fused_cat_copy__index_select_0 = async_compile.triton('triton_poi_fused_cat_copy__index_select_0', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.pointwise(
    size_hints={'x': 2}, 
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*i64', 'in_ptr1': '*i64', 'in_ptr2': '*i64', 'out_ptr0': '*i64', 'xnumel': 'i32', 'XBLOCK': 'constexpr'}, 'device': DeviceProperties(type='cuda', index=0, multi_processor_count=108, cc=80, major=8, regs_per_multiprocessor=65536, max_threads_per_multi_processor=2048, max_threads_per_block=1024, warp_size=32), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]], (3,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'autotune_hints': set(), 'kernel_name': 'triton_poi_fused_cat_copy__index_select_0', 'mutated_arg_names': ['out_ptr0'], 'optimize_mem': True, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 2, 'num_store': 1, 'num_reduction': 0, 'backend_hash': 'F7205DDDCE8E401A1728E5D602D369DE155D3FCCD3ACF038A9886E6E0DD93A54', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'max_autotune': True, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': False, 'are_deterministic_algorithms_enabled': False, 'coordinate_descent_tuning': True, 'coordinate_descent_search_radius': 1, 'coordinate_descent_check_all_directions': False, 'tiling_scores': {'x': 8}},
    min_elem_per_thread=0
)
@triton.jit
def triton_poi_fused_cat_copy__index_select_0(in_ptr0, in_ptr1, in_ptr2, out_ptr0, xnumel, XBLOCK : tl.constexpr):
    xnumel = 2
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:]
    xmask = xindex < xnumel
    x0 = xindex
    tmp0 = x0
    tmp1 = tl.full([1], 0, tl.int64)
    tmp2 = tmp0 >= tmp1
    tmp3 = tl.full([1], 1, tl.int64)
    tmp4 = tmp0 < tmp3
    tmp5 = tl.load(in_ptr0 + (0))
    tmp6 = tl.broadcast_to(tmp5, [XBLOCK])
    tmp7 = tl.where(tmp4, tmp6, 0)
    tmp8 = tl.full([XBLOCK], 2, tl.int32)
    tmp9 = tmp7 + tmp8
    tmp10 = tmp7 < 0
    tmp11 = tl.where(tmp10, tmp9, tmp7)
    tl.device_assert(((0 <= tl.broadcast_to(tmp11, [XBLOCK])) & (tl.broadcast_to(tmp11, [XBLOCK]) < 2)) | ~(tmp4 & xmask), "index out of bounds: 0 <= tl.broadcast_to(tmp11, [XBLOCK]) < 2")
    tmp13 = tl.load(in_ptr1 + (tl.broadcast_to(tmp11, [XBLOCK])), tmp4 & xmask, eviction_policy='evict_last', other=0.0)
    tmp14 = tmp0 >= tmp3
    tmp15 = tl.full([1], 2, tl.int64)
    tmp16 = tmp0 < tmp15
    tmp17 = tl.load(in_ptr2 + (0))
    tmp18 = tl.broadcast_to(tmp17, [XBLOCK])
    tmp19 = tl.where(tmp14, tmp18, 0)
    tmp20 = tl.where(tmp4, tmp13, tmp19)
    tl.store(out_ptr0 + (x0), tmp20, xmask)
''', device_str='cuda')


async_compile.wait(globals())
del async_compile

class Runner:
    def __init__(self, partitions):
        self.partitions = partitions

    def recursively_apply_fns(self, fns):
        new_callables = []
        for fn, c in zip(fns, self.partitions):
            new_callables.append(fn(c))
        self.partitions = new_callables

    def call(self, args):
        arg0_1, arg1_1, arg2_1, arg3_1 = args
        args.clear()
        assert_size_stride(arg0_1, (1, 2), (2, 1))
        assert_size_stride(arg1_1, (1, 2), (2, 1))
        assert_size_stride(arg2_1, (1, ), (1, ))
        assert_size_stride(arg3_1, (1, 1), (1, 1))
        with torch.cuda._DeviceGuard(0):
            torch.cuda.set_device(0)
            # Topologically Sorted Source Nodes: [index_select, cat], Original ATen: [aten.index_select, aten.cat, aten.copy_]
            stream0 = get_raw_stream(0)
            triton_poi_fused_cat_copy__index_select_0.run(arg2_1, arg1_1, arg3_1, arg0_1, 2, stream=stream0)
            del arg0_1
            del arg1_1
            del arg2_1
            del arg3_1
        return ()

runner = Runner(partitions=[])
call = runner.call
recursively_apply_fns = runner.recursively_apply_fns


def get_args():
    from torch._dynamo.testing import rand_strided
    arg0_1 = rand_strided((1, 2), (2, 1), device='cuda:0', dtype=torch.int64)
    arg1_1 = rand_strided((1, 2), (2, 1), device='cuda:0', dtype=torch.int64)
    arg2_1 = rand_strided((1, ), (1, ), device='cuda:0', dtype=torch.int64)
    arg3_1 = rand_strided((1, 1), (1, 1), device='cuda:0', dtype=torch.int64)
    return [arg0_1, arg1_1, arg2_1, arg3_1]


def benchmark_compiled_module(args, times=10, repeat=10):
    from torch._inductor.utils import print_performance
    fn = lambda: call(list(args))
    return print_performance(fn, times=times, repeat=repeat)


if __name__ == "__main__":
    from torch._inductor.wrapper_benchmark import compiled_module_main
    args = get_args()
    compiled_module_main('None', lambda times, repeat: benchmark_compiled_module(args, times=times, repeat=repeat))
