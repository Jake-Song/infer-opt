
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.pointwise(
    size_hints={'x': 4}, 
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*i64', 'in_ptr1': '*i64', 'in_ptr2': '*i64', 'in_ptr3': '*i64', 'in_ptr4': '*i64', 'out_ptr0': '*i64', 'xnumel': 'i32', 'XBLOCK': 'constexpr'}, 'device': DeviceProperties(type='cuda', index=0, multi_processor_count=108, cc=80, major=8, regs_per_multiprocessor=65536, max_threads_per_multi_processor=2048, max_threads_per_block=1024, warp_size=32), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]], (3,): [['tt.divisibility', 16]], (4,): [['tt.divisibility', 16]], (5,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'autotune_hints': set(), 'kernel_name': 'triton_poi_fused_cat_copy__index_select_sub_68', 'mutated_arg_names': ['out_ptr0'], 'optimize_mem': True, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 4, 'num_store': 1, 'num_reduction': 0, 'backend_hash': 'F7205DDDCE8E401A1728E5D602D369DE155D3FCCD3ACF038A9886E6E0DD93A54', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'max_autotune': True, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': False, 'are_deterministic_algorithms_enabled': False, 'coordinate_descent_tuning': True, 'coordinate_descent_search_radius': 1, 'coordinate_descent_check_all_directions': False, 'tiling_scores': {'x': 32}},
    min_elem_per_thread=0
)
@triton.jit
def triton_poi_fused_cat_copy__index_select_sub_68(in_ptr0, in_ptr1, in_ptr2, in_ptr3, in_ptr4, out_ptr0, xnumel, XBLOCK : tl.constexpr):
    xnumel = 4
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:]
    xmask = xindex < xnumel
    x0 = xindex
    tmp0 = x0
    tmp1 = tl.full([1], 0, tl.int64)
    tmp2 = tmp0 >= tmp1
    tmp3 = tl.full([1], 1, tl.int64)
    tmp4 = tmp0 < tmp3
    tmp5 = tl.load(in_ptr0 + (0))
    tmp6 = tl.broadcast_to(tmp5, [XBLOCK])
    tmp7 = tl.where(tmp4, tmp6, 0)
    tmp8 = tl.full([1], 1, tl.int64)
    tmp9 = tmp7 - tmp8
    tmp10 = tl.full([XBLOCK], 4, tl.int32)
    tmp11 = tmp9 + tmp10
    tmp12 = tmp9 < 0
    tmp13 = tl.where(tmp12, tmp11, tmp9)
    tl.device_assert(((0 <= tl.broadcast_to(tmp13, [XBLOCK])) & (tl.broadcast_to(tmp13, [XBLOCK]) < 4)) | ~(tmp4 & xmask), "index out of bounds: 0 <= tl.broadcast_to(tmp13, [XBLOCK]) < 4")
    tmp15 = tl.load(in_ptr1 + (tl.broadcast_to(tmp13, [XBLOCK])), tmp4 & xmask, eviction_policy='evict_last', other=0.0)
    tmp16 = tmp0 >= tmp3
    tmp17 = tl.full([1], 2, tl.int64)
    tmp18 = tmp0 < tmp17
    tmp19 = tmp16 & tmp18
    tmp20 = tl.load(in_ptr2 + (0))
    tmp21 = tl.broadcast_to(tmp20, [XBLOCK])
    tmp22 = tl.where(tmp19, tmp21, 0)
    tmp23 = tmp0 >= tmp17
    tmp24 = tl.full([1], 3, tl.int64)
    tmp25 = tmp0 < tmp24
    tmp26 = tmp23 & tmp25
    tmp27 = tl.load(in_ptr3 + (0))
    tmp28 = tl.broadcast_to(tmp27, [XBLOCK])
    tmp29 = tl.where(tmp26, tmp28, 0)
    tmp30 = tmp0 >= tmp24
    tmp31 = tl.full([1], 4, tl.int64)
    tmp32 = tmp0 < tmp31
    tmp33 = tl.load(in_ptr4 + (0))
    tmp34 = tl.broadcast_to(tmp33, [XBLOCK])
    tmp35 = tl.where(tmp30, tmp34, 0)
    tmp36 = tl.where(tmp26, tmp29, tmp35)
    tmp37 = tl.where(tmp19, tmp22, tmp36)
    tmp38 = tl.where(tmp4, tmp15, tmp37)
    tl.store(out_ptr0 + (x0), tmp38, xmask)
