
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.pointwise(
    size_hints={'x': 1024}, 
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*bf16', 'in_ptr1': '*fp32', 'in_ptr2': '*bf16', 'in_ptr3': '*fp32', 'in_ptr4': '*fp32', 'out_ptr1': '*bf16', 'xnumel': 'i32', 'XBLOCK': 'constexpr'}, 'device': DeviceProperties(type='cuda', index=0, multi_processor_count=108, cc=80, major=8, regs_per_multiprocessor=65536, max_threads_per_multi_processor=2048, max_threads_per_block=1024, warp_size=32), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]], (3,): [['tt.divisibility', 16]], (4,): [['tt.divisibility', 16]], (5,): [['tt.divisibility', 16]], (6,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'autotune_hints': set(), 'kernel_name': 'triton_poi_fused__to_copy_add_arange_cat_cos_expand_mean_mul_neg_pow_rsqrt_select_sin_slice_split_split_with_sizes_transpose_unsqueeze_view_49', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 11, 'num_store': 1, 'num_reduction': 0, 'backend_hash': 'F7205DDDCE8E401A1728E5D602D369DE155D3FCCD3ACF038A9886E6E0DD93A54', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'max_autotune': True, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': False, 'are_deterministic_algorithms_enabled': False, 'coordinate_descent_tuning': True, 'coordinate_descent_search_radius': 1, 'coordinate_descent_check_all_directions': False, 'tiling_scores': {'x': 4992}},
    min_elem_per_thread=0
)
@triton.jit
def triton_poi_fused__to_copy_add_arange_cat_cos_expand_mean_mul_neg_pow_rsqrt_select_sin_slice_split_split_with_sizes_transpose_unsqueeze_view_49(in_ptr0, in_ptr1, in_ptr2, in_ptr3, in_ptr4, out_ptr1, xnumel, XBLOCK : tl.constexpr):
    xnumel = 1024
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:]
    xmask = xindex < xnumel
    x0 = (xindex % 64)
    x1 = xindex // 64
    x2 = xindex
    tmp44 = tl.load(in_ptr0 + (x0 + 512*x1), xmask).to(tl.float32)
    tmp46 = tl.load(in_ptr1 + (x1), xmask, eviction_policy='evict_last')
    tmp53 = tl.load(in_ptr2 + (x0), xmask, eviction_policy='evict_last').to(tl.float32)
    tmp59 = tl.load(in_ptr3 + ((x2 % 32)), xmask, eviction_policy='evict_last')
    tmp62 = tl.load(in_ptr4 + ((x2 % 32)), xmask, eviction_policy='evict_last')
    tmp0 = x0
    tmp1 = tl.full([1], 0, tl.int64)
    tmp2 = tmp0 >= tmp1
    tmp3 = tl.full([1], 32, tl.int64)
    tmp4 = tmp0 < tmp3
    tmp5 = tl.load(in_ptr0 + (32 + 512*x1 + (x0)), tmp4 & xmask, eviction_policy='evict_last', other=0.0).to(tl.float32)
    tmp6 = tmp5.to(tl.float32)
    tmp7 = tl.load(in_ptr1 + (x1), tmp4 & xmask, eviction_policy='evict_last', other=0.0)
    tmp8 = tl.full([1], 256.0, tl.float32)
    tmp9 = (tmp7 / tmp8)
    tmp10 = tl.full([1], 1e-06, tl.float32)
    tmp11 = tmp9 + tmp10
    tmp12 = libdevice.rsqrt(tmp11)
    tmp13 = tmp6 * tmp12
    tmp14 = tl.load(in_ptr2 + (32 + (x0)), tmp4 & xmask, eviction_policy='evict_last', other=0.0).to(tl.float32)
    tmp15 = tmp14.to(tl.float32)
    tmp16 = tl.full([1], 1.0, tl.float32)
    tmp17 = tmp15 + tmp16
    tmp18 = tmp13 * tmp17
    tmp19 = tmp18.to(tl.float32)
    tmp20 = -tmp19
    tmp21 = tl.full(tmp20.shape, 0.0, tmp20.dtype)
    tmp22 = tl.where(tmp4, tmp20, tmp21)
    tmp23 = tmp0 >= tmp3
    tmp24 = tl.full([1], 64, tl.int64)
    tmp25 = tmp0 < tmp24
    tmp26 = tl.load(in_ptr0 + (512*x1 + ((-32) + x0)), tmp23 & xmask, eviction_policy='evict_last', other=0.0).to(tl.float32)
    tmp27 = tmp26.to(tl.float32)
    tmp28 = tl.load(in_ptr1 + (x1), tmp23 & xmask, eviction_policy='evict_last', other=0.0)
    tmp29 = tl.full([1], 256.0, tl.float32)
    tmp30 = (tmp28 / tmp29)
    tmp31 = tl.full([1], 1e-06, tl.float32)
    tmp32 = tmp30 + tmp31
    tmp33 = libdevice.rsqrt(tmp32)
    tmp34 = tmp27 * tmp33
    tmp35 = tl.load(in_ptr2 + ((-32) + x0), tmp23 & xmask, eviction_policy='evict_last', other=0.0).to(tl.float32)
    tmp36 = tmp35.to(tl.float32)
    tmp37 = tl.full([1], 1.0, tl.float32)
    tmp38 = tmp36 + tmp37
    tmp39 = tmp34 * tmp38
    tmp40 = tmp39.to(tl.float32)
    tmp41 = tl.full(tmp40.shape, 0.0, tmp40.dtype)
    tmp42 = tl.where(tmp23, tmp40, tmp41)
    tmp43 = tl.where(tmp4, tmp22, tmp42)
    tmp45 = tmp44.to(tl.float32)
    tmp47 = tl.full([1], 256.0, tl.float32)
    tmp48 = (tmp46 / tmp47)
    tmp49 = tl.full([1], 1e-06, tl.float32)
    tmp50 = tmp48 + tmp49
    tmp51 = libdevice.rsqrt(tmp50)
    tmp52 = tmp45 * tmp51
    tmp54 = tmp53.to(tl.float32)
    tmp55 = tl.full([1], 1.0, tl.float32)
    tmp56 = tmp54 + tmp55
    tmp57 = tmp52 * tmp56
    tmp58 = tmp57.to(tl.float32)
    tmp60 = tmp59.to(tl.float32)
    tmp61 = tmp58 * tmp60
    tmp63 = tmp62.to(tl.float32)
    tmp64 = tmp43 * tmp63
    tmp65 = tmp61 + tmp64
    tl.store(out_ptr1 + (x0 + 256*x1), tmp65, xmask)
