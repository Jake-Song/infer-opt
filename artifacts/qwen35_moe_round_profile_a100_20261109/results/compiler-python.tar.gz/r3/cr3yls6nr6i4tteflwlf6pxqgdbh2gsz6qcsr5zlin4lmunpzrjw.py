

import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties

@triton_heuristics.user_autotune(
    configs=[{'num_warps': 2, 'num_stages': 2}],
    inductor_meta={'grid_type': 'FixedGrid', 'fixed_grid': ['_grid_0', '_grid_1', '_grid_2'], 'extra_launcher_args': ['_grid_0', '_grid_1', '_grid_2'], 'kernel_name': '_w8a16_group_gemv_kernel_5', 'backend_hash': 'F7205DDDCE8E401A1728E5D602D369DE155D3FCCD3ACF038A9886E6E0DD93A54', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'max_autotune': True, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': False, 'are_deterministic_algorithms_enabled': False, 'coordinate_descent_tuning': True, 'coordinate_descent_search_radius': 1, 'coordinate_descent_check_all_directions': False},
    triton_meta={'signature': {'x_ptr': '*bf16', 'q_ptr': '*i8', 's_ptr': '*bf16', 'y_ptr': '*bf16', 'N': 'i32', 'K': 'i32', 'GROUP': 'constexpr', 'BLOCK_N': 'constexpr', 'BLOCK_K': 'constexpr', 'VEC': 'constexpr'}, 'device': DeviceProperties(type='cuda', index=0, multi_processor_count=108, cc=80, major=8, regs_per_multiprocessor=65536, max_threads_per_multi_processor=2048, max_threads_per_block=1024, warp_size=32), 'constants': {'GROUP': 128, 'BLOCK_N': 1, 'BLOCK_K': 1024, 'VEC': 16}, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]], (3,): [['tt.divisibility', 16]], (4,): [['tt.divisibility', 16]], (5,): [['tt.divisibility', 16]]}]},
    filename=__file__,
    custom_kernel=True,
)
@triton.jit
def _w8a16_group_gemv_kernel(x_ptr, q_ptr, s_ptr, y_ptr, N, K, GROUP: tl.constexpr,
                             BLOCK_N: tl.constexpr, BLOCK_K: tl.constexpr, VEC: tl.constexpr):
    NV: tl.constexpr = BLOCK_K // VEC
    pid = tl.program_id(0)
    rows = pid * BLOCK_N + tl.arange(0, BLOCK_N)
    row_ok = rows < N
    jv = tl.arange(0, NV)
    cols = jv[None, :, None] * VEC + tl.arange(0, VEC)[None, None, :]  # [1, NV, VEC]
    groups = K // GROUP
    q_ptrs = q_ptr + rows[:, None, None].to(tl.int64) * K + cols
    x_ptrs = x_ptr + rows[:, None, None] * 0 + cols  # q's shape, so x gets q's layout
    s_row = s_ptr + rows[:, None, None] * groups  # [BLOCK_N, 1, 1]
    s_step = (jv * VEC // GROUP)[None, :, None]  # [1, NV, 1]: one scale per VEC weights, when GROUP divides BLOCK_K
    acc = tl.zeros((BLOCK_N, NV), dtype=tl.float32)
    for k0 in range(0, K, BLOCK_K):
        x = tl.load(x_ptrs + k0).to(tl.float32)
        q = tl.load(q_ptrs + k0, mask=row_ok[:, None, None], other=0, eviction_policy="evict_first").to(tl.float32)
        if BLOCK_K % GROUP == 0:  # hoisted offsets: recomputing them every step was 13% slower on a 9B shape
            s_ptrs = s_row + k0 // GROUP + s_step
        else:
            s_ptrs = s_row + ((k0 + jv * VEC) // GROUP)[None, :, None]
        s = tl.sum(tl.load(s_ptrs, mask=row_ok[:, None, None], other=0.0).to(tl.float32), axis=2)
        acc += tl.sum(q * x, axis=2) * s
    tl.store(y_ptr + rows, tl.sum(acc, axis=1).to(y_ptr.dtype.element_ty), mask=row_ok)
