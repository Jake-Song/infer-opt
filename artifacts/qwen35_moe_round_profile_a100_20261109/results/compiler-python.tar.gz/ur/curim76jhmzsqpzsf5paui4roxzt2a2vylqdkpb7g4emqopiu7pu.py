# AOT ID: ['12_inference']
from ctypes import c_void_p, c_long, c_int
import torch
import math
import random
import os
import tempfile
from math import inf, nan
from cmath import nanj
from torch._inductor.hooks import run_intermediate_hooks
from torch._inductor.utils import maybe_profile
from torch._inductor.codegen.memory_planning import _align as align
from torch import device, empty_strided
from torch._inductor.async_compile import AsyncCompile
from torch._inductor.select_algorithm import extern_kernels
import triton
import triton.language as tl
from torch._inductor.runtime.triton_heuristics import start_graph, end_graph
from torch._C import _cuda_getCurrentRawStream as get_raw_stream

aten = torch.ops.aten
inductor_ops = torch.ops.inductor
_quantized = torch.ops._quantized
assert_size_stride = torch._C._dynamo.guards.assert_size_stride
assert_alignment = torch._C._dynamo.guards.assert_alignment
empty_strided_cpu = torch._C._dynamo.guards._empty_strided_cpu
empty_strided_cpu_pinned = torch._C._dynamo.guards._empty_strided_cpu_pinned
empty_strided_cuda = torch._C._dynamo.guards._empty_strided_cuda
empty_strided_xpu = torch._C._dynamo.guards._empty_strided_xpu
empty_strided_mtia = torch._C._dynamo.guards._empty_strided_mtia
reinterpret_tensor = torch._C._dynamo.guards._reinterpret_tensor
alloc_from_pool = torch.ops.inductor._alloc_from_pool
async_compile = AsyncCompile()
empty_strided_p2p = torch._C._distributed_c10d._SymmetricMemory.empty_strided_p2p


# kernel path: /tmp/infer-opt-models/q35moe-round-profile-20261109/inductor/en/cenj2xoqp5cwcaqc62qy32wb5wnotdcc7at4ipmpi2wbt542yqkv.py
# Topologically Sorted Source Nodes: [embeds, float_2, pow_1, mean, add_1, rsqrt, output, float_3, add_2, output_1, type_as], Original ATen: [aten.embedding, aten._to_copy, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul]
# Source node to ATen node mapping:
#   add_1 => add_1
#   add_2 => add_2
#   embeds => embedding
#   float_2 => convert_element_type_4
#   float_3 => convert_element_type_5
#   mean => mean
#   output => mul_1
#   output_1 => mul_2
#   pow_1 => pow_1
#   rsqrt => rsqrt
#   type_as => convert_element_type_6
# Graph fragment:
#   %arg1_1 : Tensor "i64[1, 1][1, 1]cuda:0" = PlaceHolder[target=arg1_1]
#   %arg0_1 : Tensor "bf16[248320, 2048][2048, 1]cuda:0" = PlaceHolder[target=arg0_1]
#   %buf0 : Tensor "f32[1, 1, 1][1, 1, 1]cuda:0" = PlaceHolder[target=buf0]
#   %arg4_1 : Tensor "bf16[2048][1]cuda:0" = PlaceHolder[target=arg4_1]
#   %embedding : Tensor "bf16[1, 1, 2048][2048, 2048, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.embedding.default](args = (%arg0_1, %arg1_1), kwargs = {})
#   %convert_element_type_4 : Tensor "f32[1, 1, 2048][2048, 2048, 1]cuda:0"[num_users=2] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%embedding, torch.float32), kwargs = {})
#   %pow_1 : Tensor "f32[1, 1, 2048][2048, 2048, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.pow.Tensor_Scalar](args = (%convert_element_type_4, 2), kwargs = {})
#   %mean : Tensor "f32[1, 1, 1][1, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mean.dim](args = (%pow_1, [-1], True), kwargs = {})
#   %add_1 : Tensor "f32[1, 1, 1][1, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%mean, 1e-06), kwargs = {})
#   %rsqrt : Tensor "f32[1, 1, 1][1, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.rsqrt.default](args = (%add_1,), kwargs = {})
#   %mul_1 : Tensor "f32[1, 1, 2048][2048, 2048, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%convert_element_type_4, %rsqrt), kwargs = {})
#   %convert_element_type_5 : Tensor "f32[2048][1]cuda:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%arg4_1, torch.float32), kwargs = {})
#   %add_2 : Tensor "f32[2048][1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%convert_element_type_5, 1.0), kwargs = {})
#   %mul_2 : Tensor "f32[1, 1, 2048][2048, 2048, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%mul_1, %add_2), kwargs = {})
#   %convert_element_type_6 : Tensor "bf16[1, 1, 2048][2048, 2048, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%mul_2, torch.bfloat16), kwargs = {})
#   return %buf0,%convert_element_type_6
triton_per_fused__to_copy_add_embedding_mean_mul_pow_rsqrt_0 = async_compile.triton('triton_per_fused__to_copy_add_embedding_mean_mul_pow_rsqrt_0', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.persistent_reduction(
    size_hints={'x': 1, 'r0_': 2048},
    reduction_hint=ReductionHint.INNER,
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*i64', 'in_ptr1': '*bf16', 'in_ptr2': '*bf16', 'out_ptr1': '*bf16', 'xnumel': 'constexpr', 'r0_numel': 'i32', 'XBLOCK': 'constexpr'}, 'device': DeviceProperties(type='cuda', index=0, multi_processor_count=108, cc=80, major=8, regs_per_multiprocessor=65536, max_threads_per_multi_processor=2048, max_threads_per_block=1024, warp_size=32), 'constants': {'xnumel': 1}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]], (3,): [['tt.divisibility', 16]], (5,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'autotune_hints': set(), 'kernel_name': 'triton_per_fused__to_copy_add_embedding_mean_mul_pow_rsqrt_0', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': None, 'atomic_add_found': False, 'num_load': 2, 'num_store': 1, 'num_reduction': 1, 'backend_hash': 'F7205DDDCE8E401A1728E5D602D369DE155D3FCCD3ACF038A9886E6E0DD93A54', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'max_autotune': True, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': False, 'are_deterministic_algorithms_enabled': False, 'coordinate_descent_tuning': True, 'coordinate_descent_search_radius': 1, 'coordinate_descent_check_all_directions': False, 'tiling_scores': {'r0_': 12288}}
)
@triton.jit
def triton_per_fused__to_copy_add_embedding_mean_mul_pow_rsqrt_0(in_ptr0, in_ptr1, in_ptr2, out_ptr1, xnumel, r0_numel, XBLOCK : tl.constexpr):
    xnumel = 1
    r0_numel = 2048
    R0_BLOCK: tl.constexpr = 2048
    rnumel = r0_numel
    RBLOCK: tl.constexpr = R0_BLOCK
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:, None]
    xmask = tl.full([XBLOCK], True, tl.int1)[:, None]
    r0_index = tl.arange(0, R0_BLOCK)[None, :]
    r0_offset = 0
    r0_mask = tl.full([R0_BLOCK], True, tl.int1)[None, :]
    roffset = r0_offset
    rindex = r0_index
    r0_0 = r0_index
    tmp0 = tl.load(in_ptr0 + (0))
    tmp1 = tl.broadcast_to(tmp0, [1, 1])
    tmp19 = tl.load(in_ptr2 + (r0_0), None).to(tl.float32)
    tmp2 = tl.full([1, 1], 248320, tl.int32)
    tmp3 = tmp1 + tmp2
    tmp4 = tmp1 < 0
    tmp5 = tl.where(tmp4, tmp3, tmp1)
    tl.device_assert((0 <= tmp5) & (tmp5 < 248320), "index out of bounds: 0 <= tmp5 < 248320")
    tmp7 = tl.load(in_ptr1 + (r0_0 + 2048*tmp5), None).to(tl.float32)
    tmp8 = tmp7.to(tl.float32)
    tmp9 = tmp8 * tmp8
    tmp10 = tl.broadcast_to(tmp9, [XBLOCK, R0_BLOCK])
    tmp12 = tl.sum(tmp10, 1)[:, None].to(tl.float32)
    tmp13 = tl.full([1, 1], 2048.0, tl.float32)
    tmp14 = (tmp12 / tmp13)
    tmp15 = tl.full([1, 1], 1e-06, tl.float32)
    tmp16 = tmp14 + tmp15
    tmp17 = libdevice.rsqrt(tmp16)
    tmp18 = tmp8 * tmp17
    tmp20 = tmp19.to(tl.float32)
    tmp21 = tl.full([1, 1], 1.0, tl.float32)
    tmp22 = tmp20 + tmp21
    tmp23 = tmp18 * tmp22
    tmp24 = tmp23.to(tl.float32)
    tl.store(out_ptr1 + (tl.broadcast_to(r0_0, [XBLOCK, R0_BLOCK])), tmp24, None)
''', device_str='cuda')


# kernel path: /tmp/infer-opt-models/q35moe-round-profile-20261109/inductor/j2/cj2jra5p65sjqjvas3ohr3yixjc7waebtvpdr7h7gk2xoso7u75d.py
# Topologically Sorted Source Nodes: [float_4, pow_2, mean_1, add_3, rsqrt_1, output_2, float_5, add_4, output_3, type_as_1], Original ATen: [aten._to_copy, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul]
# Source node to ATen node mapping:
#   add_3 => add_3
#   add_4 => add_4
#   float_4 => convert_element_type_7
#   float_5 => convert_element_type_8
#   mean_1 => mean_1
#   output_2 => mul_3
#   output_3 => mul_4
#   pow_2 => pow_2
#   rsqrt_1 => rsqrt_1
#   type_as_1 => convert_element_type_9
# Graph fragment:
#   %arg5_1 : Tensor "bf16[1, 1, 2048][2048, 2048, 1]cuda:0" = PlaceHolder[target=arg5_1]
#   %buf1 : Tensor "f32[1, 1, 1][1, 1, 1]cuda:0" = PlaceHolder[target=buf1]
#   %arg6_1 : Tensor "bf16[2048][1]cuda:0" = PlaceHolder[target=arg6_1]
#   %convert_element_type_7 : Tensor "f32[1, 1, 2048][2048, 2048, 1]cuda:0"[num_users=2] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%arg5_1, torch.float32), kwargs = {})
#   %pow_2 : Tensor "f32[1, 1, 2048][2048, 2048, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.pow.Tensor_Scalar](args = (%convert_element_type_7, 2), kwargs = {})
#   %mean_1 : Tensor "f32[1, 1, 1][1, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mean.dim](args = (%pow_2, [-1], True), kwargs = {})
#   %add_3 : Tensor "f32[1, 1, 1][1, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%mean_1, 1e-06), kwargs = {})
#   %rsqrt_1 : Tensor "f32[1, 1, 1][1, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.rsqrt.default](args = (%add_3,), kwargs = {})
#   %mul_3 : Tensor "f32[1, 1, 2048][2048, 2048, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%convert_element_type_7, %rsqrt_1), kwargs = {})
#   %convert_element_type_8 : Tensor "f32[2048][1]cuda:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%arg6_1, torch.float32), kwargs = {})
#   %add_4 : Tensor "f32[2048][1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%convert_element_type_8, 1.0), kwargs = {})
#   %mul_4 : Tensor "f32[1, 1, 2048][2048, 2048, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%mul_3, %add_4), kwargs = {})
#   %convert_element_type_9 : Tensor "bf16[1, 1, 2048][2048, 2048, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%mul_4, torch.bfloat16), kwargs = {})
#   return %buf1,%convert_element_type_9
triton_per_fused__to_copy_add_mean_mul_pow_rsqrt_1 = async_compile.triton('triton_per_fused__to_copy_add_mean_mul_pow_rsqrt_1', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.persistent_reduction(
    size_hints={'x': 1, 'r0_': 2048},
    reduction_hint=ReductionHint.INNER,
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*bf16', 'in_ptr1': '*bf16', 'out_ptr1': '*bf16', 'xnumel': 'constexpr', 'r0_numel': 'i32', 'XBLOCK': 'constexpr'}, 'device': DeviceProperties(type='cuda', index=0, multi_processor_count=108, cc=80, major=8, regs_per_multiprocessor=65536, max_threads_per_multi_processor=2048, max_threads_per_block=1024, warp_size=32), 'constants': {'xnumel': 1}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]], (4,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'autotune_hints': set(), 'kernel_name': 'triton_per_fused__to_copy_add_mean_mul_pow_rsqrt_1', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': None, 'atomic_add_found': False, 'num_load': 2, 'num_store': 1, 'num_reduction': 1, 'backend_hash': 'F7205DDDCE8E401A1728E5D602D369DE155D3FCCD3ACF038A9886E6E0DD93A54', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'max_autotune': True, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': False, 'are_deterministic_algorithms_enabled': False, 'coordinate_descent_tuning': True, 'coordinate_descent_search_radius': 1, 'coordinate_descent_check_all_directions': False, 'tiling_scores': {'r0_': 16384}}
)
@triton.jit
def triton_per_fused__to_copy_add_mean_mul_pow_rsqrt_1(in_ptr0, in_ptr1, out_ptr1, xnumel, r0_numel, XBLOCK : tl.constexpr):
    xnumel = 1
    r0_numel = 2048
    R0_BLOCK: tl.constexpr = 2048
    rnumel = r0_numel
    RBLOCK: tl.constexpr = R0_BLOCK
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:, None]
    xmask = tl.full([XBLOCK], True, tl.int1)[:, None]
    r0_index = tl.arange(0, R0_BLOCK)[None, :]
    r0_offset = 0
    r0_mask = tl.full([R0_BLOCK], True, tl.int1)[None, :]
    roffset = r0_offset
    rindex = r0_index
    r0_0 = r0_index
    tmp0 = tl.load(in_ptr0 + (r0_0), None).to(tl.float32)
    tmp12 = tl.load(in_ptr1 + (r0_0), None).to(tl.float32)
    tmp1 = tmp0.to(tl.float32)
    tmp2 = tmp1 * tmp1
    tmp3 = tl.broadcast_to(tmp2, [XBLOCK, R0_BLOCK])
    tmp5 = tl.sum(tmp3, 1)[:, None].to(tl.float32)
    tmp6 = tl.full([1, 1], 2048.0, tl.float32)
    tmp7 = (tmp5 / tmp6)
    tmp8 = tl.full([1, 1], 1e-06, tl.float32)
    tmp9 = tmp7 + tmp8
    tmp10 = libdevice.rsqrt(tmp9)
    tmp11 = tmp1 * tmp10
    tmp13 = tmp12.to(tl.float32)
    tmp14 = tl.full([1, 1], 1.0, tl.float32)
    tmp15 = tmp13 + tmp14
    tmp16 = tmp11 * tmp15
    tmp17 = tmp16.to(tl.float32)
    tl.store(out_ptr1 + (tl.broadcast_to(r0_0, [XBLOCK, R0_BLOCK])), tmp17, None)
''', device_str='cuda')


# Original path: /content/q35moe-round-profile-20261109/infer-opt/infer_opt/quant_kernels.py:72
_w8a16_group_gemv_kernel_0 = async_compile.triton('_w8a16_group_gemv_kernel', '''

import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties

@triton_heuristics.user_autotune(
    configs=[{'num_warps': 2, 'num_stages': 2}],
    inductor_meta={'grid_type': 'FixedGrid', 'fixed_grid': ['_grid_0', '_grid_1', '_grid_2'], 'extra_launcher_args': ['_grid_0', '_grid_1', '_grid_2'], 'kernel_name': '_w8a16_group_gemv_kernel_0', 'backend_hash': 'F7205DDDCE8E401A1728E5D602D369DE155D3FCCD3ACF038A9886E6E0DD93A54', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'max_autotune': True, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': False, 'are_deterministic_algorithms_enabled': False, 'coordinate_descent_tuning': True, 'coordinate_descent_search_radius': 1, 'coordinate_descent_check_all_directions': False},
    triton_meta={'signature': {'x_ptr': '*bf16', 'q_ptr': '*i8', 's_ptr': '*bf16', 'y_ptr': '*bf16', 'N': 'i32', 'K': 'i32', 'GROUP': 'constexpr', 'BLOCK_N': 'constexpr', 'BLOCK_K': 'constexpr', 'VEC': 'constexpr'}, 'device': DeviceProperties(type='cuda', index=0, multi_processor_count=108, cc=80, major=8, regs_per_multiprocessor=65536, max_threads_per_multi_processor=2048, max_threads_per_block=1024, warp_size=32), 'constants': {'GROUP': 128, 'BLOCK_N': 1, 'BLOCK_K': 1024, 'VEC': 16}, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]], (3,): [['tt.divisibility', 16]], (4,): [['tt.divisibility', 16]], (5,): [['tt.divisibility', 16]]}]},
    filename=__file__,
    custom_kernel=True,
)
@triton.jit
def _w8a16_group_gemv_kernel(x_ptr, q_ptr, s_ptr, y_ptr, N, K, GROUP: tl.constexpr,
                             BLOCK_N: tl.constexpr, BLOCK_K: tl.constexpr, VEC: tl.constexpr):
    NV: tl.constexpr = BLOCK_K // VEC
    pid = tl.program_id(0)
    rows = pid * BLOCK_N + tl.arange(0, BLOCK_N)
    row_ok = rows < N
    jv = tl.arange(0, NV)
    cols = jv[None, :, None] * VEC + tl.arange(0, VEC)[None, None, :]  # [1, NV, VEC]
    groups = K // GROUP
    q_ptrs = q_ptr + rows[:, None, None].to(tl.int64) * K + cols
    x_ptrs = x_ptr + rows[:, None, None] * 0 + cols  # q's shape, so x gets q's layout
    s_row = s_ptr + rows[:, None, None] * groups  # [BLOCK_N, 1, 1]
    s_step = (jv * VEC // GROUP)[None, :, None]  # [1, NV, 1]: one scale per VEC weights, when GROUP divides BLOCK_K
    acc = tl.zeros((BLOCK_N, NV), dtype=tl.float32)
    for k0 in range(0, K, BLOCK_K):
        x = tl.load(x_ptrs + k0).to(tl.float32)
        q = tl.load(q_ptrs + k0, mask=row_ok[:, None, None], other=0, eviction_policy="evict_first").to(tl.float32)
        if BLOCK_K % GROUP == 0:  # hoisted offsets: recomputing them every step was 13% slower on a 9B shape
            s_ptrs = s_row + k0 // GROUP + s_step
        else:
            s_ptrs = s_row + ((k0 + jv * VEC) // GROUP)[None, :, None]
        s = tl.sum(tl.load(s_ptrs, mask=row_ok[:, None, None], other=0.0).to(tl.float32), axis=2)
        acc += tl.sum(q * x, axis=2) * s
    tl.store(y_ptr + rows, tl.sum(acc, axis=1).to(y_ptr.dtype.element_ty), mask=row_ok)
''', device_str='cuda')


# kernel path: /tmp/infer-opt-models/q35moe-round-profile-20261109/inductor/ik/ciktsi6l3plqs5iepvnnnv25mn5mhu7uiut3xc7k25yabqmbq5du.py
# Topologically Sorted Source Nodes: [float_6, pow_3, mean_2, add_5, rsqrt_2, output_4, float_7, add_6, output_5, hidden_states, y_1], Original ATen: [aten._to_copy, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul]
# Source node to ATen node mapping:
#   add_5 => add_5
#   add_6 => add_6
#   float_6 => convert_element_type_10
#   float_7 => convert_element_type_11
#   hidden_states => convert_element_type_12
#   mean_2 => mean_2
#   output_4 => mul_5
#   output_5 => mul_6
#   pow_3 => pow_3
#   rsqrt_2 => rsqrt_2
#   y_1 => triton_kernel_wrapper_mutation_4
# Graph fragment:
#   %buf6 : Tensor  = PlaceHolder[target=buf6]
#   %buf7 : Tensor "f32[1, 1, 1][1, 1, 1]cuda:0" = PlaceHolder[target=buf7]
#   %arg9_1 : Tensor "bf16[2048][1]cuda:0" = PlaceHolder[target=arg9_1]
#   %convert_element_type_10 : Tensor "f32[1, 1, 2048][2048, 2048, 1]cuda:0"[num_users=2] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%empty, torch.float32), kwargs = {})
#   %pow_3 : Tensor "f32[1, 1, 2048][2048, 2048, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.pow.Tensor_Scalar](args = (%convert_element_type_10, 2), kwargs = {})
#   %mean_2 : Tensor "f32[1, 1, 1][1, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mean.dim](args = (%pow_3, [-1], True), kwargs = {})
#   %add_5 : Tensor "f32[1, 1, 1][1, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%mean_2, 1e-06), kwargs = {})
#   %rsqrt_2 : Tensor "f32[1, 1, 1][1, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.rsqrt.default](args = (%add_5,), kwargs = {})
#   %mul_5 : Tensor "f32[1, 1, 2048][2048, 2048, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%convert_element_type_10, %rsqrt_2), kwargs = {})
#   %convert_element_type_11 : Tensor "f32[2048][1]cuda:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%arg9_1, torch.float32), kwargs = {})
#   %add_6 : Tensor "f32[2048][1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%convert_element_type_11, 1.0), kwargs = {})
#   %mul_6 : Tensor "f32[1, 1, 2048][2048, 2048, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%mul_5, %add_6), kwargs = {})
#   %convert_element_type_12 : Tensor "bf16[1, 1, 2048][2048, 2048, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%mul_6, torch.bfloat16), kwargs = {})
#   %triton_kernel_wrapper_mutation_4 : [num_users=0] = call_function[target=torch.ops.higher_order.triton_kernel_wrapper_mutation](args = (), kwargs = {kernel_idx: 2921, constant_args_idx: 3536, grid: [(9216, 1, 1)], tma_descriptor_metadata: {}, kwargs: {x_ptr: %convert_element_type_12, q_ptr: %arg10_1, s_ptr: %arg11_1, y_ptr: %empty_1, N: 9216, K: 2048, GROUP: 128, BLOCK_N: 1, BLOCK_K: 1024, VEC: 16}})
#   return %buf7,%buf9
triton_per_fused__to_copy_add_mean_mul_pow_rsqrt_2 = async_compile.triton('triton_per_fused__to_copy_add_mean_mul_pow_rsqrt_2', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.persistent_reduction(
    size_hints={'x': 1, 'r0_': 2048},
    reduction_hint=ReductionHint.INNER,
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*bf16', 'in_ptr1': '*bf16', 'out_ptr1': '*bf16', 'xnumel': 'constexpr', 'r0_numel': 'i32', 'XBLOCK': 'constexpr'}, 'device': DeviceProperties(type='cuda', index=0, multi_processor_count=108, cc=80, major=8, regs_per_multiprocessor=65536, max_threads_per_multi_processor=2048, max_threads_per_block=1024, warp_size=32), 'constants': {'xnumel': 1}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]], (4,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'autotune_hints': set(), 'kernel_name': 'triton_per_fused__to_copy_add_mean_mul_pow_rsqrt_2', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': None, 'atomic_add_found': False, 'num_load': 2, 'num_store': 1, 'num_reduction': 1, 'backend_hash': 'F7205DDDCE8E401A1728E5D602D369DE155D3FCCD3ACF038A9886E6E0DD93A54', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'max_autotune': True, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': False, 'are_deterministic_algorithms_enabled': False, 'coordinate_descent_tuning': True, 'coordinate_descent_search_radius': 1, 'coordinate_descent_check_all_directions': False, 'tiling_scores': {'r0_': 12288}}
)
@triton.jit
def triton_per_fused__to_copy_add_mean_mul_pow_rsqrt_2(in_ptr0, in_ptr1, out_ptr1, xnumel, r0_numel, XBLOCK : tl.constexpr):
    xnumel = 1
    r0_numel = 2048
    R0_BLOCK: tl.constexpr = 2048
    rnumel = r0_numel
    RBLOCK: tl.constexpr = R0_BLOCK
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:, None]
    xmask = tl.full([XBLOCK], True, tl.int1)[:, None]
    r0_index = tl.arange(0, R0_BLOCK)[None, :]
    r0_offset = 0
    r0_mask = tl.full([R0_BLOCK], True, tl.int1)[None, :]
    roffset = r0_offset
    rindex = r0_index
    r0_0 = r0_index
    tmp0 = tl.load(in_ptr0 + (r0_0), None).to(tl.float32)
    tmp12 = tl.load(in_ptr1 + (r0_0), None).to(tl.float32)
    tmp1 = tmp0.to(tl.float32)
    tmp2 = tmp1 * tmp1
    tmp3 = tl.broadcast_to(tmp2, [XBLOCK, R0_BLOCK])
    tmp5 = tl.sum(tmp3, 1)[:, None].to(tl.float32)
    tmp6 = tl.full([1, 1], 2048.0, tl.float32)
    tmp7 = (tmp5 / tmp6)
    tmp8 = tl.full([1, 1], 1e-06, tl.float32)
    tmp9 = tmp7 + tmp8
    tmp10 = libdevice.rsqrt(tmp9)
    tmp11 = tmp1 * tmp10
    tmp13 = tmp12.to(tl.float32)
    tmp14 = tl.full([1, 1], 1.0, tl.float32)
    tmp15 = tmp13 + tmp14
    tmp16 = tmp11 * tmp15
    tmp17 = tmp16.to(tl.float32)
    tl.store(out_ptr1 + (tl.broadcast_to(r0_0, [XBLOCK, R0_BLOCK])), tmp17, None)
''', device_str='cuda')


# Original path: /content/q35moe-round-profile-20261109/infer-opt/infer_opt/quant_kernels.py:72
_w8a16_group_gemv_kernel_1 = async_compile.triton('_w8a16_group_gemv_kernel', '''

import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties

@triton_heuristics.user_autotune(
    configs=[{'num_warps': 2, 'num_stages': 2}],
    inductor_meta={'grid_type': 'FixedGrid', 'fixed_grid': ['_grid_0', '_grid_1', '_grid_2'], 'extra_launcher_args': ['_grid_0', '_grid_1', '_grid_2'], 'kernel_name': '_w8a16_group_gemv_kernel_1', 'backend_hash': 'F7205DDDCE8E401A1728E5D602D369DE155D3FCCD3ACF038A9886E6E0DD93A54', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'max_autotune': True, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': False, 'are_deterministic_algorithms_enabled': False, 'coordinate_descent_tuning': True, 'coordinate_descent_search_radius': 1, 'coordinate_descent_check_all_directions': False},
    triton_meta={'signature': {'x_ptr': '*bf16', 'q_ptr': '*i8', 's_ptr': '*bf16', 'y_ptr': '*bf16', 'N': 'i32', 'K': 'i32', 'GROUP': 'constexpr', 'BLOCK_N': 'constexpr', 'BLOCK_K': 'constexpr', 'VEC': 'constexpr'}, 'device': DeviceProperties(type='cuda', index=0, multi_processor_count=108, cc=80, major=8, regs_per_multiprocessor=65536, max_threads_per_multi_processor=2048, max_threads_per_block=1024, warp_size=32), 'constants': {'GROUP': 128, 'BLOCK_N': 1, 'BLOCK_K': 1024, 'VEC': 16}, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]], (3,): [['tt.divisibility', 16]], (4,): [['tt.divisibility', 16]], (5,): [['tt.divisibility', 16]]}]},
    filename=__file__,
    custom_kernel=True,
)
@triton.jit
def _w8a16_group_gemv_kernel(x_ptr, q_ptr, s_ptr, y_ptr, N, K, GROUP: tl.constexpr,
                             BLOCK_N: tl.constexpr, BLOCK_K: tl.constexpr, VEC: tl.constexpr):
    NV: tl.constexpr = BLOCK_K // VEC
    pid = tl.program_id(0)
    rows = pid * BLOCK_N + tl.arange(0, BLOCK_N)
    row_ok = rows < N
    jv = tl.arange(0, NV)
    cols = jv[None, :, None] * VEC + tl.arange(0, VEC)[None, None, :]  # [1, NV, VEC]
    groups = K // GROUP
    q_ptrs = q_ptr + rows[:, None, None].to(tl.int64) * K + cols
    x_ptrs = x_ptr + rows[:, None, None] * 0 + cols  # q's shape, so x gets q's layout
    s_row = s_ptr + rows[:, None, None] * groups  # [BLOCK_N, 1, 1]
    s_step = (jv * VEC // GROUP)[None, :, None]  # [1, NV, 1]: one scale per VEC weights, when GROUP divides BLOCK_K
    acc = tl.zeros((BLOCK_N, NV), dtype=tl.float32)
    for k0 in range(0, K, BLOCK_K):
        x = tl.load(x_ptrs + k0).to(tl.float32)
        q = tl.load(q_ptrs + k0, mask=row_ok[:, None, None], other=0, eviction_policy="evict_first").to(tl.float32)
        if BLOCK_K % GROUP == 0:  # hoisted offsets: recomputing them every step was 13% slower on a 9B shape
            s_ptrs = s_row + k0 // GROUP + s_step
        else:
            s_ptrs = s_row + ((k0 + jv * VEC) // GROUP)[None, :, None]
        s = tl.sum(tl.load(s_ptrs, mask=row_ok[:, None, None], other=0.0).to(tl.float32), axis=2)
        acc += tl.sum(q * x, axis=2) * s
    tl.store(y_ptr + rows, tl.sum(acc, axis=1).to(y_ptr.dtype.element_ty), mask=row_ok)
''', device_str='cuda')


# kernel path: /tmp/infer-opt-models/q35moe-round-profile-20261109/inductor/lu/cluwnv4dvctxb2s2iwwqxosys6rda3vrdkpcunslira73ualhlvf.py
# Topologically Sorted Source Nodes: [float_8, pow_4, mean_3], Original ATen: [aten.split_with_sizes, aten.view, aten.split, aten._to_copy, aten.pow, aten.mean]
# Source node to ATen node mapping:
#   float_8 => convert_element_type_13, split_3, split_with_sizes_5, view_9
#   mean_3 => mean_3
#   pow_4 => pow_4
# Graph fragment:
#   %buf10 : Tensor  = PlaceHolder[target=buf10]
#   %split_with_sizes_5 : [num_users=1] = call_function[target=torch.ops.aten.split_with_sizes.default](args = (%empty_1, [8192, 512, 512], -1), kwargs = {})
#   %view_9 : Tensor "bf16[1, 1, 16, 512][9216, 9216, 512, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%getitem_23, [1, 1, -1, 512]), kwargs = {})
#   %split_3 : [num_users=1] = call_function[target=torch.ops.aten.split.Tensor](args = (%view_9, 256, -1), kwargs = {})
#   %convert_element_type_13 : Tensor "f32[1, 1, 16, 256][4096, 4096, 256, 1]cuda:0"[num_users=2] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%getitem_26, torch.float32), kwargs = {})
#   %pow_4 : Tensor "f32[1, 1, 16, 256][4096, 4096, 256, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.pow.Tensor_Scalar](args = (%convert_element_type_13, 2), kwargs = {})
#   %mean_3 : Tensor "f32[1, 1, 16, 1][16, 16, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mean.dim](args = (%pow_4, [-1], True), kwargs = {})
#   return %buf11
triton_per_fused__to_copy_mean_pow_split_split_with_sizes_view_3 = async_compile.triton('triton_per_fused__to_copy_mean_pow_split_split_with_sizes_view_3', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.persistent_reduction(
    size_hints={'x': 16, 'r0_': 256},
    reduction_hint=ReductionHint.INNER,
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*bf16', 'out_ptr0': '*fp32', 'xnumel': 'i32', 'r0_numel': 'i32', 'XBLOCK': 'constexpr'}, 'device': DeviceProperties(type='cuda', index=0, multi_processor_count=108, cc=80, major=8, regs_per_multiprocessor=65536, max_threads_per_multi_processor=2048, max_threads_per_block=1024, warp_size=32), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]], (3,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'autotune_hints': set(), 'kernel_name': 'triton_per_fused__to_copy_mean_pow_split_split_with_sizes_view_3', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': None, 'atomic_add_found': False, 'num_load': 1, 'num_store': 1, 'num_reduction': 1, 'backend_hash': 'F7205DDDCE8E401A1728E5D602D369DE155D3FCCD3ACF038A9886E6E0DD93A54', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'max_autotune': True, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': False, 'are_deterministic_algorithms_enabled': False, 'coordinate_descent_tuning': True, 'coordinate_descent_search_radius': 1, 'coordinate_descent_check_all_directions': False, 'tiling_scores': {'x': 128, 'r0_': 0}}
)
@triton.jit
def triton_per_fused__to_copy_mean_pow_split_split_with_sizes_view_3(in_ptr0, out_ptr0, xnumel, r0_numel, XBLOCK : tl.constexpr):
    xnumel = 16
    r0_numel = 256
    R0_BLOCK: tl.constexpr = 256
    rnumel = r0_numel
    RBLOCK: tl.constexpr = R0_BLOCK
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:, None]
    xmask = xindex < xnumel
    r0_index = tl.arange(0, R0_BLOCK)[None, :]
    r0_offset = 0
    r0_mask = tl.full([R0_BLOCK], True, tl.int1)[None, :]
    roffset = r0_offset
    rindex = r0_index
    r0_1 = r0_index
    x0 = xindex
    tmp0 = tl.load(in_ptr0 + (r0_1 + 512*x0), xmask, other=0.0).to(tl.float32)
    tmp1 = tmp0.to(tl.float32)
    tmp2 = tmp1 * tmp1
    tmp3 = tl.broadcast_to(tmp2, [XBLOCK, R0_BLOCK])
    tmp5 = tl.where(xmask, tmp3, 0)
    tmp6 = tl.sum(tmp5, 1)[:, None].to(tl.float32)
    tl.store(out_ptr0 + (x0), tmp6, xmask)
''', device_str='cuda')


# kernel path: /tmp/infer-opt-models/q35moe-round-profile-20261109/inductor/uw/cuww6d4xvuaig6w5r7cxvaarq2lp53jdtl6n4dfvb3evyuhopk2s.py
# Topologically Sorted Source Nodes: [arange, positions, view, expand, position_ids, getitem, float_1, to, freqs, cos, getitem_2, sin, getitem_5, setitem_1, setitem_3], Original ATen: [aten.arange, aten.add, aten.view, aten.expand, aten.unsqueeze, aten._to_copy, aten.mul, aten.cos, aten.select, aten.slice, aten.sin]
# Source node to ATen node mapping:
#   arange => iota
#   cos => cos
#   expand => expand
#   float_1 => convert_element_type
#   freqs => mul
#   getitem => unsqueeze
#   getitem_2 => select_1, slice_1
#   getitem_5 => select_13, slice_9
#   position_ids => expand_1
#   positions => add
#   setitem_1 => select_8, slice_7
#   setitem_3 => select_20, slice_15
#   sin => sin
#   to => convert_element_type_1
#   view => view
# Graph fragment:
#   %copy_ : Tensor "i64[1][1]cuda:0" = PlaceHolder[target=copy_]
#   %arg3_1 : Tensor "bf16[32][1]cuda:0" = PlaceHolder[target=arg3_1]
#   %iota : Tensor "i64[1][1]cuda:0"[num_users=1] = call_function[target=torch.ops.prims.iota.default](args = (1,), kwargs = {start: 0, step: 1, dtype: torch.int64, device: cuda:0, requires_grad: False})
#   %add : Tensor "i64[1][1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%iota, %arg2_1), kwargs = {})
#   %view : Tensor "i64[1, 1, 1][1, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%add, [1, 1, 1]), kwargs = {})
#   %expand : Tensor "i64[3, 1, 1][0, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.expand.default](args = (%view, [3, 1, 1]), kwargs = {})
#   %expand_1 : Tensor "i64[3, 1, 1][0, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.expand.default](args = (%expand, [3, -1, -1]), kwargs = {})
#   %unsqueeze : Tensor "i64[3, 1, 1, 1][0, 1, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%expand_1, 3), kwargs = {})
#   %convert_element_type : Tensor "f32[3, 1, 1, 1][1, 1, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%unsqueeze, torch.float32), kwargs = {})
#   %convert_element_type_1 : Tensor "f32[32][1]cuda:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%arg3_1, torch.float32), kwargs = {})
#   %mul : Tensor "f32[3, 1, 1, 32][32, 32, 32, 1]cuda:0"[num_users=2] = call_function[target=torch.ops.aten.mul.Tensor](args = (%convert_element_type, %convert_element_type_1), kwargs = {})
#   %cos : Tensor "f32[3, 1, 1, 32][32, 32, 32, 1]cuda:0"[num_users=5] = call_function[target=torch.ops.aten.cos.default](args = (%mul,), kwargs = {})
#   %select_1 : Tensor "f32[1, 1, 32][32, 32, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.select.int](args = (%cos, 0, 1), kwargs = {})
#   %slice_1 : Tensor "f32[1, 1, 11][32, 32, 3]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.slice.Tensor](args = (%select_1, 2, 1, 33, 3), kwargs = {})
#   %select_int : Tensor "f32[1, 1, 32][32, 32, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.select.int](args = (%cos, 0, 0), kwargs = {})
#   %slice_scatter_default : Tensor "f32[1, 1, 32][32, 32, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.slice_scatter.default](args = (%select_int, %slice_1, 2, 1, 33, 3), kwargs = {})
#   %select_scatter_default : Tensor "f32[3, 1, 1, 32][32, 32, 32, 1]cuda:0"[num_users=5] = call_function[target=torch.ops.aten.select_scatter.default](args = (%cos, %slice_scatter_default, 0, 0), kwargs = {})
#   %sin : Tensor "f32[3, 1, 1, 32][32, 32, 32, 1]cuda:0"[num_users=5] = call_function[target=torch.ops.aten.sin.default](args = (%mul,), kwargs = {})
#   %select_13 : Tensor "f32[1, 1, 32][32, 32, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.select.int](args = (%sin, 0, 1), kwargs = {})
#   %slice_9 : Tensor "f32[1, 1, 11][32, 32, 3]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.slice.Tensor](args = (%select_13, 2, 1, 33, 3), kwargs = {})
#   %select_int_1 : Tensor "f32[1, 1, 32][32, 32, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.select.int](args = (%sin, 0, 0), kwargs = {})
#   %slice_scatter_default_1 : Tensor "f32[1, 1, 32][32, 32, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.slice_scatter.default](args = (%select_int_1, %slice_9, 2, 1, 33, 3), kwargs = {})
#   %select_scatter_default_1 : Tensor "f32[3, 1, 1, 32][32, 32, 32, 1]cuda:0"[num_users=5] = call_function[target=torch.ops.aten.select_scatter.default](args = (%sin, %slice_scatter_default_1, 0, 0), kwargs = {})
#   %select_8 : Tensor "f32[1, 1, 32][32, 32, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.select.int](args = (%select_scatter_default, 0, 2), kwargs = {})
#   %slice_7 : Tensor "f32[1, 1, 10][32, 32, 3]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.slice.Tensor](args = (%select_8, 2, 2, 30, 3), kwargs = {})
#   %select_int_2 : Tensor "f32[1, 1, 32][32, 32, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.select.int](args = (%select_scatter_default, 0, 0), kwargs = {})
#   %slice_scatter_default_2 : Tensor "f32[1, 1, 32][32, 32, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.slice_scatter.default](args = (%select_int_2, %slice_7, 2, 2, 30, 3), kwargs = {})
#   %select_20 : Tensor "f32[1, 1, 32][32, 32, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.select.int](args = (%select_scatter_default_1, 0, 2), kwargs = {})
#   %slice_15 : Tensor "f32[1, 1, 10][32, 32, 3]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.slice.Tensor](args = (%select_20, 2, 2, 30, 3), kwargs = {})
#   %select_int_3 : Tensor "f32[1, 1, 32][32, 32, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.select.int](args = (%select_scatter_default_1, 0, 0), kwargs = {})
#   %slice_scatter_default_3 : Tensor "f32[1, 1, 32][32, 32, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.slice_scatter.default](args = (%select_int_3, %slice_15, 2, 2, 30, 3), kwargs = {})
#   return %slice_scatter_default_2,%slice_scatter_default_3
triton_poi_fused__to_copy_add_arange_cos_expand_mul_select_sin_slice_unsqueeze_view_4 = async_compile.triton('triton_poi_fused__to_copy_add_arange_cos_expand_mul_select_sin_slice_unsqueeze_view_4', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.pointwise(
    size_hints={'x': 32}, 
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*i64', 'in_ptr1': '*bf16', 'out_ptr0': '*fp32', 'out_ptr1': '*fp32', 'xnumel': 'i32', 'XBLOCK': 'constexpr'}, 'device': DeviceProperties(type='cuda', index=0, multi_processor_count=108, cc=80, major=8, regs_per_multiprocessor=65536, max_threads_per_multi_processor=2048, max_threads_per_block=1024, warp_size=32), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]], (3,): [['tt.divisibility', 16]], (4,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'autotune_hints': set(), 'kernel_name': 'triton_poi_fused__to_copy_add_arange_cos_expand_mul_select_sin_slice_unsqueeze_view_4', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 8, 'num_store': 2, 'num_reduction': 0, 'backend_hash': 'F7205DDDCE8E401A1728E5D602D369DE155D3FCCD3ACF038A9886E6E0DD93A54', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'max_autotune': True, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': False, 'are_deterministic_algorithms_enabled': False, 'coordinate_descent_tuning': True, 'coordinate_descent_search_radius': 1, 'coordinate_descent_check_all_directions': False, 'tiling_scores': {'x': 704}},
    min_elem_per_thread=0
)
@triton.jit
def triton_poi_fused__to_copy_add_arange_cos_expand_mul_select_sin_slice_unsqueeze_view_4(in_ptr0, in_ptr1, out_ptr0, out_ptr1, xnumel, XBLOCK : tl.constexpr):
    xnumel = 32
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:]
    xmask = xindex < xnumel
    x0 = xindex
    tmp64 = tl.load(in_ptr0 + (0))
    tmp65 = tl.broadcast_to(tmp64, [XBLOCK])
    tmp68 = tl.load(in_ptr1 + (x0), xmask).to(tl.float32)
    tmp0 = x0
    tmp1 = tl.full([1], 2, tl.int64)
    tmp2 = tmp0 >= tmp1
    tmp3 = tl.full([1], 30, tl.int64)
    tmp4 = tmp0 < tmp3
    tmp5 = (((-2) + x0) % 3)
    tmp6 = tl.full([1], 0, tl.int64)
    tmp7 = tmp5 == tmp6
    tmp8 = tmp2 & tmp4
    tmp9 = tmp8 & tmp7
    tmp10 = tl.full([1], 2, tl.int32)
    tmp11 = tl.full([1], 0, tl.int32)
    tmp12 = tmp10 == tmp11
    tmp13 = 2 + 3*(triton_helpers.div_floor_integer((-2) + x0,  3))
    tmp14 = tl.full([1], 1, tl.int64)
    tmp15 = tmp13 >= tmp14
    tmp16 = tl.full([1], 0, tl.int64)
    tmp17 = tmp14 == tmp16
    tmp18 = tmp15 & tmp17
    tmp19 = tmp18 & tmp9
    tmp20 = tl.load(in_ptr0 + (0))
    tmp21 = tl.broadcast_to(tmp20, [XBLOCK])
    tmp22 = tl.where(tmp19, tmp21, 0)
    tmp23 = tl.full([1], 0, tl.int64)
    tmp24 = tmp23 + tmp22
    tmp25 = tmp24.to(tl.float32)
    tmp26 = tl.load(in_ptr1 + (1 + 3*(triton_helpers.div_floor_integer((-2) + x0,  3))), tmp19 & xmask, eviction_policy='evict_last', other=0.0).to(tl.float32)
    tmp27 = tmp26.to(tl.float32)
    tmp28 = tmp25 * tmp27
    tmp29 = tl_math.cos(tmp28)
    tmp30 = tl.full(tmp29.shape, 0.0, tmp29.dtype)
    tmp31 = tl.where(tmp19, tmp29, tmp30)
    tmp32 = tl.load(in_ptr0 + (0))
    tmp33 = tl.broadcast_to(tmp32, [XBLOCK])
    tmp34 = tl.where(tmp9, tmp33, 0)
    tmp35 = tmp16 + tmp34
    tmp36 = tmp35.to(tl.float32)
    tmp37 = tl.load(in_ptr1 + (2 + 3*(triton_helpers.div_floor_integer((-2) + x0,  3))), tmp9 & xmask, eviction_policy='evict_last', other=0.0).to(tl.float32)
    tmp38 = tmp37.to(tl.float32)
    tmp39 = tmp36 * tmp38
    tmp40 = tl_math.cos(tmp39)
    tmp41 = tl.where(tmp18, tmp31, tmp40)
    tmp42 = tl.where(tmp12, tmp41, tmp40)
    tmp43 = tl.full(tmp42.shape, 0.0, tmp42.dtype)
    tmp44 = tl.where(tmp9, tmp42, tmp43)
    tmp45 = tl.full([1], 0, tl.int32)
    tmp46 = tmp45 == tmp45
    tmp47 = tl.full([1], 1, tl.int64)
    tmp48 = tmp0 >= tmp47
    tmp49 = (((-1) + x0) % 3)
    tmp50 = tmp49 == tmp6
    tmp51 = tmp48 & tmp50
    tmp52 = tl.load(in_ptr0 + (0))
    tmp53 = tl.broadcast_to(tmp52, [XBLOCK])
    tmp54 = tl.where(tmp51, tmp53, 0)
    tmp55 = tl.full([1], 0, tl.int64)
    tmp56 = tmp55 + tmp54
    tmp57 = tmp56.to(tl.float32)
    tmp58 = tl.load(in_ptr1 + (1 + 3*(triton_helpers.div_floor_integer((-1) + x0,  3))), tmp51 & xmask, eviction_policy='evict_last', other=0.0).to(tl.float32)
    tmp59 = tmp58.to(tl.float32)
    tmp60 = tmp57 * tmp59
    tmp61 = tl_math.cos(tmp60)
    tmp62 = tl.full(tmp61.shape, 0.0, tmp61.dtype)
    tmp63 = tl.where(tmp51, tmp61, tmp62)
    tmp66 = tmp6 + tmp65
    tmp67 = tmp66.to(tl.float32)
    tmp69 = tmp68.to(tl.float32)
    tmp70 = tmp67 * tmp69
    tmp71 = tl_math.cos(tmp70)
    tmp72 = tl.where(tmp51, tmp63, tmp71)
    tmp73 = tl.where(tmp46, tmp72, tmp71)
    tmp74 = tl.where(tmp9, tmp44, tmp73)
    tmp75 = tl_math.sin(tmp28)
    tmp76 = tl.full(tmp75.shape, 0.0, tmp75.dtype)
    tmp77 = tl.where(tmp19, tmp75, tmp76)
    tmp78 = tl_math.sin(tmp39)
    tmp79 = tl.where(tmp18, tmp77, tmp78)
    tmp80 = tl.where(tmp12, tmp79, tmp78)
    tmp81 = tl.full(tmp80.shape, 0.0, tmp80.dtype)
    tmp82 = tl.where(tmp9, tmp80, tmp81)
    tmp83 = tl_math.sin(tmp60)
    tmp84 = tl.full(tmp83.shape, 0.0, tmp83.dtype)
    tmp85 = tl.where(tmp51, tmp83, tmp84)
    tmp86 = tl_math.sin(tmp70)
    tmp87 = tl.where(tmp51, tmp85, tmp86)
    tmp88 = tl.where(tmp46, tmp87, tmp86)
    tmp89 = tl.where(tmp9, tmp82, tmp88)
    tl.store(out_ptr0 + (x0), tmp74, xmask)
    tl.store(out_ptr1 + (x0), tmp89, xmask)
''', device_str='cuda')


# kernel path: /tmp/infer-opt-models/q35moe-round-profile-20261109/inductor/fu/cfumtn65oc4raod3vuri6bpgfe3joyle527y2o6jeff2d3mcr2de.py
# Topologically Sorted Source Nodes: [arange, positions, view, expand, position_ids, getitem, float_1, to, freqs, cos, getitem_2, sin, getitem_5, float_8, pow_4, mean_3, add_7, rsqrt_3, output_6, float_9, add_8, output_7, type_as_3, query_states_1, q_rot, cos_1, cos_2, cos_3, mul_11, x2, neg, x1, cat_3, sin_1, sin_2, sin_3, mul_12, q_embed], Original ATen: [aten.arange, aten.add, aten.view, aten.expand, aten.unsqueeze, aten._to_copy, aten.mul, aten.cos, aten.select, aten.slice, aten.sin, aten.split_with_sizes, aten.split, aten.pow, aten.mean, aten.rsqrt, aten.transpose, aten.cat, aten.neg]
# Source node to ATen node mapping:
#   add_7 => add_7
#   add_8 => add_8
#   arange => iota
#   cat_3 => cat_1
#   cos => cos
#   cos_1 => clone, expand_2, select_11, unsqueeze_1, view_1
#   cos_2 => convert_element_type_2
#   cos_3 => unsqueeze_3
#   expand => expand
#   float_1 => convert_element_type
#   float_8 => convert_element_type_13, split_3, split_with_sizes_5, view_9
#   float_9 => convert_element_type_14
#   freqs => mul
#   getitem => unsqueeze
#   getitem_2 => select_1, slice_1
#   getitem_5 => select_13, slice_9
#   mean_3 => mean_3
#   mul_11 => mul_11
#   mul_12 => mul_12
#   neg => neg
#   output_6 => mul_7
#   output_7 => mul_8
#   position_ids => expand_1
#   positions => add
#   pow_4 => pow_4
#   q_embed => add_11
#   q_rot => slice_17
#   query_states_1 => permute
#   rsqrt_3 => rsqrt_3
#   sin => sin
#   sin_1 => clone_2, expand_3, select_23, unsqueeze_2, view_2
#   sin_2 => convert_element_type_3
#   sin_3 => unsqueeze_4
#   to => convert_element_type_1
#   type_as_3 => convert_element_type_15
#   view => view
#   x1 => slice_21
#   x2 => slice_22
# Graph fragment:
#   %buf10 : Tensor  = PlaceHolder[target=buf10]
#   %buf11 : Tensor "f32[1, 1, 16, 1][16, 16, 1, 16]cuda:0" = PlaceHolder[target=buf11]
#   %arg12_1 : Tensor "bf16[256][1]cuda:0" = PlaceHolder[target=arg12_1]
#   %slice_scatter_default_2 : Tensor "f32[1, 1, 32][32, 32, 1]cuda:0" = PlaceHolder[target=slice_scatter_default_2]
#   %copy_ : Tensor "i64[1][1]cuda:0" = PlaceHolder[target=copy_]
#   %arg3_1 : Tensor "bf16[32][1]cuda:0" = PlaceHolder[target=arg3_1]
#   %mul_11 : Tensor "bf16[1, 16, 1, 64][1024, 64, 1024, 1]cuda:0" = PlaceHolder[target=mul_11]
#   %cat_1 : Tensor "bf16[1, 16, 1, 64][1024, 64, 1024, 1]cuda:0" = PlaceHolder[target=cat_1]
#   %slice_scatter_default_3 : Tensor "f32[1, 1, 32][32, 32, 1]cuda:0" = PlaceHolder[target=slice_scatter_default_3]
#   %iota : Tensor "i64[1][1]cuda:0"[num_users=1] = call_function[target=torch.ops.prims.iota.default](args = (1,), kwargs = {start: 0, step: 1, dtype: torch.int64, device: cuda:0, requires_grad: False})
#   %add : Tensor "i64[1][1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%iota, %arg2_1), kwargs = {})
#   %view : Tensor "i64[1, 1, 1][1, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%add, [1, 1, 1]), kwargs = {})
#   %expand : Tensor "i64[3, 1, 1][0, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.expand.default](args = (%view, [3, 1, 1]), kwargs = {})
#   %expand_1 : Tensor "i64[3, 1, 1][0, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.expand.default](args = (%expand, [3, -1, -1]), kwargs = {})
#   %unsqueeze : Tensor "i64[3, 1, 1, 1][0, 1, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%expand_1, 3), kwargs = {})
#   %convert_element_type : Tensor "f32[3, 1, 1, 1][1, 1, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%unsqueeze, torch.float32), kwargs = {})
#   %convert_element_type_1 : Tensor "f32[32][1]cuda:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%arg3_1, torch.float32), kwargs = {})
#   %mul : Tensor "f32[3, 1, 1, 32][32, 32, 32, 1]cuda:0"[num_users=2] = call_function[target=torch.ops.aten.mul.Tensor](args = (%convert_element_type, %convert_element_type_1), kwargs = {})
#   %cos : Tensor "f32[3, 1, 1, 32][32, 32, 32, 1]cuda:0"[num_users=5] = call_function[target=torch.ops.aten.cos.default](args = (%mul,), kwargs = {})
#   %select_1 : Tensor "f32[1, 1, 32][32, 32, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.select.int](args = (%cos, 0, 1), kwargs = {})
#   %slice_1 : Tensor "f32[1, 1, 11][32, 32, 3]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.slice.Tensor](args = (%select_1, 2, 1, 33, 3), kwargs = {})
#   %select_int : Tensor "f32[1, 1, 32][32, 32, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.select.int](args = (%cos, 0, 0), kwargs = {})
#   %slice_scatter_default : Tensor "f32[1, 1, 32][32, 32, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.slice_scatter.default](args = (%select_int, %slice_1, 2, 1, 33, 3), kwargs = {})
#   %select_scatter_default : Tensor "f32[3, 1, 1, 32][32, 32, 32, 1]cuda:0"[num_users=5] = call_function[target=torch.ops.aten.select_scatter.default](args = (%cos, %slice_scatter_default, 0, 0), kwargs = {})
#   %sin : Tensor "f32[3, 1, 1, 32][32, 32, 32, 1]cuda:0"[num_users=5] = call_function[target=torch.ops.aten.sin.default](args = (%mul,), kwargs = {})
#   %select_13 : Tensor "f32[1, 1, 32][32, 32, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.select.int](args = (%sin, 0, 1), kwargs = {})
#   %slice_9 : Tensor "f32[1, 1, 11][32, 32, 3]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.slice.Tensor](args = (%select_13, 2, 1, 33, 3), kwargs = {})
#   %select_int_1 : Tensor "f32[1, 1, 32][32, 32, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.select.int](args = (%sin, 0, 0), kwargs = {})
#   %slice_scatter_default_1 : Tensor "f32[1, 1, 32][32, 32, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.slice_scatter.default](args = (%select_int_1, %slice_9, 2, 1, 33, 3), kwargs = {})
#   %select_scatter_default_1 : Tensor "f32[3, 1, 1, 32][32, 32, 32, 1]cuda:0"[num_users=5] = call_function[target=torch.ops.aten.select_scatter.default](args = (%sin, %slice_scatter_default_1, 0, 0), kwargs = {})
#   %split_with_sizes_5 : [num_users=1] = call_function[target=torch.ops.aten.split_with_sizes.default](args = (%empty_1, [8192, 512, 512], -1), kwargs = {})
#   %view_9 : Tensor "bf16[1, 1, 16, 512][9216, 9216, 512, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%getitem_23, [1, 1, -1, 512]), kwargs = {})
#   %split_3 : [num_users=1] = call_function[target=torch.ops.aten.split.Tensor](args = (%view_9, 256, -1), kwargs = {})
#   %convert_element_type_13 : Tensor "f32[1, 1, 16, 256][4096, 4096, 256, 1]cuda:0"[num_users=2] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%getitem_26, torch.float32), kwargs = {})
#   %pow_4 : Tensor "f32[1, 1, 16, 256][4096, 4096, 256, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.pow.Tensor_Scalar](args = (%convert_element_type_13, 2), kwargs = {})
#   %mean_3 : Tensor "f32[1, 1, 16, 1][16, 16, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mean.dim](args = (%pow_4, [-1], True), kwargs = {})
#   %add_7 : Tensor "f32[1, 1, 16, 1][16, 16, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%mean_3, 1e-06), kwargs = {})
#   %rsqrt_3 : Tensor "f32[1, 1, 16, 1][16, 16, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.rsqrt.default](args = (%add_7,), kwargs = {})
#   %mul_7 : Tensor "f32[1, 1, 16, 256][4096, 4096, 256, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%convert_element_type_13, %rsqrt_3), kwargs = {})
#   %convert_element_type_14 : Tensor "f32[256][1]cuda:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%arg12_1, torch.float32), kwargs = {})
#   %add_8 : Tensor "f32[256][1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%convert_element_type_14, 1.0), kwargs = {})
#   %mul_8 : Tensor "f32[1, 1, 16, 256][4096, 4096, 256, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%mul_7, %add_8), kwargs = {})
#   %convert_element_type_15 : Tensor "bf16[1, 1, 16, 256][4096, 4096, 256, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%mul_8, torch.bfloat16), kwargs = {})
#   %permute : Tensor "bf16[1, 16, 1, 256][4096, 256, 4096, 1]cuda:0"[num_users=2] = call_function[target=torch.ops.aten.permute.default](args = (%convert_element_type_15, [0, 2, 1, 3]), kwargs = {})
#   %slice_17 : Tensor "bf16[1, 16, 1, 64][4096, 256, 4096, 1]cuda:0"[num_users=3] = call_function[target=torch.ops.aten.slice.Tensor](args = (%permute, 3, 0, 64), kwargs = {})
#   %select_scatter_default_2 : Tensor "f32[3, 1, 1, 32][32, 32, 32, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.select_scatter.default](args = (%select_scatter_default, %slice_scatter_default_2, 0, 0), kwargs = {})
#   %select_11 : Tensor "f32[1, 1, 32][32, 32, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.select.int](args = (%select_scatter_default_2, 0, 0), kwargs = {})
#   %unsqueeze_1 : Tensor "f32[1, 1, 1, 32][32, 32, 32, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%select_11, 2), kwargs = {})
#   %expand_2 : Tensor "f32[1, 1, 2, 32][32, 32, 0, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.expand.default](args = (%unsqueeze_1, [1, 1, 2, 32]), kwargs = {})
#   %clone : Tensor "f32[1, 1, 2, 32][64, 64, 32, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.clone.default](args = (%expand_2,), kwargs = {memory_format: torch.contiguous_format})
#   %view_1 : Tensor "f32[1, 1, 64][64, 64, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%clone, [1, 1, 64]), kwargs = {})
#   %convert_element_type_2 : Tensor "bf16[1, 1, 64][64, 64, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%view_1, torch.bfloat16), kwargs = {})
#   %unsqueeze_3 : Tensor "bf16[1, 1, 1, 64][64, 64, 64, 1]cuda:0"[num_users=2] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%convert_element_type_2, 1), kwargs = {})
#   %mul_11 : Tensor "bf16[1, 16, 1, 64][1024, 64, 1024, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%slice_17, %unsqueeze_3), kwargs = {})
#   %slice_22 : Tensor "bf16[1, 16, 1, 32][4096, 256, 4096, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.slice.Tensor](args = (%slice_17, 3, 32, 9223372036854775807), kwargs = {})
#   %neg : Tensor "bf16[1, 16, 1, 32][512, 32, 32, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.neg.default](args = (%slice_22,), kwargs = {})
#   %slice_21 : Tensor "bf16[1, 16, 1, 32][4096, 256, 4096, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.slice.Tensor](args = (%slice_17, 3, 0, 32), kwargs = {})
#   %cat_1 : Tensor "bf16[1, 16, 1, 64][1024, 64, 64, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.cat.default](args = ([%neg, %slice_21], -1), kwargs = {})
#   %select_scatter_default_3 : Tensor "f32[3, 1, 1, 32][32, 32, 32, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.select_scatter.default](args = (%select_scatter_default_1, %slice_scatter_default_3, 0, 0), kwargs = {})
#   %select_23 : Tensor "f32[1, 1, 32][32, 32, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.select.int](args = (%select_scatter_default_3, 0, 0), kwargs = {})
#   %unsqueeze_2 : Tensor "f32[1, 1, 1, 32][32, 32, 32, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%select_23, 2), kwargs = {})
#   %expand_3 : Tensor "f32[1, 1, 2, 32][32, 32, 0, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.expand.default](args = (%unsqueeze_2, [1, 1, 2, 32]), kwargs = {})
#   %clone_2 : Tensor "f32[1, 1, 2, 32][64, 64, 32, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.clone.default](args = (%expand_3,), kwargs = {memory_format: torch.contiguous_format})
#   %view_2 : Tensor "f32[1, 1, 64][64, 64, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%clone_2, [1, 1, 64]), kwargs = {})
#   %convert_element_type_3 : Tensor "bf16[1, 1, 64][64, 64, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%view_2, torch.bfloat16), kwargs = {})
#   %unsqueeze_4 : Tensor "bf16[1, 1, 1, 64][64, 64, 64, 1]cuda:0"[num_users=2] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%convert_element_type_3, 1), kwargs = {})
#   %mul_12 : Tensor "bf16[1, 16, 1, 64][1024, 64, 64, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%cat_1, %unsqueeze_4), kwargs = {})
#   %add_11 : Tensor "bf16[1, 16, 1, 64][1024, 64, 64, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%mul_11, %mul_12), kwargs = {})
#   return %cat_1,%mul_11,%add_11
triton_poi_fused__to_copy_add_arange_cat_cos_expand_mean_mul_neg_pow_rsqrt_select_sin_slice_split_split_with_sizes_transpose_unsqueeze_view_5 = async_compile.triton('triton_poi_fused__to_copy_add_arange_cat_cos_expand_mean_mul_neg_pow_rsqrt_select_sin_slice_split_split_with_sizes_transpose_unsqueeze_view_5', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.pointwise(
    size_hints={'x': 1024}, 
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*bf16', 'in_ptr1': '*fp32', 'in_ptr2': '*bf16', 'in_ptr3': '*fp32', 'in_ptr4': '*i64', 'in_ptr5': '*bf16', 'in_ptr6': '*fp32', 'out_ptr2': '*bf16', 'xnumel': 'i32', 'XBLOCK': 'constexpr'}, 'device': DeviceProperties(type='cuda', index=0, multi_processor_count=108, cc=80, major=8, regs_per_multiprocessor=65536, max_threads_per_multi_processor=2048, max_threads_per_block=1024, warp_size=32), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]], (3,): [['tt.divisibility', 16]], (4,): [['tt.divisibility', 16]], (5,): [['tt.divisibility', 16]], (6,): [['tt.divisibility', 16]], (7,): [['tt.divisibility', 16]], (8,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'autotune_hints': set(), 'kernel_name': 'triton_poi_fused__to_copy_add_arange_cat_cos_expand_mean_mul_neg_pow_rsqrt_select_sin_slice_split_split_with_sizes_transpose_unsqueeze_view_5', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 15, 'num_store': 1, 'num_reduction': 0, 'backend_hash': 'F7205DDDCE8E401A1728E5D602D369DE155D3FCCD3ACF038A9886E6E0DD93A54', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'max_autotune': True, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': False, 'are_deterministic_algorithms_enabled': False, 'coordinate_descent_tuning': True, 'coordinate_descent_search_radius': 1, 'coordinate_descent_check_all_directions': False, 'tiling_scores': {'x': 4800}},
    min_elem_per_thread=0
)
@triton.jit
def triton_poi_fused__to_copy_add_arange_cat_cos_expand_mean_mul_neg_pow_rsqrt_select_sin_slice_split_split_with_sizes_transpose_unsqueeze_view_5(in_ptr0, in_ptr1, in_ptr2, in_ptr3, in_ptr4, in_ptr5, in_ptr6, out_ptr2, xnumel, XBLOCK : tl.constexpr):
    xnumel = 1024
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:]
    xmask = xindex < xnumel
    x0 = (xindex % 64)
    x1 = xindex // 64
    x2 = xindex
    tmp44 = tl.load(in_ptr0 + (x0 + 512*x1), xmask).to(tl.float32)
    tmp46 = tl.load(in_ptr1 + (x1), xmask, eviction_policy='evict_last')
    tmp53 = tl.load(in_ptr2 + (x0), xmask, eviction_policy='evict_last').to(tl.float32)
    tmp61 = tl.load(in_ptr3 + ((x2 % 32)), xmask, eviction_policy='evict_last')
    tmp80 = tl.load(in_ptr4 + (0))
    tmp81 = tl.broadcast_to(tmp80, [XBLOCK])
    tmp84 = tl.load(in_ptr5 + ((x2 % 32)), xmask, eviction_policy='evict_last').to(tl.float32)
    tmp93 = tl.load(in_ptr6 + ((x2 % 32)), xmask, eviction_policy='evict_last')
    tmp0 = x0
    tmp1 = tl.full([1], 0, tl.int64)
    tmp2 = tmp0 >= tmp1
    tmp3 = tl.full([1], 32, tl.int64)
    tmp4 = tmp0 < tmp3
    tmp5 = tl.load(in_ptr0 + (32 + 512*x1 + (x0)), tmp4 & xmask, eviction_policy='evict_last', other=0.0).to(tl.float32)
    tmp6 = tmp5.to(tl.float32)
    tmp7 = tl.load(in_ptr1 + (x1), tmp4 & xmask, eviction_policy='evict_last', other=0.0)
    tmp8 = tl.full([1], 256.0, tl.float32)
    tmp9 = (tmp7 / tmp8)
    tmp10 = tl.full([1], 1e-06, tl.float32)
    tmp11 = tmp9 + tmp10
    tmp12 = libdevice.rsqrt(tmp11)
    tmp13 = tmp6 * tmp12
    tmp14 = tl.load(in_ptr2 + (32 + (x0)), tmp4 & xmask, eviction_policy='evict_last', other=0.0).to(tl.float32)
    tmp15 = tmp14.to(tl.float32)
    tmp16 = tl.full([1], 1.0, tl.float32)
    tmp17 = tmp15 + tmp16
    tmp18 = tmp13 * tmp17
    tmp19 = tmp18.to(tl.float32)
    tmp20 = -tmp19
    tmp21 = tl.full(tmp20.shape, 0.0, tmp20.dtype)
    tmp22 = tl.where(tmp4, tmp20, tmp21)
    tmp23 = tmp0 >= tmp3
    tmp24 = tl.full([1], 64, tl.int64)
    tmp25 = tmp0 < tmp24
    tmp26 = tl.load(in_ptr0 + (512*x1 + ((-32) + x0)), tmp23 & xmask, eviction_policy='evict_last', other=0.0).to(tl.float32)
    tmp27 = tmp26.to(tl.float32)
    tmp28 = tl.load(in_ptr1 + (x1), tmp23 & xmask, eviction_policy='evict_last', other=0.0)
    tmp29 = tl.full([1], 256.0, tl.float32)
    tmp30 = (tmp28 / tmp29)
    tmp31 = tl.full([1], 1e-06, tl.float32)
    tmp32 = tmp30 + tmp31
    tmp33 = libdevice.rsqrt(tmp32)
    tmp34 = tmp27 * tmp33
    tmp35 = tl.load(in_ptr2 + ((-32) + x0), tmp23 & xmask, eviction_policy='evict_last', other=0.0).to(tl.float32)
    tmp36 = tmp35.to(tl.float32)
    tmp37 = tl.full([1], 1.0, tl.float32)
    tmp38 = tmp36 + tmp37
    tmp39 = tmp34 * tmp38
    tmp40 = tmp39.to(tl.float32)
    tmp41 = tl.full(tmp40.shape, 0.0, tmp40.dtype)
    tmp42 = tl.where(tmp23, tmp40, tmp41)
    tmp43 = tl.where(tmp4, tmp22, tmp42)
    tmp45 = tmp44.to(tl.float32)
    tmp47 = tl.full([1], 256.0, tl.float32)
    tmp48 = (tmp46 / tmp47)
    tmp49 = tl.full([1], 1e-06, tl.float32)
    tmp50 = tmp48 + tmp49
    tmp51 = libdevice.rsqrt(tmp50)
    tmp52 = tmp45 * tmp51
    tmp54 = tmp53.to(tl.float32)
    tmp55 = tl.full([1], 1.0, tl.float32)
    tmp56 = tmp54 + tmp55
    tmp57 = tmp52 * tmp56
    tmp58 = tmp57.to(tl.float32)
    tmp59 = tl.full([1], 0, tl.int32)
    tmp60 = tmp59 == tmp59
    tmp62 = (x2 % 32)
    tmp63 = tl.full([1], 1, tl.int64)
    tmp64 = tmp62 >= tmp63
    tmp65 = (((-1) + ((x0 % 32))) % 3)
    tmp66 = tmp65 == tmp1
    tmp67 = tmp64 & tmp66
    tmp68 = tl.load(in_ptr4 + (0))
    tmp69 = tl.broadcast_to(tmp68, [XBLOCK])
    tmp70 = tl.where(tmp67, tmp69, 0)
    tmp71 = tl.full([1], 0, tl.int64)
    tmp72 = tmp71 + tmp70
    tmp73 = tmp72.to(tl.float32)
    tmp74 = tl.load(in_ptr5 + (1 + 3*(triton_helpers.div_floor_integer((-1) + ((x0 % 32)),  3))), tmp67 & xmask, eviction_policy='evict_last', other=0.0).to(tl.float32)
    tmp75 = tmp74.to(tl.float32)
    tmp76 = tmp73 * tmp75
    tmp77 = tl_math.cos(tmp76)
    tmp78 = tl.full(tmp77.shape, 0.0, tmp77.dtype)
    tmp79 = tl.where(tmp67, tmp77, tmp78)
    tmp82 = tmp1 + tmp81
    tmp83 = tmp82.to(tl.float32)
    tmp85 = tmp84.to(tl.float32)
    tmp86 = tmp83 * tmp85
    tmp87 = tl_math.cos(tmp86)
    tmp88 = tl.where(tmp67, tmp79, tmp87)
    tmp89 = tl.where(tmp60, tmp88, tmp87)
    tmp90 = tl.where(tmp60, tmp61, tmp89)
    tmp91 = tmp90.to(tl.float32)
    tmp92 = tmp58 * tmp91
    tmp94 = tl_math.sin(tmp76)
    tmp95 = tl.full(tmp94.shape, 0.0, tmp94.dtype)
    tmp96 = tl.where(tmp67, tmp94, tmp95)
    tmp97 = tl_math.sin(tmp86)
    tmp98 = tl.where(tmp67, tmp96, tmp97)
    tmp99 = tl.where(tmp60, tmp98, tmp97)
    tmp100 = tl.where(tmp60, tmp93, tmp99)
    tmp101 = tmp100.to(tl.float32)
    tmp102 = tmp43 * tmp101
    tmp103 = tmp92 + tmp102
    tl.store(out_ptr2 + (x0 + 256*x1), tmp103, xmask)
''', device_str='cuda')


# kernel path: /tmp/infer-opt-models/q35moe-round-profile-20261109/inductor/tc/ctc3gqfbijqcmi2aexxbz43w2ibwavnwbqawkme25o5txlldqv6z.py
# Topologically Sorted Source Nodes: [float_8, pow_4, mean_3, add_7, rsqrt_3, output_6, float_9, add_8, output_7, type_as_3, query_states_1, q_pass, query_states_2], Original ATen: [aten.split_with_sizes, aten.view, aten.split, aten._to_copy, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.transpose, aten.slice, aten.cat]
# Source node to ATen node mapping:
#   add_7 => add_7
#   add_8 => add_8
#   float_8 => convert_element_type_13, split_3, split_with_sizes_5, view_9
#   float_9 => convert_element_type_14
#   mean_3 => mean_3
#   output_6 => mul_7
#   output_7 => mul_8
#   pow_4 => pow_4
#   q_pass => slice_18
#   query_states_1 => permute
#   query_states_2 => cat_3
#   rsqrt_3 => rsqrt_3
#   type_as_3 => convert_element_type_15
# Graph fragment:
#   %buf10 : Tensor  = PlaceHolder[target=buf10]
#   %buf11 : Tensor "f32[1, 1, 16, 1][16, 16, 1, 16]cuda:0" = PlaceHolder[target=buf11]
#   %arg12_1 : Tensor "bf16[256][1]cuda:0" = PlaceHolder[target=arg12_1]
#   %split_with_sizes_5 : [num_users=1] = call_function[target=torch.ops.aten.split_with_sizes.default](args = (%empty_1, [8192, 512, 512], -1), kwargs = {})
#   %view_9 : Tensor "bf16[1, 1, 16, 512][9216, 9216, 512, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%getitem_23, [1, 1, -1, 512]), kwargs = {})
#   %split_3 : [num_users=1] = call_function[target=torch.ops.aten.split.Tensor](args = (%view_9, 256, -1), kwargs = {})
#   %convert_element_type_13 : Tensor "f32[1, 1, 16, 256][4096, 4096, 256, 1]cuda:0"[num_users=2] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%getitem_26, torch.float32), kwargs = {})
#   %pow_4 : Tensor "f32[1, 1, 16, 256][4096, 4096, 256, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.pow.Tensor_Scalar](args = (%convert_element_type_13, 2), kwargs = {})
#   %mean_3 : Tensor "f32[1, 1, 16, 1][16, 16, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mean.dim](args = (%pow_4, [-1], True), kwargs = {})
#   %add_7 : Tensor "f32[1, 1, 16, 1][16, 16, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%mean_3, 1e-06), kwargs = {})
#   %rsqrt_3 : Tensor "f32[1, 1, 16, 1][16, 16, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.rsqrt.default](args = (%add_7,), kwargs = {})
#   %mul_7 : Tensor "f32[1, 1, 16, 256][4096, 4096, 256, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%convert_element_type_13, %rsqrt_3), kwargs = {})
#   %convert_element_type_14 : Tensor "f32[256][1]cuda:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%arg12_1, torch.float32), kwargs = {})
#   %add_8 : Tensor "f32[256][1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%convert_element_type_14, 1.0), kwargs = {})
#   %mul_8 : Tensor "f32[1, 1, 16, 256][4096, 4096, 256, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%mul_7, %add_8), kwargs = {})
#   %convert_element_type_15 : Tensor "bf16[1, 1, 16, 256][4096, 4096, 256, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%mul_8, torch.bfloat16), kwargs = {})
#   %permute : Tensor "bf16[1, 16, 1, 256][4096, 256, 4096, 1]cuda:0"[num_users=2] = call_function[target=torch.ops.aten.permute.default](args = (%convert_element_type_15, [0, 2, 1, 3]), kwargs = {})
#   %slice_18 : Tensor "bf16[1, 16, 1, 192][4096, 256, 4096, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.slice.Tensor](args = (%permute, 3, 64, 9223372036854775807), kwargs = {})
#   %cat_3 : Tensor "bf16[1, 16, 1, 256][4096, 256, 256, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.cat.default](args = ([%add_11, %slice_18], -1), kwargs = {})
#   return %buf17
triton_poi_fused__to_copy_add_cat_mean_mul_pow_rsqrt_slice_split_split_with_sizes_transpose_view_6 = async_compile.triton('triton_poi_fused__to_copy_add_cat_mean_mul_pow_rsqrt_slice_split_split_with_sizes_transpose_view_6', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.pointwise(
    size_hints={'x': 4096}, 
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*bf16', 'in_ptr1': '*fp32', 'in_ptr2': '*bf16', 'out_ptr0': '*bf16', 'xnumel': 'i32', 'XBLOCK': 'constexpr'}, 'device': DeviceProperties(type='cuda', index=0, multi_processor_count=108, cc=80, major=8, regs_per_multiprocessor=65536, max_threads_per_multi_processor=2048, max_threads_per_block=1024, warp_size=32), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]], (3,): [['tt.divisibility', 16]], (4,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'autotune_hints': set(), 'kernel_name': 'triton_poi_fused__to_copy_add_cat_mean_mul_pow_rsqrt_slice_split_split_with_sizes_transpose_view_6', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 3, 'num_store': 1, 'num_reduction': 0, 'backend_hash': 'F7205DDDCE8E401A1728E5D602D369DE155D3FCCD3ACF038A9886E6E0DD93A54', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'max_autotune': True, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': False, 'are_deterministic_algorithms_enabled': False, 'coordinate_descent_tuning': True, 'coordinate_descent_search_radius': 1, 'coordinate_descent_check_all_directions': False, 'tiling_scores': {'x': 12672}},
    min_elem_per_thread=0
)
@triton.jit
def triton_poi_fused__to_copy_add_cat_mean_mul_pow_rsqrt_slice_split_split_with_sizes_transpose_view_6(in_ptr0, in_ptr1, in_ptr2, out_ptr0, xnumel, XBLOCK : tl.constexpr):
    xnumel = 3072
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:]
    xmask = xindex < xnumel
    x0 = (xindex % 192)
    x1 = xindex // 192
    tmp0 = tl.load(in_ptr0 + (64 + x0 + 512*x1), xmask).to(tl.float32)
    tmp2 = tl.load(in_ptr1 + (x1), xmask, eviction_policy='evict_last')
    tmp9 = tl.load(in_ptr2 + (64 + x0), xmask, eviction_policy='evict_last').to(tl.float32)
    tmp1 = tmp0.to(tl.float32)
    tmp3 = tl.full([1], 256.0, tl.float32)
    tmp4 = (tmp2 / tmp3)
    tmp5 = tl.full([1], 1e-06, tl.float32)
    tmp6 = tmp4 + tmp5
    tmp7 = libdevice.rsqrt(tmp6)
    tmp8 = tmp1 * tmp7
    tmp10 = tmp9.to(tl.float32)
    tmp11 = tl.full([1], 1.0, tl.float32)
    tmp12 = tmp10 + tmp11
    tmp13 = tmp8 * tmp12
    tmp14 = tmp13.to(tl.float32)
    tl.store(out_ptr0 + (x0 + 256*x1), tmp14, xmask)
''', device_str='cuda')


# kernel path: /tmp/infer-opt-models/q35moe-round-profile-20261109/inductor/pc/cpc44hb3u2t27tvx3ryd7tl7c447xe2vfn4356oq72gjrvckyvdq.py
# Topologically Sorted Source Nodes: [float_10, pow_5, mean_4], Original ATen: [aten.split_with_sizes, aten.view, aten._to_copy, aten.pow, aten.mean]
# Source node to ATen node mapping:
#   float_10 => convert_element_type_16, split_with_sizes_7, view_12
#   mean_4 => mean_4
#   pow_5 => pow_5
# Graph fragment:
#   %buf10 : Tensor  = PlaceHolder[target=buf10]
#   %split_with_sizes_7 : [num_users=1] = call_function[target=torch.ops.aten.split_with_sizes.default](args = (%empty_1, [8192, 512, 512], -1), kwargs = {})
#   %view_12 : Tensor "bf16[1, 1, 2, 256][9216, 9216, 256, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%getitem_32, [1, 1, -1, 256]), kwargs = {})
#   %convert_element_type_16 : Tensor "f32[1, 1, 2, 256][9216, 9216, 256, 1]cuda:0"[num_users=2] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%view_12, torch.float32), kwargs = {})
#   %pow_5 : Tensor "f32[1, 1, 2, 256][512, 512, 256, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.pow.Tensor_Scalar](args = (%convert_element_type_16, 2), kwargs = {})
#   %mean_4 : Tensor "f32[1, 1, 2, 1][2, 2, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mean.dim](args = (%pow_5, [-1], True), kwargs = {})
#   return %buf19
triton_per_fused__to_copy_mean_pow_split_with_sizes_view_7 = async_compile.triton('triton_per_fused__to_copy_mean_pow_split_with_sizes_view_7', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.persistent_reduction(
    size_hints={'x': 2, 'r0_': 256},
    reduction_hint=ReductionHint.INNER,
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*bf16', 'out_ptr0': '*fp32', 'xnumel': 'i32', 'r0_numel': 'i32', 'XBLOCK': 'constexpr'}, 'device': DeviceProperties(type='cuda', index=0, multi_processor_count=108, cc=80, major=8, regs_per_multiprocessor=65536, max_threads_per_multi_processor=2048, max_threads_per_block=1024, warp_size=32), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (3,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'autotune_hints': set(), 'kernel_name': 'triton_per_fused__to_copy_mean_pow_split_with_sizes_view_7', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': None, 'atomic_add_found': False, 'num_load': 1, 'num_store': 1, 'num_reduction': 1, 'backend_hash': 'F7205DDDCE8E401A1728E5D602D369DE155D3FCCD3ACF038A9886E6E0DD93A54', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'max_autotune': True, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': False, 'are_deterministic_algorithms_enabled': False, 'coordinate_descent_tuning': True, 'coordinate_descent_search_radius': 1, 'coordinate_descent_check_all_directions': False, 'tiling_scores': {'x': 4, 'r0_': 0}}
)
@triton.jit
def triton_per_fused__to_copy_mean_pow_split_with_sizes_view_7(in_ptr0, out_ptr0, xnumel, r0_numel, XBLOCK : tl.constexpr):
    xnumel = 2
    r0_numel = 256
    R0_BLOCK: tl.constexpr = 256
    rnumel = r0_numel
    RBLOCK: tl.constexpr = R0_BLOCK
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:, None]
    xmask = xindex < xnumel
    r0_index = tl.arange(0, R0_BLOCK)[None, :]
    r0_offset = 0
    r0_mask = tl.full([R0_BLOCK], True, tl.int1)[None, :]
    roffset = r0_offset
    rindex = r0_index
    r0_1 = r0_index
    x0 = xindex
    tmp0 = tl.load(in_ptr0 + (8192 + r0_1 + 256*x0), xmask, other=0.0).to(tl.float32)
    tmp1 = tmp0.to(tl.float32)
    tmp2 = tmp1 * tmp1
    tmp3 = tl.broadcast_to(tmp2, [XBLOCK, R0_BLOCK])
    tmp5 = tl.where(xmask, tmp3, 0)
    tmp6 = tl.sum(tmp5, 1)[:, None].to(tl.float32)
    tl.store(out_ptr0 + (x0), tmp6, xmask)
''', device_str='cuda')


# kernel path: /tmp/infer-opt-models/q35moe-round-profile-20261109/inductor/as/casvdjmbm7kbhvygz5ft75sdjmuendmdysnnkd3yi3ywdvxgs4zb.py
# Topologically Sorted Source Nodes: [arange, positions, view, expand, position_ids, getitem, float_1, to, freqs, cos, getitem_2, sin, getitem_5, float_10, cos_1, cos_2, cos_3, sin_1, sin_2, sin_3, pow_5, mean_4, add_9, rsqrt_4, output_8, float_11, add_10, output_9, type_as_4, key_states, k_rot, mul_13, x2_1, neg_1, x1_1, cat_4, mul_14, k_embed], Original ATen: [aten.arange, aten.add, aten.view, aten.expand, aten.unsqueeze, aten._to_copy, aten.mul, aten.cos, aten.select, aten.slice, aten.sin, aten.split_with_sizes, aten.cat, aten.pow, aten.mean, aten.rsqrt, aten.transpose, aten.neg]
# Source node to ATen node mapping:
#   add_10 => add_10
#   add_9 => add_9
#   arange => iota
#   cat_4 => cat_2
#   cos => cos
#   cos_1 => clone, expand_2, select_11, unsqueeze_1, view_1
#   cos_2 => convert_element_type_2
#   cos_3 => unsqueeze_3
#   expand => expand
#   float_1 => convert_element_type
#   float_10 => convert_element_type_16, split_with_sizes_7, view_12
#   float_11 => convert_element_type_17
#   freqs => mul
#   getitem => unsqueeze
#   getitem_2 => select_1, slice_1
#   getitem_5 => select_13, slice_9
#   k_embed => add_12
#   k_rot => slice_19
#   key_states => permute_1
#   mean_4 => mean_4
#   mul_13 => mul_13
#   mul_14 => mul_14
#   neg_1 => neg_1
#   output_8 => mul_9
#   output_9 => mul_10
#   position_ids => expand_1
#   positions => add
#   pow_5 => pow_5
#   rsqrt_4 => rsqrt_4
#   sin => sin
#   sin_1 => clone_2, expand_3, select_23, unsqueeze_2, view_2
#   sin_2 => convert_element_type_3
#   sin_3 => unsqueeze_4
#   to => convert_element_type_1
#   type_as_4 => convert_element_type_18
#   view => view
#   x1_1 => slice_23
#   x2_1 => slice_24
# Graph fragment:
#   %buf10 : Tensor  = PlaceHolder[target=buf10]
#   %buf19 : Tensor "f32[1, 1, 2, 1][2, 2, 1, 2]cuda:0" = PlaceHolder[target=buf19]
#   %arg13_1 : Tensor "bf16[256][1]cuda:0" = PlaceHolder[target=arg13_1]
#   %slice_scatter_default_2 : Tensor "f32[1, 1, 32][32, 32, 1]cuda:0" = PlaceHolder[target=slice_scatter_default_2]
#   %copy_ : Tensor "i64[1][1]cuda:0" = PlaceHolder[target=copy_]
#   %arg3_1 : Tensor "bf16[32][1]cuda:0" = PlaceHolder[target=arg3_1]
#   %mul_13 : Tensor "bf16[1, 2, 1, 64][128, 64, 128, 1]cuda:0" = PlaceHolder[target=mul_13]
#   %cat_2 : Tensor "bf16[1, 2, 1, 64][128, 64, 128, 1]cuda:0" = PlaceHolder[target=cat_2]
#   %slice_scatter_default_3 : Tensor "f32[1, 1, 32][32, 32, 1]cuda:0" = PlaceHolder[target=slice_scatter_default_3]
#   %iota : Tensor "i64[1][1]cuda:0"[num_users=1] = call_function[target=torch.ops.prims.iota.default](args = (1,), kwargs = {start: 0, step: 1, dtype: torch.int64, device: cuda:0, requires_grad: False})
#   %add : Tensor "i64[1][1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%iota, %arg2_1), kwargs = {})
#   %view : Tensor "i64[1, 1, 1][1, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%add, [1, 1, 1]), kwargs = {})
#   %expand : Tensor "i64[3, 1, 1][0, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.expand.default](args = (%view, [3, 1, 1]), kwargs = {})
#   %expand_1 : Tensor "i64[3, 1, 1][0, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.expand.default](args = (%expand, [3, -1, -1]), kwargs = {})
#   %unsqueeze : Tensor "i64[3, 1, 1, 1][0, 1, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%expand_1, 3), kwargs = {})
#   %convert_element_type : Tensor "f32[3, 1, 1, 1][1, 1, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%unsqueeze, torch.float32), kwargs = {})
#   %convert_element_type_1 : Tensor "f32[32][1]cuda:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%arg3_1, torch.float32), kwargs = {})
#   %mul : Tensor "f32[3, 1, 1, 32][32, 32, 32, 1]cuda:0"[num_users=2] = call_function[target=torch.ops.aten.mul.Tensor](args = (%convert_element_type, %convert_element_type_1), kwargs = {})
#   %cos : Tensor "f32[3, 1, 1, 32][32, 32, 32, 1]cuda:0"[num_users=5] = call_function[target=torch.ops.aten.cos.default](args = (%mul,), kwargs = {})
#   %select_1 : Tensor "f32[1, 1, 32][32, 32, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.select.int](args = (%cos, 0, 1), kwargs = {})
#   %slice_1 : Tensor "f32[1, 1, 11][32, 32, 3]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.slice.Tensor](args = (%select_1, 2, 1, 33, 3), kwargs = {})
#   %select_int : Tensor "f32[1, 1, 32][32, 32, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.select.int](args = (%cos, 0, 0), kwargs = {})
#   %slice_scatter_default : Tensor "f32[1, 1, 32][32, 32, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.slice_scatter.default](args = (%select_int, %slice_1, 2, 1, 33, 3), kwargs = {})
#   %select_scatter_default : Tensor "f32[3, 1, 1, 32][32, 32, 32, 1]cuda:0"[num_users=5] = call_function[target=torch.ops.aten.select_scatter.default](args = (%cos, %slice_scatter_default, 0, 0), kwargs = {})
#   %sin : Tensor "f32[3, 1, 1, 32][32, 32, 32, 1]cuda:0"[num_users=5] = call_function[target=torch.ops.aten.sin.default](args = (%mul,), kwargs = {})
#   %select_13 : Tensor "f32[1, 1, 32][32, 32, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.select.int](args = (%sin, 0, 1), kwargs = {})
#   %slice_9 : Tensor "f32[1, 1, 11][32, 32, 3]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.slice.Tensor](args = (%select_13, 2, 1, 33, 3), kwargs = {})
#   %select_int_1 : Tensor "f32[1, 1, 32][32, 32, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.select.int](args = (%sin, 0, 0), kwargs = {})
#   %slice_scatter_default_1 : Tensor "f32[1, 1, 32][32, 32, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.slice_scatter.default](args = (%select_int_1, %slice_9, 2, 1, 33, 3), kwargs = {})
#   %select_scatter_default_1 : Tensor "f32[3, 1, 1, 32][32, 32, 32, 1]cuda:0"[num_users=5] = call_function[target=torch.ops.aten.select_scatter.default](args = (%sin, %slice_scatter_default_1, 0, 0), kwargs = {})
#   %split_with_sizes_7 : [num_users=1] = call_function[target=torch.ops.aten.split_with_sizes.default](args = (%empty_1, [8192, 512, 512], -1), kwargs = {})
#   %select_scatter_default_2 : Tensor "f32[3, 1, 1, 32][32, 32, 32, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.select_scatter.default](args = (%select_scatter_default, %slice_scatter_default_2, 0, 0), kwargs = {})
#   %select_11 : Tensor "f32[1, 1, 32][32, 32, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.select.int](args = (%select_scatter_default_2, 0, 0), kwargs = {})
#   %unsqueeze_1 : Tensor "f32[1, 1, 1, 32][32, 32, 32, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%select_11, 2), kwargs = {})
#   %expand_2 : Tensor "f32[1, 1, 2, 32][32, 32, 0, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.expand.default](args = (%unsqueeze_1, [1, 1, 2, 32]), kwargs = {})
#   %clone : Tensor "f32[1, 1, 2, 32][64, 64, 32, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.clone.default](args = (%expand_2,), kwargs = {memory_format: torch.contiguous_format})
#   %view_1 : Tensor "f32[1, 1, 64][64, 64, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%clone, [1, 1, 64]), kwargs = {})
#   %convert_element_type_2 : Tensor "bf16[1, 1, 64][64, 64, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%view_1, torch.bfloat16), kwargs = {})
#   %unsqueeze_3 : Tensor "bf16[1, 1, 1, 64][64, 64, 64, 1]cuda:0"[num_users=2] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%convert_element_type_2, 1), kwargs = {})
#   %select_scatter_default_3 : Tensor "f32[3, 1, 1, 32][32, 32, 32, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.select_scatter.default](args = (%select_scatter_default_1, %slice_scatter_default_3, 0, 0), kwargs = {})
#   %select_23 : Tensor "f32[1, 1, 32][32, 32, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.select.int](args = (%select_scatter_default_3, 0, 0), kwargs = {})
#   %unsqueeze_2 : Tensor "f32[1, 1, 1, 32][32, 32, 32, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%select_23, 2), kwargs = {})
#   %expand_3 : Tensor "f32[1, 1, 2, 32][32, 32, 0, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.expand.default](args = (%unsqueeze_2, [1, 1, 2, 32]), kwargs = {})
#   %clone_2 : Tensor "f32[1, 1, 2, 32][64, 64, 32, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.clone.default](args = (%expand_3,), kwargs = {memory_format: torch.contiguous_format})
#   %view_2 : Tensor "f32[1, 1, 64][64, 64, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%clone_2, [1, 1, 64]), kwargs = {})
#   %convert_element_type_3 : Tensor "bf16[1, 1, 64][64, 64, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%view_2, torch.bfloat16), kwargs = {})
#   %unsqueeze_4 : Tensor "bf16[1, 1, 1, 64][64, 64, 64, 1]cuda:0"[num_users=2] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%convert_element_type_3, 1), kwargs = {})
#   %view_12 : Tensor "bf16[1, 1, 2, 256][9216, 9216, 256, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%getitem_32, [1, 1, -1, 256]), kwargs = {})
#   %convert_element_type_16 : Tensor "f32[1, 1, 2, 256][9216, 9216, 256, 1]cuda:0"[num_users=2] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%view_12, torch.float32), kwargs = {})
#   %pow_5 : Tensor "f32[1, 1, 2, 256][512, 512, 256, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.pow.Tensor_Scalar](args = (%convert_element_type_16, 2), kwargs = {})
#   %mean_4 : Tensor "f32[1, 1, 2, 1][2, 2, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mean.dim](args = (%pow_5, [-1], True), kwargs = {})
#   %add_9 : Tensor "f32[1, 1, 2, 1][2, 2, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%mean_4, 1e-06), kwargs = {})
#   %rsqrt_4 : Tensor "f32[1, 1, 2, 1][2, 2, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.rsqrt.default](args = (%add_9,), kwargs = {})
#   %mul_9 : Tensor "f32[1, 1, 2, 256][512, 512, 256, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%convert_element_type_16, %rsqrt_4), kwargs = {})
#   %convert_element_type_17 : Tensor "f32[256][1]cuda:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%arg13_1, torch.float32), kwargs = {})
#   %add_10 : Tensor "f32[256][1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%convert_element_type_17, 1.0), kwargs = {})
#   %mul_10 : Tensor "f32[1, 1, 2, 256][512, 512, 256, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%mul_9, %add_10), kwargs = {})
#   %convert_element_type_18 : Tensor "bf16[1, 1, 2, 256][512, 512, 256, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%mul_10, torch.bfloat16), kwargs = {})
#   %permute_1 : Tensor "bf16[1, 2, 1, 256][512, 256, 512, 1]cuda:0"[num_users=2] = call_function[target=torch.ops.aten.permute.default](args = (%convert_element_type_18, [0, 2, 1, 3]), kwargs = {})
#   %slice_19 : Tensor "bf16[1, 2, 1, 64][512, 256, 512, 1]cuda:0"[num_users=3] = call_function[target=torch.ops.aten.slice.Tensor](args = (%permute_1, 3, 0, 64), kwargs = {})
#   %mul_13 : Tensor "bf16[1, 2, 1, 64][128, 64, 128, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%slice_19, %unsqueeze_3), kwargs = {})
#   %slice_24 : Tensor "bf16[1, 2, 1, 32][512, 256, 512, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.slice.Tensor](args = (%slice_19, 3, 32, 9223372036854775807), kwargs = {})
#   %neg_1 : Tensor "bf16[1, 2, 1, 32][64, 32, 32, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.neg.default](args = (%slice_24,), kwargs = {})
#   %slice_23 : Tensor "bf16[1, 2, 1, 32][512, 256, 512, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.slice.Tensor](args = (%slice_19, 3, 0, 32), kwargs = {})
#   %cat_2 : Tensor "bf16[1, 2, 1, 64][128, 64, 64, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.cat.default](args = ([%neg_1, %slice_23], -1), kwargs = {})
#   %mul_14 : Tensor "bf16[1, 2, 1, 64][128, 64, 64, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%cat_2, %unsqueeze_4), kwargs = {})
#   %add_12 : Tensor "bf16[1, 2, 1, 64][128, 64, 64, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%mul_13, %mul_14), kwargs = {})
#   return %cat_2,%mul_13,%add_12
triton_poi_fused__to_copy_add_arange_cat_cos_expand_mean_mul_neg_pow_rsqrt_select_sin_slice_split_with_sizes_transpose_unsqueeze_view_8 = async_compile.triton('triton_poi_fused__to_copy_add_arange_cat_cos_expand_mean_mul_neg_pow_rsqrt_select_sin_slice_split_with_sizes_transpose_unsqueeze_view_8', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.pointwise(
    size_hints={'x': 128}, 
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*bf16', 'in_ptr1': '*fp32', 'in_ptr2': '*bf16', 'in_ptr3': '*fp32', 'in_ptr4': '*i64', 'in_ptr5': '*bf16', 'in_ptr6': '*fp32', 'out_ptr2': '*bf16', 'xnumel': 'i32', 'XBLOCK': 'constexpr'}, 'device': DeviceProperties(type='cuda', index=0, multi_processor_count=108, cc=80, major=8, regs_per_multiprocessor=65536, max_threads_per_multi_processor=2048, max_threads_per_block=1024, warp_size=32), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]], (3,): [['tt.divisibility', 16]], (4,): [['tt.divisibility', 16]], (5,): [['tt.divisibility', 16]], (6,): [['tt.divisibility', 16]], (7,): [['tt.divisibility', 16]], (8,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'autotune_hints': set(), 'kernel_name': 'triton_poi_fused__to_copy_add_arange_cat_cos_expand_mean_mul_neg_pow_rsqrt_select_sin_slice_split_with_sizes_transpose_unsqueeze_view_8', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 15, 'num_store': 1, 'num_reduction': 0, 'backend_hash': 'F7205DDDCE8E401A1728E5D602D369DE155D3FCCD3ACF038A9886E6E0DD93A54', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'max_autotune': True, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': False, 'are_deterministic_algorithms_enabled': False, 'coordinate_descent_tuning': True, 'coordinate_descent_search_radius': 1, 'coordinate_descent_check_all_directions': False, 'tiling_scores': {'x': 1216}},
    min_elem_per_thread=0
)
@triton.jit
def triton_poi_fused__to_copy_add_arange_cat_cos_expand_mean_mul_neg_pow_rsqrt_select_sin_slice_split_with_sizes_transpose_unsqueeze_view_8(in_ptr0, in_ptr1, in_ptr2, in_ptr3, in_ptr4, in_ptr5, in_ptr6, out_ptr2, xnumel, XBLOCK : tl.constexpr):
    xnumel = 128
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:]
    xmask = xindex < xnumel
    x0 = (xindex % 64)
    x1 = xindex // 64
    x2 = xindex
    tmp44 = tl.load(in_ptr0 + (8192 + x0 + 256*x1), xmask).to(tl.float32)
    tmp46 = tl.load(in_ptr1 + (x1), xmask, eviction_policy='evict_last')
    tmp53 = tl.load(in_ptr2 + (x0), xmask, eviction_policy='evict_last').to(tl.float32)
    tmp61 = tl.load(in_ptr3 + ((x2 % 32)), xmask, eviction_policy='evict_last')
    tmp80 = tl.load(in_ptr4 + (0))
    tmp81 = tl.broadcast_to(tmp80, [XBLOCK])
    tmp84 = tl.load(in_ptr5 + ((x2 % 32)), xmask, eviction_policy='evict_last').to(tl.float32)
    tmp93 = tl.load(in_ptr6 + ((x2 % 32)), xmask, eviction_policy='evict_last')
    tmp0 = x0
    tmp1 = tl.full([1], 0, tl.int64)
    tmp2 = tmp0 >= tmp1
    tmp3 = tl.full([1], 32, tl.int64)
    tmp4 = tmp0 < tmp3
    tmp5 = tl.load(in_ptr0 + (8224 + 256*x1 + (x0)), tmp4 & xmask, eviction_policy='evict_last', other=0.0).to(tl.float32)
    tmp6 = tmp5.to(tl.float32)
    tmp7 = tl.load(in_ptr1 + (x1), tmp4 & xmask, eviction_policy='evict_last', other=0.0)
    tmp8 = tl.full([1], 256.0, tl.float32)
    tmp9 = (tmp7 / tmp8)
    tmp10 = tl.full([1], 1e-06, tl.float32)
    tmp11 = tmp9 + tmp10
    tmp12 = libdevice.rsqrt(tmp11)
    tmp13 = tmp6 * tmp12
    tmp14 = tl.load(in_ptr2 + (32 + (x0)), tmp4 & xmask, eviction_policy='evict_last', other=0.0).to(tl.float32)
    tmp15 = tmp14.to(tl.float32)
    tmp16 = tl.full([1], 1.0, tl.float32)
    tmp17 = tmp15 + tmp16
    tmp18 = tmp13 * tmp17
    tmp19 = tmp18.to(tl.float32)
    tmp20 = -tmp19
    tmp21 = tl.full(tmp20.shape, 0.0, tmp20.dtype)
    tmp22 = tl.where(tmp4, tmp20, tmp21)
    tmp23 = tmp0 >= tmp3
    tmp24 = tl.full([1], 64, tl.int64)
    tmp25 = tmp0 < tmp24
    tmp26 = tl.load(in_ptr0 + (8192 + 256*x1 + ((-32) + x0)), tmp23 & xmask, eviction_policy='evict_last', other=0.0).to(tl.float32)
    tmp27 = tmp26.to(tl.float32)
    tmp28 = tl.load(in_ptr1 + (x1), tmp23 & xmask, eviction_policy='evict_last', other=0.0)
    tmp29 = tl.full([1], 256.0, tl.float32)
    tmp30 = (tmp28 / tmp29)
    tmp31 = tl.full([1], 1e-06, tl.float32)
    tmp32 = tmp30 + tmp31
    tmp33 = libdevice.rsqrt(tmp32)
    tmp34 = tmp27 * tmp33
    tmp35 = tl.load(in_ptr2 + ((-32) + x0), tmp23 & xmask, eviction_policy='evict_last', other=0.0).to(tl.float32)
    tmp36 = tmp35.to(tl.float32)
    tmp37 = tl.full([1], 1.0, tl.float32)
    tmp38 = tmp36 + tmp37
    tmp39 = tmp34 * tmp38
    tmp40 = tmp39.to(tl.float32)
    tmp41 = tl.full(tmp40.shape, 0.0, tmp40.dtype)
    tmp42 = tl.where(tmp23, tmp40, tmp41)
    tmp43 = tl.where(tmp4, tmp22, tmp42)
    tmp45 = tmp44.to(tl.float32)
    tmp47 = tl.full([1], 256.0, tl.float32)
    tmp48 = (tmp46 / tmp47)
    tmp49 = tl.full([1], 1e-06, tl.float32)
    tmp50 = tmp48 + tmp49
    tmp51 = libdevice.rsqrt(tmp50)
    tmp52 = tmp45 * tmp51
    tmp54 = tmp53.to(tl.float32)
    tmp55 = tl.full([1], 1.0, tl.float32)
    tmp56 = tmp54 + tmp55
    tmp57 = tmp52 * tmp56
    tmp58 = tmp57.to(tl.float32)
    tmp59 = tl.full([1], 0, tl.int32)
    tmp60 = tmp59 == tmp59
    tmp62 = (x2 % 32)
    tmp63 = tl.full([1], 1, tl.int64)
    tmp64 = tmp62 >= tmp63
    tmp65 = (((-1) + ((x0 % 32))) % 3)
    tmp66 = tmp65 == tmp1
    tmp67 = tmp64 & tmp66
    tmp68 = tl.load(in_ptr4 + (0))
    tmp69 = tl.broadcast_to(tmp68, [XBLOCK])
    tmp70 = tl.where(tmp67, tmp69, 0)
    tmp71 = tl.full([1], 0, tl.int64)
    tmp72 = tmp71 + tmp70
    tmp73 = tmp72.to(tl.float32)
    tmp74 = tl.load(in_ptr5 + (1 + 3*(triton_helpers.div_floor_integer((-1) + ((x0 % 32)),  3))), tmp67 & xmask, eviction_policy='evict_last', other=0.0).to(tl.float32)
    tmp75 = tmp74.to(tl.float32)
    tmp76 = tmp73 * tmp75
    tmp77 = tl_math.cos(tmp76)
    tmp78 = tl.full(tmp77.shape, 0.0, tmp77.dtype)
    tmp79 = tl.where(tmp67, tmp77, tmp78)
    tmp82 = tmp1 + tmp81
    tmp83 = tmp82.to(tl.float32)
    tmp85 = tmp84.to(tl.float32)
    tmp86 = tmp83 * tmp85
    tmp87 = tl_math.cos(tmp86)
    tmp88 = tl.where(tmp67, tmp79, tmp87)
    tmp89 = tl.where(tmp60, tmp88, tmp87)
    tmp90 = tl.where(tmp60, tmp61, tmp89)
    tmp91 = tmp90.to(tl.float32)
    tmp92 = tmp58 * tmp91
    tmp94 = tl_math.sin(tmp76)
    tmp95 = tl.full(tmp94.shape, 0.0, tmp94.dtype)
    tmp96 = tl.where(tmp67, tmp94, tmp95)
    tmp97 = tl_math.sin(tmp86)
    tmp98 = tl.where(tmp67, tmp96, tmp97)
    tmp99 = tl.where(tmp60, tmp98, tmp97)
    tmp100 = tl.where(tmp60, tmp93, tmp99)
    tmp101 = tmp100.to(tl.float32)
    tmp102 = tmp43 * tmp101
    tmp103 = tmp92 + tmp102
    tl.store(out_ptr2 + (x0 + 256*x1), tmp103, xmask)
''', device_str='cuda')


# kernel path: /tmp/infer-opt-models/q35moe-round-profile-20261109/inductor/nq/cnqlbhgyysyoyvysf6wfhmy5dqqio2yeaeuuwcmbpis77r4hqtor.py
# Topologically Sorted Source Nodes: [float_10, pow_5, mean_4, add_9, rsqrt_4, output_8, float_11, add_10, output_9, type_as_4, key_states, k_pass, key_states_1], Original ATen: [aten.split_with_sizes, aten.view, aten._to_copy, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.transpose, aten.slice, aten.cat]
# Source node to ATen node mapping:
#   add_10 => add_10
#   add_9 => add_9
#   float_10 => convert_element_type_16, split_with_sizes_7, view_12
#   float_11 => convert_element_type_17
#   k_pass => slice_20
#   key_states => permute_1
#   key_states_1 => cat_4
#   mean_4 => mean_4
#   output_8 => mul_9
#   output_9 => mul_10
#   pow_5 => pow_5
#   rsqrt_4 => rsqrt_4
#   type_as_4 => convert_element_type_18
# Graph fragment:
#   %buf10 : Tensor  = PlaceHolder[target=buf10]
#   %buf19 : Tensor "f32[1, 1, 2, 1][2, 2, 1, 2]cuda:0" = PlaceHolder[target=buf19]
#   %arg13_1 : Tensor "bf16[256][1]cuda:0" = PlaceHolder[target=arg13_1]
#   %split_with_sizes_7 : [num_users=1] = call_function[target=torch.ops.aten.split_with_sizes.default](args = (%empty_1, [8192, 512, 512], -1), kwargs = {})
#   %view_12 : Tensor "bf16[1, 1, 2, 256][9216, 9216, 256, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%getitem_32, [1, 1, -1, 256]), kwargs = {})
#   %convert_element_type_16 : Tensor "f32[1, 1, 2, 256][9216, 9216, 256, 1]cuda:0"[num_users=2] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%view_12, torch.float32), kwargs = {})
#   %pow_5 : Tensor "f32[1, 1, 2, 256][512, 512, 256, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.pow.Tensor_Scalar](args = (%convert_element_type_16, 2), kwargs = {})
#   %mean_4 : Tensor "f32[1, 1, 2, 1][2, 2, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mean.dim](args = (%pow_5, [-1], True), kwargs = {})
#   %add_9 : Tensor "f32[1, 1, 2, 1][2, 2, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%mean_4, 1e-06), kwargs = {})
#   %rsqrt_4 : Tensor "f32[1, 1, 2, 1][2, 2, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.rsqrt.default](args = (%add_9,), kwargs = {})
#   %mul_9 : Tensor "f32[1, 1, 2, 256][512, 512, 256, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%convert_element_type_16, %rsqrt_4), kwargs = {})
#   %convert_element_type_17 : Tensor "f32[256][1]cuda:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%arg13_1, torch.float32), kwargs = {})
#   %add_10 : Tensor "f32[256][1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%convert_element_type_17, 1.0), kwargs = {})
#   %mul_10 : Tensor "f32[1, 1, 2, 256][512, 512, 256, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%mul_9, %add_10), kwargs = {})
#   %convert_element_type_18 : Tensor "bf16[1, 1, 2, 256][512, 512, 256, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%mul_10, torch.bfloat16), kwargs = {})
#   %permute_1 : Tensor "bf16[1, 2, 1, 256][512, 256, 512, 1]cuda:0"[num_users=2] = call_function[target=torch.ops.aten.permute.default](args = (%convert_element_type_18, [0, 2, 1, 3]), kwargs = {})
#   %slice_20 : Tensor "bf16[1, 2, 1, 192][512, 256, 512, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.slice.Tensor](args = (%permute_1, 3, 64, 9223372036854775807), kwargs = {})
#   %cat_4 : Tensor "bf16[1, 2, 1, 256][512, 256, 256, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.cat.default](args = ([%add_12, %slice_20], -1), kwargs = {})
#   return %buf23
triton_poi_fused__to_copy_add_cat_mean_mul_pow_rsqrt_slice_split_with_sizes_transpose_view_9 = async_compile.triton('triton_poi_fused__to_copy_add_cat_mean_mul_pow_rsqrt_slice_split_with_sizes_transpose_view_9', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.pointwise(
    size_hints={'x': 512}, 
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*bf16', 'in_ptr1': '*fp32', 'in_ptr2': '*bf16', 'out_ptr0': '*bf16', 'xnumel': 'i32', 'XBLOCK': 'constexpr'}, 'device': DeviceProperties(type='cuda', index=0, multi_processor_count=108, cc=80, major=8, regs_per_multiprocessor=65536, max_threads_per_multi_processor=2048, max_threads_per_block=1024, warp_size=32), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]], (3,): [['tt.divisibility', 16]], (4,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'autotune_hints': set(), 'kernel_name': 'triton_poi_fused__to_copy_add_cat_mean_mul_pow_rsqrt_slice_split_with_sizes_transpose_view_9', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 3, 'num_store': 1, 'num_reduction': 0, 'backend_hash': 'F7205DDDCE8E401A1728E5D602D369DE155D3FCCD3ACF038A9886E6E0DD93A54', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'max_autotune': True, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': False, 'are_deterministic_algorithms_enabled': False, 'coordinate_descent_tuning': True, 'coordinate_descent_search_radius': 1, 'coordinate_descent_check_all_directions': False, 'tiling_scores': {'x': 1920}},
    min_elem_per_thread=0
)
@triton.jit
def triton_poi_fused__to_copy_add_cat_mean_mul_pow_rsqrt_slice_split_with_sizes_transpose_view_9(in_ptr0, in_ptr1, in_ptr2, out_ptr0, xnumel, XBLOCK : tl.constexpr):
    xnumel = 384
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:]
    xmask = xindex < xnumel
    x0 = (xindex % 192)
    x1 = xindex // 192
    tmp0 = tl.load(in_ptr0 + (8256 + x0 + 256*x1), xmask).to(tl.float32)
    tmp2 = tl.load(in_ptr1 + (x1), xmask, eviction_policy='evict_last')
    tmp9 = tl.load(in_ptr2 + (64 + x0), xmask, eviction_policy='evict_last').to(tl.float32)
    tmp1 = tmp0.to(tl.float32)
    tmp3 = tl.full([1], 256.0, tl.float32)
    tmp4 = (tmp2 / tmp3)
    tmp5 = tl.full([1], 1e-06, tl.float32)
    tmp6 = tmp4 + tmp5
    tmp7 = libdevice.rsqrt(tmp6)
    tmp8 = tmp1 * tmp7
    tmp10 = tmp9.to(tl.float32)
    tmp11 = tl.full([1], 1.0, tl.float32)
    tmp12 = tmp10 + tmp11
    tmp13 = tmp8 * tmp12
    tmp14 = tmp13.to(tl.float32)
    tl.store(out_ptr0 + (x0 + 256*x1), tmp14, xmask)
''', device_str='cuda')


# kernel path: /tmp/infer-opt-models/q35moe-round-profile-20261109/inductor/l5/cl5vcxg6xbyyoce5n4wmuszvod5gbjavplnu26k4uvlkikvysm7b.py
# Topologically Sorted Source Nodes: [index_copy_], Original ATen: [aten.index_copy]
# Source node to ATen node mapping:
#   index_copy_ => index_put
# Graph fragment:
#   %copy_ : Tensor "i64[1][1]cuda:0" = PlaceHolder[target=copy_]
#   %cat_4 : Tensor "bf16[1, 2, 1, 256][512, 256, 256, 1]cuda:0" = PlaceHolder[target=cat_4]
#   %index_put : Tensor "bf16[1, 2, 2048, 256][1048576, 524288, 256, 1]cuda:0" = PlaceHolder[target=index_put]
#   %index_put : Tensor "bf16[1, 2, 2048, 256][1048576, 524288, 256, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.index_put_.default](args = (%arg14_1, [None, None, %arg2_1], %cat_4), kwargs = {})
#   return %buf25
triton_poi_fused_index_copy_10 = async_compile.triton('triton_poi_fused_index_copy_10', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.pointwise(
    size_hints={'x': 512}, 
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*i64', 'in_ptr1': '*bf16', 'out_ptr0': '*bf16', 'xnumel': 'i32', 'XBLOCK': 'constexpr'}, 'device': DeviceProperties(type='cuda', index=0, multi_processor_count=108, cc=80, major=8, regs_per_multiprocessor=65536, max_threads_per_multi_processor=2048, max_threads_per_block=1024, warp_size=32), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]], (3,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'autotune_hints': set(), 'kernel_name': 'triton_poi_fused_index_copy_10', 'mutated_arg_names': ['out_ptr0'], 'optimize_mem': True, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 2, 'num_store': 1, 'num_reduction': 0, 'backend_hash': 'F7205DDDCE8E401A1728E5D602D369DE155D3FCCD3ACF038A9886E6E0DD93A54', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'max_autotune': True, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': False, 'are_deterministic_algorithms_enabled': False, 'coordinate_descent_tuning': True, 'coordinate_descent_search_radius': 1, 'coordinate_descent_check_all_directions': False, 'tiling_scores': {'x': 1024}},
    min_elem_per_thread=0
)
@triton.jit
def triton_poi_fused_index_copy_10(in_ptr0, in_ptr1, out_ptr0, xnumel, XBLOCK : tl.constexpr):
    xnumel = 512
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:]
    xmask = xindex < xnumel
    x2 = xindex
    x0 = (xindex % 256)
    x1 = xindex // 256
    tmp0 = tl.load(in_ptr0 + (0))
    tmp1 = tl.broadcast_to(tmp0, [XBLOCK])
    tmp7 = tl.load(in_ptr1 + (x2), xmask).to(tl.float32)
    tmp2 = tl.full([XBLOCK], 2048, tl.int32)
    tmp3 = tmp1 + tmp2
    tmp4 = tmp1 < 0
    tmp5 = tl.where(tmp4, tmp3, tmp1)
    tl.device_assert((0 <= tmp5) & (tmp5 < 2048), "index out of bounds: 0 <= tmp5 < 2048")
    tl.store(out_ptr0 + (x0 + 256*tmp5 + 524288*x1), tmp7, xmask)
''', device_str='cuda')


# kernel path: /tmp/infer-opt-models/q35moe-round-profile-20261109/inductor/zp/czphmxakdqv4vo3if7oq2q5vnjtivdtsbrlcdcjm5mdtjvfbqj7k.py
# Topologically Sorted Source Nodes: [index_copy__1], Original ATen: [aten.split_with_sizes, aten.view, aten.transpose, aten.index_copy]
# Source node to ATen node mapping:
#   index_copy__1 => index_put_1, permute_3, split_with_sizes_10, view_15
# Graph fragment:
#   %copy_ : Tensor "i64[1][1]cuda:0" = PlaceHolder[target=copy_]
#   %buf10 : Tensor  = PlaceHolder[target=buf10]
#   %index_put_1 : Tensor "bf16[1, 2, 2048, 256][1048576, 524288, 256, 1]cuda:0" = PlaceHolder[target=index_put_1]
#   %split_with_sizes_10 : [num_users=1] = call_function[target=torch.ops.aten.split_with_sizes.default](args = (%empty_1, [8192, 512, 512], -1), kwargs = {})
#   %view_15 : Tensor "bf16[1, 1, 2, 256][9216, 9216, 256, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%getitem_42, [1, 1, -1, 256]), kwargs = {})
#   %permute_3 : Tensor "bf16[1, 2, 1, 256][9216, 256, 9216, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.permute.default](args = (%view_15, [0, 2, 1, 3]), kwargs = {})
#   %index_put_1 : Tensor "bf16[1, 2, 2048, 256][1048576, 524288, 256, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.index_put_.default](args = (%arg15_1, [None, None, %arg2_1], %permute_3), kwargs = {})
#   return %buf26
triton_poi_fused_index_copy_split_with_sizes_transpose_view_11 = async_compile.triton('triton_poi_fused_index_copy_split_with_sizes_transpose_view_11', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.pointwise(
    size_hints={'x': 512}, 
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*i64', 'in_ptr1': '*bf16', 'out_ptr0': '*bf16', 'xnumel': 'i32', 'XBLOCK': 'constexpr'}, 'device': DeviceProperties(type='cuda', index=0, multi_processor_count=108, cc=80, major=8, regs_per_multiprocessor=65536, max_threads_per_multi_processor=2048, max_threads_per_block=1024, warp_size=32), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]], (3,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'autotune_hints': set(), 'kernel_name': 'triton_poi_fused_index_copy_split_with_sizes_transpose_view_11', 'mutated_arg_names': ['out_ptr0'], 'optimize_mem': True, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 2, 'num_store': 1, 'num_reduction': 0, 'backend_hash': 'F7205DDDCE8E401A1728E5D602D369DE155D3FCCD3ACF038A9886E6E0DD93A54', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'max_autotune': True, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': False, 'are_deterministic_algorithms_enabled': False, 'coordinate_descent_tuning': True, 'coordinate_descent_search_radius': 1, 'coordinate_descent_check_all_directions': False, 'tiling_scores': {'x': 0}},
    min_elem_per_thread=0
)
@triton.jit
def triton_poi_fused_index_copy_split_with_sizes_transpose_view_11(in_ptr0, in_ptr1, out_ptr0, xnumel, XBLOCK : tl.constexpr):
    xnumel = 512
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:]
    xmask = xindex < xnumel
    x2 = xindex
    x0 = (xindex % 256)
    x1 = xindex // 256
    tmp0 = tl.load(in_ptr0 + (0))
    tmp1 = tl.broadcast_to(tmp0, [XBLOCK])
    tmp7 = tl.load(in_ptr1 + (8704 + x2), xmask).to(tl.float32)
    tmp2 = tl.full([XBLOCK], 2048, tl.int32)
    tmp3 = tmp1 + tmp2
    tmp4 = tmp1 < 0
    tmp5 = tl.where(tmp4, tmp3, tmp1)
    tl.device_assert((0 <= tmp5) & (tmp5 < 2048), "index out of bounds: 0 <= tmp5 < 2048")
    tl.store(out_ptr0 + (x0 + 256*tmp5 + 524288*x1), tmp7, xmask)
''', device_str='cuda')


# Original path: /content/q35moe-round-profile-20261109/infer-opt/infer_opt/attention_kernels.py:30
_decode_attention_kernel_2 = async_compile.triton('_decode_attention_kernel', '''

import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties

@triton_heuristics.user_autotune(
    configs=[{'num_warps': 4, 'num_stages': 3}],
    inductor_meta={'grid_type': 'FixedGrid', 'fixed_grid': ['_grid_0', '_grid_1', '_grid_2'], 'extra_launcher_args': ['_grid_0', '_grid_1', '_grid_2'], 'kernel_name': '_decode_attention_kernel_2', 'backend_hash': 'F7205DDDCE8E401A1728E5D602D369DE155D3FCCD3ACF038A9886E6E0DD93A54', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'max_autotune': True, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': False, 'are_deterministic_algorithms_enabled': False, 'coordinate_descent_tuning': True, 'coordinate_descent_search_radius': 1, 'coordinate_descent_check_all_directions': False},
    triton_meta={'signature': {'q_ptr': '*bf16', 'k_ptr': '*bf16', 'v_ptr': '*bf16', 'pos_ptr': '*i64', 'm_ptr': '*fp32', 'l_ptr': '*fp32', 'o_ptr': '*fp32', 'L': 'i32', 'scale': 'fp64', 'G': 'constexpr', 'G_PAD': 'constexpr', 'T': 'constexpr', 'D': 'constexpr', 'CHUNK': 'constexpr'}, 'device': DeviceProperties(type='cuda', index=0, multi_processor_count=108, cc=80, major=8, regs_per_multiprocessor=65536, max_threads_per_multi_processor=2048, max_threads_per_block=1024, warp_size=32), 'constants': {'G': 8, 'G_PAD': 16, 'T': 1, 'D': 256, 'CHUNK': 64}, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]], (3,): [['tt.divisibility', 16]], (4,): [['tt.divisibility', 16]], (5,): [['tt.divisibility', 16]], (6,): [['tt.divisibility', 16]], (7,): [['tt.divisibility', 16]]}]},
    filename=__file__,
    custom_kernel=True,
)
@triton.jit
def _decode_attention_kernel(q_ptr, k_ptr, v_ptr, pos_ptr, m_ptr, l_ptr, o_ptr, L, scale,
                             G: tl.constexpr, G_PAD: tl.constexpr, T: tl.constexpr, D: tl.constexpr,
                             CHUNK: tl.constexpr):
    head = tl.program_id(0)  # batch * KV heads
    split = tl.program_id(1)
    n_split = tl.num_programs(1)
    g = tl.arange(0, G_PAD)
    d = tl.arange(0, D)
    keys = split * CHUNK + tl.arange(0, CHUNK)
    position = tl.load(pos_ptr)
    part = (head * n_split + split) * G + g  # row of this (head, split, query head) in the partial buffers
    g_ok = g < G
    if split * CHUNK > position + T - 1:  # nothing filled in this slice
        tl.store(m_ptr + part, tl.full((G_PAD,), float("-inf"), tl.float32), mask=g_ok)
        tl.store(l_ptr + part, tl.zeros((G_PAD,), tl.float32), mask=g_ok)
        tl.store(o_ptr + part[:, None] * D + d[None, :], tl.zeros((G_PAD, D), tl.float32), mask=g_ok[:, None])
        return
    q = tl.load(q_ptr + (head * G + g)[:, None] * D + d[None, :], mask=g_ok[:, None], other=0.0)
    kv_ok = (keys < L)[:, None]
    kv_off = (head.to(tl.int64) * L + keys)[:, None] * D + d[None, :]
    k = tl.load(k_ptr + kv_off, mask=kv_ok, other=0.0)
    scores = tl.dot(q, tl.trans(k)) * scale  # [G_PAD, CHUNK], fp32
    if T == 1:
        scores = tl.where((keys <= position)[None, :], scores, float("-inf"))
        m = tl.max(scores, axis=1)
        p = tl.exp(scores - m[:, None])
    else:
        scores = tl.where(keys[None, :] <= (position + g % T)[:, None], scores, float("-inf"))
        m = tl.max(scores, axis=1)
        p = tl.exp(scores - tl.where(m == float("-inf"), 0.0, m)[:, None])  # rows with no key here: p = 0
    v = tl.load(v_ptr + kv_off, mask=kv_ok, other=0.0)
    o = tl.dot(p.to(v.dtype), v)  # [G_PAD, D], fp32
    tl.store(m_ptr + part, m, mask=g_ok)
    tl.store(l_ptr + part, tl.sum(p, axis=1), mask=g_ok)
    tl.store(o_ptr + part[:, None] * D + d[None, :], o, mask=g_ok[:, None])
''', device_str='cuda')


# kernel path: /tmp/infer-opt-models/q35moe-round-profile-20261109/inductor/on/con54jegmxlyopssnplgwtkfawzeimw7ps6qqsxu7pkufsvm2hgp.py
# Topologically Sorted Source Nodes: [amax, sub, weight, mul_16, sum_2], Original ATen: [aten.amax, aten.sub, aten.exp, aten.mul, aten.sum]
# Source node to ATen node mapping:
#   amax => amax
#   mul_16 => mul_16
#   sub => sub
#   sum_2 => sum_2
#   weight => exp
# Graph fragment:
#   %buf30 : Tensor  = PlaceHolder[target=buf30]
#   %amax : Tensor "f32[1, 2, 1, 8][16, 8, 16, 1]cuda:0" = PlaceHolder[target=amax]
#   %buf31 : Tensor  = PlaceHolder[target=buf31]
#   %amax : Tensor "f32[1, 2, 1, 8][16, 8, 8, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.amax.default](args = (%empty_2, [2], True), kwargs = {})
#   %sub : Tensor "f32[1, 2, 32, 8][512, 256, 8, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.sub.Tensor](args = (%empty_2, %amax), kwargs = {})
#   %exp : Tensor "f32[1, 2, 32, 8][512, 256, 8, 1]cuda:0"[num_users=2] = call_function[target=torch.ops.aten.exp.default](args = (%sub,), kwargs = {})
#   %mul_16 : Tensor "f32[1, 2, 32, 8][512, 256, 8, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%exp, %empty_3), kwargs = {})
#   %sum_2 : Tensor "f32[1, 2, 8][16, 8, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.sum.dim_IntList](args = (%mul_16, [2]), kwargs = {})
#   return %amax,%sum_2
triton_per_fused_amax_exp_mul_sub_sum_12 = async_compile.triton('triton_per_fused_amax_exp_mul_sub_sum_12', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.persistent_reduction(
    size_hints={'x': 16, 'r0_': 32},
    reduction_hint=ReductionHint.DEFAULT,
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*fp32', 'in_ptr1': '*fp32', 'out_ptr0': '*fp32', 'out_ptr1': '*fp32', 'xnumel': 'i32', 'r0_numel': 'i32', 'XBLOCK': 'constexpr'}, 'device': DeviceProperties(type='cuda', index=0, multi_processor_count=108, cc=80, major=8, regs_per_multiprocessor=65536, max_threads_per_multi_processor=2048, max_threads_per_block=1024, warp_size=32), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]], (3,): [['tt.divisibility', 16]], (4,): [['tt.divisibility', 16]], (5,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'autotune_hints': set(), 'kernel_name': 'triton_per_fused_amax_exp_mul_sub_sum_12', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': None, 'atomic_add_found': False, 'num_load': 2, 'num_store': 2, 'num_reduction': 2, 'backend_hash': 'F7205DDDCE8E401A1728E5D602D369DE155D3FCCD3ACF038A9886E6E0DD93A54', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'max_autotune': True, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': False, 'are_deterministic_algorithms_enabled': False, 'coordinate_descent_tuning': True, 'coordinate_descent_search_radius': 1, 'coordinate_descent_check_all_directions': False, 'tiling_scores': {'x': 256, 'r0_': 0}}
)
@triton.jit
def triton_per_fused_amax_exp_mul_sub_sum_12(in_ptr0, in_ptr1, out_ptr0, out_ptr1, xnumel, r0_numel, XBLOCK : tl.constexpr):
    xnumel = 16
    r0_numel = 32
    R0_BLOCK: tl.constexpr = 32
    rnumel = r0_numel
    RBLOCK: tl.constexpr = R0_BLOCK
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:, None]
    xmask = xindex < xnumel
    r0_index = tl.arange(0, R0_BLOCK)[None, :]
    r0_offset = 0
    r0_mask = tl.full([R0_BLOCK], True, tl.int1)[None, :]
    roffset = r0_offset
    rindex = r0_index
    r0_2 = r0_index
    x0 = (xindex % 8)
    x1 = xindex // 8
    x3 = xindex
    tmp0 = tl.load(in_ptr0 + (x0 + 8*r0_2 + 256*x1), xmask, other=0.0)
    tmp7 = tl.load(in_ptr1 + (x0 + 8*r0_2 + 256*x1), xmask, other=0.0)
    tmp1 = tl.broadcast_to(tmp0, [XBLOCK, R0_BLOCK])
    tmp3 = tl.where(xmask, tmp1, float("-inf"))
    tmp4 = triton_helpers.max2(tmp3, 1)[:, None].to(tl.float32)
    tmp5 = tmp0 - tmp4
    tmp6 = libdevice.exp(tmp5)
    tmp8 = tmp6 * tmp7
    tmp9 = tl.broadcast_to(tmp8, [XBLOCK, R0_BLOCK])
    tmp11 = tl.where(xmask, tmp9, 0)
    tmp12 = tl.sum(tmp11, 1)[:, None].to(tl.float32)
    tl.store(out_ptr0 + (x3), tmp4, xmask)
    tl.store(out_ptr1 + (x3), tmp12, xmask)
''', device_str='cuda')


# kernel path: /tmp/infer-opt-models/q35moe-round-profile-20261109/inductor/is/ciszbc42nbplaqbhwmk3la3bjhxnw67fn5zunpge7ei347pi67re.py
# Topologically Sorted Source Nodes: [gate_1, sub, weight, unsqueeze_2, mul_15, sum_1, unsqueeze_3, out, attn_output, attn_output_1, transpose_3, reshape_2, sigmoid, attn_output_4, y_2], Original ATen: [aten.split_with_sizes, aten.view, aten.split, aten.sub, aten.exp, aten.unsqueeze, aten.mul, aten.sum, aten.div, aten._to_copy, aten.transpose, aten.clone, aten._unsafe_view, aten.sigmoid]
# Source node to ATen node mapping:
#   attn_output => convert_element_type_19
#   attn_output_1 => view_17
#   attn_output_4 => mul_17
#   gate_1 => clone_4, split_1, split_with_sizes_3, view_5, view_6
#   mul_15 => mul_15
#   out => div
#   reshape_2 => view_18
#   sigmoid => sigmoid
#   sub => sub
#   sum_1 => sum_1
#   transpose_3 => permute_4
#   unsqueeze_2 => unsqueeze_5
#   unsqueeze_3 => unsqueeze_6
#   weight => exp
#   y_2 => triton_kernel_wrapper_mutation_2
# Graph fragment:
#   %buf30 : Tensor  = PlaceHolder[target=buf30]
#   %amax : Tensor "f32[1, 2, 1, 8][16, 8, 16, 1]cuda:0" = PlaceHolder[target=amax]
#   %buf32 : Tensor  = PlaceHolder[target=buf32]
#   %sum_1 : Tensor "f32[1, 2, 8, 256][4096, 2048, 256, 1]cuda:0" = PlaceHolder[target=sum_1]
#   %sum_2 : Tensor "f32[1, 2, 8][16, 8, 1]cuda:0" = PlaceHolder[target=sum_2]
#   %buf10 : Tensor  = PlaceHolder[target=buf10]
#   %split_with_sizes_3 : [num_users=1] = call_function[target=torch.ops.aten.split_with_sizes.default](args = (%empty_1, [8192, 512, 512], -1), kwargs = {})
#   %view_5 : Tensor "bf16[1, 1, 16, 512][9216, 9216, 512, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%getitem_13, [1, 1, -1, 512]), kwargs = {})
#   %split_1 : [num_users=1] = call_function[target=torch.ops.aten.split.Tensor](args = (%view_5, 256, -1), kwargs = {})
#   %sub : Tensor "f32[1, 2, 32, 8][512, 256, 8, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.sub.Tensor](args = (%empty_2, %amax), kwargs = {})
#   %exp : Tensor "f32[1, 2, 32, 8][512, 256, 8, 1]cuda:0"[num_users=2] = call_function[target=torch.ops.aten.exp.default](args = (%sub,), kwargs = {})
#   %unsqueeze_5 : Tensor "f32[1, 2, 32, 8, 1][512, 256, 8, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%exp, -1), kwargs = {})
#   %mul_15 : Tensor "f32[1, 2, 32, 8, 256][131072, 65536, 2048, 256, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%unsqueeze_5, %empty_4), kwargs = {})
#   %sum_1 : Tensor "f32[1, 2, 8, 256][4096, 2048, 256, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.sum.dim_IntList](args = (%mul_15, [2]), kwargs = {})
#   %unsqueeze_6 : Tensor "f32[1, 2, 8, 1][16, 8, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%sum_2, -1), kwargs = {})
#   %div : Tensor "f32[1, 2, 8, 256][4096, 2048, 256, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.div.Tensor](args = (%sum_1, %unsqueeze_6), kwargs = {})
#   %convert_element_type_19 : Tensor "bf16[1, 2, 8, 256][4096, 2048, 256, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%div, torch.bfloat16), kwargs = {})
#   %view_17 : Tensor "bf16[1, 16, 1, 256][4096, 256, 256, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%convert_element_type_19, [1, 16, 1, 256]), kwargs = {})
#   %permute_4 : Tensor "bf16[1, 1, 16, 256][4096, 256, 256, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.permute.default](args = (%view_17, [0, 2, 1, 3]), kwargs = {})
#   %view_18 : Tensor "bf16[1, 1, 4096][4096, 256, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%permute_4, [1, 1, -1]), kwargs = {})
#   %clone_4 : Tensor "bf16[1, 1, 16, 256][4096, 4096, 256, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.clone.default](args = (%getitem_17,), kwargs = {memory_format: torch.contiguous_format})
#   %view_6 : Tensor "bf16[1, 1, 4096][4096, 4096, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%clone_4, [1, 1, 4096]), kwargs = {})
#   %sigmoid : Tensor "bf16[1, 1, 4096][4096, 4096, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.sigmoid.default](args = (%view_6,), kwargs = {})
#   %mul_17 : Tensor "bf16[1, 1, 4096][4096, 4096, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%view_18, %sigmoid), kwargs = {})
#   %triton_kernel_wrapper_mutation_2 : [num_users=0] = call_function[target=torch.ops.higher_order.triton_kernel_wrapper_mutation](args = (), kwargs = {kernel_idx: 2923, constant_args_idx: 3538, grid: [(2048, 1, 1)], tma_descriptor_metadata: {}, kwargs: {x_ptr: %mul_17, q_ptr: %arg16_1, s_ptr: %arg17_1, y_ptr: %empty_5, N: 2048, K: 4096, GROUP: 128, BLOCK_N: 1, BLOCK_K: 1024, VEC: 16}})
#   return %sum_1,%buf37
triton_per_fused__to_copy__unsafe_view_clone_div_exp_mul_sigmoid_split_split_with_sizes_sub_sum_transpose_unsqueeze_view_13 = async_compile.triton('triton_per_fused__to_copy__unsafe_view_clone_div_exp_mul_sigmoid_split_split_with_sizes_sub_sum_transpose_unsqueeze_view_13', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.persistent_reduction(
    size_hints={'x': 4096, 'r0_': 32},
    reduction_hint=ReductionHint.DEFAULT,
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*fp32', 'in_ptr1': '*fp32', 'in_ptr2': '*fp32', 'in_ptr3': '*fp32', 'in_ptr4': '*bf16', 'out_ptr1': '*bf16', 'xnumel': 'i32', 'r0_numel': 'i32', 'XBLOCK': 'constexpr'}, 'device': DeviceProperties(type='cuda', index=0, multi_processor_count=108, cc=80, major=8, regs_per_multiprocessor=65536, max_threads_per_multi_processor=2048, max_threads_per_block=1024, warp_size=32), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]], (3,): [['tt.divisibility', 16]], (4,): [['tt.divisibility', 16]], (5,): [['tt.divisibility', 16]], (6,): [['tt.divisibility', 16]], (7,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'autotune_hints': set(), 'kernel_name': 'triton_per_fused__to_copy__unsafe_view_clone_div_exp_mul_sigmoid_split_split_with_sizes_sub_sum_transpose_unsqueeze_view_13', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': None, 'atomic_add_found': False, 'num_load': 5, 'num_store': 1, 'num_reduction': 1, 'backend_hash': 'F7205DDDCE8E401A1728E5D602D369DE155D3FCCD3ACF038A9886E6E0DD93A54', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'max_autotune': True, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': False, 'are_deterministic_algorithms_enabled': False, 'coordinate_descent_tuning': True, 'coordinate_descent_search_radius': 1, 'coordinate_descent_check_all_directions': False, 'tiling_scores': {'x': 16384, 'r0_': 0}}
)
@triton.jit
def triton_per_fused__to_copy__unsafe_view_clone_div_exp_mul_sigmoid_split_split_with_sizes_sub_sum_transpose_unsqueeze_view_13(in_ptr0, in_ptr1, in_ptr2, in_ptr3, in_ptr4, out_ptr1, xnumel, r0_numel, XBLOCK : tl.constexpr):
    xnumel = 4096
    r0_numel = 32
    R0_BLOCK: tl.constexpr = 32
    rnumel = r0_numel
    RBLOCK: tl.constexpr = R0_BLOCK
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:, None]
    xmask = tl.full([XBLOCK], True, tl.int1)[:, None]
    r0_index = tl.arange(0, R0_BLOCK)[None, :]
    r0_offset = 0
    r0_mask = tl.full([R0_BLOCK], True, tl.int1)[None, :]
    roffset = r0_offset
    rindex = r0_index
    r0_3 = r0_index
    x1 = ((xindex // 256) % 8)
    x2 = xindex // 2048
    x5 = xindex // 256
    x6 = (xindex % 2048)
    x4 = xindex
    tmp0 = tl.load(in_ptr0 + (x1 + 8*r0_3 + 256*x2), None, eviction_policy='evict_last')
    tmp1 = tl.load(in_ptr1 + (x5), None, eviction_policy='evict_last')
    tmp4 = tl.load(in_ptr2 + (x6 + 2048*r0_3 + 65536*x2), None)
    tmp9 = tl.load(in_ptr3 + (x4 // 256), None, eviction_policy='evict_last')
    tmp12 = tl.load(in_ptr4 + (256 + 512*(x4 // 256) + ((x4 % 256))), None, eviction_policy='evict_last').to(tl.float32)
    tmp2 = tmp0 - tmp1
    tmp3 = libdevice.exp(tmp2)
    tmp5 = tmp3 * tmp4
    tmp6 = tl.broadcast_to(tmp5, [XBLOCK, R0_BLOCK])
    tmp8 = tl.sum(tmp6, 1)[:, None].to(tl.float32)
    tmp10 = (tmp8 / tmp9)
    tmp11 = tmp10.to(tl.float32)
    tmp13 = tl.sigmoid(tmp12)
    tmp14 = tmp11 * tmp13
    tl.store(out_ptr1 + (x4), tmp14, None)
''', device_str='cuda')


# kernel path: /tmp/infer-opt-models/q35moe-round-profile-20261109/inductor/uy/cuy3x5e7scmyatghn5fh64xnu2klowjpgcglj652f7f3xx5le4tf.py
# Topologically Sorted Source Nodes: [hidden_states_1, float_12, pow_6, mean_5, add_14, rsqrt_5, output_10, float_13, add_15, output_11, hidden_states_2, x, linear_1], Original ATen: [aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul, aten.view, aten.mm, aten.t]
# Source node to ATen node mapping:
#   add_14 => add_14
#   add_15 => add_15
#   float_12 => convert_element_type_20
#   float_13 => convert_element_type_21
#   hidden_states_1 => add_13
#   hidden_states_2 => convert_element_type_22
#   linear_1 => convert_element_type_30, convert_element_type_31, mul_22, permute_6, sum_6, unsqueeze_10, unsqueeze_9
#   mean_5 => mean_5
#   output_10 => mul_18
#   output_11 => mul_19
#   pow_6 => pow_6
#   rsqrt_5 => rsqrt_5
#   x => view_19
# Graph fragment:
#   %buf6 : Tensor  = PlaceHolder[target=buf6]
#   %buf38 : Tensor  = PlaceHolder[target=buf38]
#   %buf39 : Tensor "f32[1, 1, 1][1, 1, 1]cuda:0" = PlaceHolder[target=buf39]
#   %arg18_1 : Tensor "bf16[2048][1]cuda:0" = PlaceHolder[target=arg18_1]
#   %convert_element_type_22 : Tensor "bf16[1, 1, 2048][2048, 2048, 1]cuda:0" = PlaceHolder[target=convert_element_type_22]
#   %arg28_1 : Tensor "bf16[1, 2048][2048, 1]cuda:0" = PlaceHolder[target=arg28_1]
#   %add_13 : Tensor "bf16[1, 1, 2048][2048, 2048, 1]cuda:0"[num_users=2] = call_function[target=torch.ops.aten.add.Tensor](args = (%empty, %empty_5), kwargs = {})
#   %convert_element_type_20 : Tensor "f32[1, 1, 2048][2048, 2048, 1]cuda:0"[num_users=2] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%add_13, torch.float32), kwargs = {})
#   %pow_6 : Tensor "f32[1, 1, 2048][2048, 2048, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.pow.Tensor_Scalar](args = (%convert_element_type_20, 2), kwargs = {})
#   %mean_5 : Tensor "f32[1, 1, 1][1, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mean.dim](args = (%pow_6, [-1], True), kwargs = {})
#   %add_14 : Tensor "f32[1, 1, 1][1, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%mean_5, 1e-06), kwargs = {})
#   %rsqrt_5 : Tensor "f32[1, 1, 1][1, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.rsqrt.default](args = (%add_14,), kwargs = {})
#   %mul_18 : Tensor "f32[1, 1, 2048][2048, 2048, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%convert_element_type_20, %rsqrt_5), kwargs = {})
#   %convert_element_type_21 : Tensor "f32[2048][1]cuda:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%arg18_1, torch.float32), kwargs = {})
#   %add_15 : Tensor "f32[2048][1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%convert_element_type_21, 1.0), kwargs = {})
#   %mul_19 : Tensor "f32[1, 1, 2048][2048, 2048, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%mul_18, %add_15), kwargs = {})
#   %convert_element_type_22 : Tensor "bf16[1, 1, 2048][2048, 2048, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%mul_19, torch.bfloat16), kwargs = {})
#   %view_19 : Tensor "bf16[1, 2048][2048, 1]cuda:0"[num_users=4] = call_function[target=torch.ops.aten.reshape.default](args = (%convert_element_type_22, [-1, 2048]), kwargs = {})
#   %convert_element_type_30 : Tensor "f32[1, 2048][2048, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%view_19, torch.float32), kwargs = {})
#   %unsqueeze_9 : Tensor "f32[1, 2048, 1][2048, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%convert_element_type_30, 2), kwargs = {})
#   %permute_6 : Tensor "bf16[2048, 1][1, 2048]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.permute.default](args = (%arg28_1, [1, 0]), kwargs = {})
#   %convert_element_type_31 : Tensor "f32[2048, 1][1, 2048]cuda:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%permute_6, torch.float32), kwargs = {})
#   %unsqueeze_10 : Tensor "f32[1, 2048, 1][2048, 1, 2048]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%convert_element_type_31, 0), kwargs = {})
#   %mul_22 : Tensor "f32[1, 2048, 1][2048, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%unsqueeze_9, %unsqueeze_10), kwargs = {})
#   %sum_6 : Tensor "f32[1, 1][1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.sum.dim_IntList](args = (%mul_22, [1]), kwargs = {})
#   return %buf39,%convert_element_type_22,%sum_6
triton_per_fused__to_copy_add_mean_mm_mul_pow_rsqrt_t_view_14 = async_compile.triton('triton_per_fused__to_copy_add_mean_mm_mul_pow_rsqrt_t_view_14', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.persistent_reduction(
    size_hints={'x': 1, 'r0_': 2048},
    reduction_hint=ReductionHint.INNER,
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*bf16', 'in_ptr1': '*bf16', 'in_ptr2': '*bf16', 'in_ptr3': '*bf16', 'out_ptr1': '*bf16', 'out_ptr2': '*fp32', 'xnumel': 'constexpr', 'r0_numel': 'i32', 'XBLOCK': 'constexpr'}, 'device': DeviceProperties(type='cuda', index=0, multi_processor_count=108, cc=80, major=8, regs_per_multiprocessor=65536, max_threads_per_multi_processor=2048, max_threads_per_block=1024, warp_size=32), 'constants': {'xnumel': 1}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]], (3,): [['tt.divisibility', 16]], (4,): [['tt.divisibility', 16]], (5,): [['tt.divisibility', 16]], (7,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'autotune_hints': set(), 'kernel_name': 'triton_per_fused__to_copy_add_mean_mm_mul_pow_rsqrt_t_view_14', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': None, 'atomic_add_found': False, 'num_load': 4, 'num_store': 2, 'num_reduction': 2, 'backend_hash': 'F7205DDDCE8E401A1728E5D602D369DE155D3FCCD3ACF038A9886E6E0DD93A54', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'max_autotune': True, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': False, 'are_deterministic_algorithms_enabled': False, 'coordinate_descent_tuning': True, 'coordinate_descent_search_radius': 1, 'coordinate_descent_check_all_directions': False, 'tiling_scores': {'r0_': 16384}}
)
@triton.jit
def triton_per_fused__to_copy_add_mean_mm_mul_pow_rsqrt_t_view_14(in_ptr0, in_ptr1, in_ptr2, in_ptr3, out_ptr1, out_ptr2, xnumel, r0_numel, XBLOCK : tl.constexpr):
    xnumel = 1
    r0_numel = 2048
    R0_BLOCK: tl.constexpr = 2048
    rnumel = r0_numel
    RBLOCK: tl.constexpr = R0_BLOCK
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:, None]
    xmask = tl.full([XBLOCK], True, tl.int1)[:, None]
    r0_index = tl.arange(0, R0_BLOCK)[None, :]
    r0_offset = 0
    r0_mask = tl.full([R0_BLOCK], True, tl.int1)[None, :]
    roffset = r0_offset
    rindex = r0_index
    r0_0 = r0_index
    tmp0 = tl.load(in_ptr0 + (r0_0), None).to(tl.float32)
    tmp1 = tl.load(in_ptr1 + (r0_0), None).to(tl.float32)
    tmp14 = tl.load(in_ptr2 + (r0_0), None).to(tl.float32)
    tmp21 = tl.load(in_ptr3 + (r0_0), None).to(tl.float32)
    tmp2 = tmp0 + tmp1
    tmp3 = tmp2.to(tl.float32)
    tmp4 = tmp3 * tmp3
    tmp5 = tl.broadcast_to(tmp4, [XBLOCK, R0_BLOCK])
    tmp7 = tl.sum(tmp5, 1)[:, None].to(tl.float32)
    tmp8 = tl.full([1, 1], 2048.0, tl.float32)
    tmp9 = (tmp7 / tmp8)
    tmp10 = tl.full([1, 1], 1e-06, tl.float32)
    tmp11 = tmp9 + tmp10
    tmp12 = libdevice.rsqrt(tmp11)
    tmp13 = tmp3 * tmp12
    tmp15 = tmp14.to(tl.float32)
    tmp16 = tl.full([1, 1], 1.0, tl.float32)
    tmp17 = tmp15 + tmp16
    tmp18 = tmp13 * tmp17
    tmp19 = tmp18.to(tl.float32)
    tmp20 = tmp19.to(tl.float32)
    tmp22 = tmp21.to(tl.float32)
    tmp23 = tmp20 * tmp22
    tmp24 = tl.broadcast_to(tmp23, [XBLOCK, R0_BLOCK])
    tmp26 = tl.sum(tmp24, 1)[:, None].to(tl.float32)
    tl.store(out_ptr1 + (tl.broadcast_to(r0_0, [XBLOCK, R0_BLOCK])), tmp19, None)
    tl.store(out_ptr2 + (tl.full([1, 1], 0, tl.int32).broadcast_to(XBLOCK, 1)), tmp26, None)
''', device_str='cuda')


# kernel path: /tmp/infer-opt-models/q35moe-round-profile-20261109/inductor/e7/ce7zalkrjfhj3ecuw2h6nxf7cvfwuxv6ajrdvvwqcrwzekmhirkp.py
# Topologically Sorted Source Nodes: [hidden_states_1, float_12, pow_6, mean_5, add_14, rsqrt_5, output_10, float_13, add_15, output_11, hidden_states_2, x, logits], Original ATen: [aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul, aten.view, aten.mm, aten.t]
# Source node to ATen node mapping:
#   add_14 => add_14
#   add_15 => add_15
#   float_12 => convert_element_type_20
#   float_13 => convert_element_type_21
#   hidden_states_1 => add_13
#   hidden_states_2 => convert_element_type_22
#   logits => convert_element_type_23, convert_element_type_24, mul_20, permute_5, sum_3, unsqueeze_7, unsqueeze_8
#   mean_5 => mean_5
#   output_10 => mul_18
#   output_11 => mul_19
#   pow_6 => pow_6
#   rsqrt_5 => rsqrt_5
#   x => view_19
# Graph fragment:
#   %convert_element_type_22 : Tensor "bf16[1, 1, 2048][2048, 2048, 1]cuda:0" = PlaceHolder[target=convert_element_type_22]
#   %arg19_1 : Tensor "bf16[256, 2048][2048, 1]cuda:0" = PlaceHolder[target=arg19_1]
#   %add_13 : Tensor "bf16[1, 1, 2048][2048, 2048, 1]cuda:0"[num_users=2] = call_function[target=torch.ops.aten.add.Tensor](args = (%empty, %empty_5), kwargs = {})
#   %convert_element_type_20 : Tensor "f32[1, 1, 2048][2048, 2048, 1]cuda:0"[num_users=2] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%add_13, torch.float32), kwargs = {})
#   %pow_6 : Tensor "f32[1, 1, 2048][2048, 2048, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.pow.Tensor_Scalar](args = (%convert_element_type_20, 2), kwargs = {})
#   %mean_5 : Tensor "f32[1, 1, 1][1, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mean.dim](args = (%pow_6, [-1], True), kwargs = {})
#   %add_14 : Tensor "f32[1, 1, 1][1, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%mean_5, 1e-06), kwargs = {})
#   %rsqrt_5 : Tensor "f32[1, 1, 1][1, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.rsqrt.default](args = (%add_14,), kwargs = {})
#   %mul_18 : Tensor "f32[1, 1, 2048][2048, 2048, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%convert_element_type_20, %rsqrt_5), kwargs = {})
#   %convert_element_type_21 : Tensor "f32[2048][1]cuda:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%arg18_1, torch.float32), kwargs = {})
#   %add_15 : Tensor "f32[2048][1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%convert_element_type_21, 1.0), kwargs = {})
#   %mul_19 : Tensor "f32[1, 1, 2048][2048, 2048, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%mul_18, %add_15), kwargs = {})
#   %convert_element_type_22 : Tensor "bf16[1, 1, 2048][2048, 2048, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%mul_19, torch.bfloat16), kwargs = {})
#   %view_19 : Tensor "bf16[1, 2048][2048, 1]cuda:0"[num_users=4] = call_function[target=torch.ops.aten.reshape.default](args = (%convert_element_type_22, [-1, 2048]), kwargs = {})
#   %convert_element_type_23 : Tensor "f32[1, 2048][2048, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%view_19, torch.float32), kwargs = {})
#   %unsqueeze_7 : Tensor "f32[1, 2048, 1][2048, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%convert_element_type_23, 2), kwargs = {})
#   %permute_5 : Tensor "bf16[2048, 256][1, 2048]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.permute.default](args = (%arg19_1, [1, 0]), kwargs = {})
#   %convert_element_type_24 : Tensor "f32[2048, 256][1, 2048]cuda:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%permute_5, torch.float32), kwargs = {})
#   %unsqueeze_8 : Tensor "f32[1, 2048, 256][2048, 1, 2048]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%convert_element_type_24, 0), kwargs = {})
#   %mul_20 : Tensor "f32[1, 2048, 256][2048, 1, 2048]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%unsqueeze_7, %unsqueeze_8), kwargs = {})
#   %sum_3 : Tensor "f32[1, 256][256, 1]cuda:0"[num_users=2] = call_function[target=torch.ops.aten.sum.dim_IntList](args = (%mul_20, [1]), kwargs = {})
#   return %sum_3
triton_per_fused__to_copy_add_mean_mm_mul_pow_rsqrt_t_view_15 = async_compile.triton('triton_per_fused__to_copy_add_mean_mm_mul_pow_rsqrt_t_view_15', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.persistent_reduction(
    size_hints={'x': 256, 'r0_': 2048},
    reduction_hint=ReductionHint.INNER,
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*bf16', 'in_ptr1': '*bf16', 'out_ptr0': '*fp32', 'xnumel': 'i32', 'r0_numel': 'i32', 'XBLOCK': 'constexpr'}, 'device': DeviceProperties(type='cuda', index=0, multi_processor_count=108, cc=80, major=8, regs_per_multiprocessor=65536, max_threads_per_multi_processor=2048, max_threads_per_block=1024, warp_size=32), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]], (3,): [['tt.divisibility', 16]], (4,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'autotune_hints': set(), 'kernel_name': 'triton_per_fused__to_copy_add_mean_mm_mul_pow_rsqrt_t_view_15', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': None, 'atomic_add_found': False, 'num_load': 2, 'num_store': 1, 'num_reduction': 1, 'backend_hash': 'F7205DDDCE8E401A1728E5D602D369DE155D3FCCD3ACF038A9886E6E0DD93A54', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'max_autotune': True, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': False, 'are_deterministic_algorithms_enabled': False, 'coordinate_descent_tuning': True, 'coordinate_descent_search_radius': 1, 'coordinate_descent_check_all_directions': False, 'tiling_scores': {'x': 2048, 'r0_': 1052672}}
)
@triton.jit
def triton_per_fused__to_copy_add_mean_mm_mul_pow_rsqrt_t_view_15(in_ptr0, in_ptr1, out_ptr0, xnumel, r0_numel, XBLOCK : tl.constexpr):
    xnumel = 256
    r0_numel = 2048
    R0_BLOCK: tl.constexpr = 2048
    rnumel = r0_numel
    RBLOCK: tl.constexpr = R0_BLOCK
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:, None]
    xmask = xindex < xnumel
    r0_index = tl.arange(0, R0_BLOCK)[None, :]
    r0_offset = 0
    r0_mask = tl.full([R0_BLOCK], True, tl.int1)[None, :]
    roffset = r0_offset
    rindex = r0_index
    r0_1 = r0_index
    x0 = xindex
    tmp0 = tl.load(in_ptr0 + (r0_1), None, eviction_policy='evict_last').to(tl.float32)
    tmp2 = tl.load(in_ptr1 + (r0_1 + 2048*x0), xmask, other=0.0).to(tl.float32)
    tmp1 = tmp0.to(tl.float32)
    tmp3 = tmp2.to(tl.float32)
    tmp4 = tmp1 * tmp3
    tmp5 = tl.broadcast_to(tmp4, [XBLOCK, R0_BLOCK])
    tmp7 = tl.where(xmask, tmp5, 0)
    tmp8 = tl.sum(tmp7, 1)[:, None].to(tl.float32)
    tl.store(out_ptr0 + (x0), tmp8, xmask)
''', device_str='cuda')


# kernel path: /tmp/infer-opt-models/q35moe-round-profile-20261109/inductor/kg/ckgnqdbd5gykao6g3psl6phygautbxglcay4s7prf7ius2hlu4ck.py
# Topologically Sorted Source Nodes: [probs], Original ATen: [prims.prepare_softmax_online, aten.sub, aten.exp, aten._softmax]
# Source node to ATen node mapping:
#   probs => div_1
# Graph fragment:
#   %sum_3 : Tensor "f32[1, 256][256, 1]cuda:0" = PlaceHolder[target=sum_3]
#   %getitem_57 : Tensor "f32[1, 1][1, 1]cuda:0" = PlaceHolder[target=getitem_57]
#   %getitem_58 : Tensor "f32[1, 1][1, 1]cuda:0" = PlaceHolder[target=getitem_58]
#   %prepare_softmax_online_default : [num_users=2] = call_function[target=torch.ops.prims.prepare_softmax_online.default](args = (%sum_3, -1), kwargs = {})
#   %sub_tensor : Tensor "f32[1, 256][256, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.sub.Tensor](args = (%sum_3, %getitem_57), kwargs = {})
#   %exp_default : Tensor "f32[1, 256][256, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.exp.default](args = (%sub_tensor,), kwargs = {})
#   %div_1 : Tensor "f32[1, 256][256, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.div.Tensor](args = (%exp_default, %getitem_58), kwargs = {})
#   return %getitem_57,%getitem_58,%div_1
triton_per_fused__softmax_exp_prepare_softmax_online_sub_16 = async_compile.triton('triton_per_fused__softmax_exp_prepare_softmax_online_sub_16', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.persistent_reduction(
    size_hints={'x': 1, 'r0_': 256},
    reduction_hint=ReductionHint.INNER,
    filename=__file__,
    triton_meta={'signature': {'in_out_ptr0': '*fp32', 'xnumel': 'constexpr', 'r0_numel': 'i32', 'XBLOCK': 'constexpr'}, 'device': DeviceProperties(type='cuda', index=0, multi_processor_count=108, cc=80, major=8, regs_per_multiprocessor=65536, max_threads_per_multi_processor=2048, max_threads_per_block=1024, warp_size=32), 'constants': {'xnumel': 1}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'autotune_hints': set(), 'kernel_name': 'triton_per_fused__softmax_exp_prepare_softmax_online_sub_16', 'mutated_arg_names': ['in_out_ptr0'], 'optimize_mem': True, 'no_x_dim': None, 'atomic_add_found': False, 'num_load': 1, 'num_store': 1, 'num_reduction': 4, 'backend_hash': 'F7205DDDCE8E401A1728E5D602D369DE155D3FCCD3ACF038A9886E6E0DD93A54', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'max_autotune': True, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': False, 'are_deterministic_algorithms_enabled': False, 'coordinate_descent_tuning': True, 'coordinate_descent_search_radius': 1, 'coordinate_descent_check_all_directions': False, 'tiling_scores': {'r0_': 3072}}
)
@triton.jit
def triton_per_fused__softmax_exp_prepare_softmax_online_sub_16(in_out_ptr0, xnumel, r0_numel, XBLOCK : tl.constexpr):
    xnumel = 1
    r0_numel = 256
    R0_BLOCK: tl.constexpr = 256
    rnumel = r0_numel
    RBLOCK: tl.constexpr = R0_BLOCK
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:, None]
    xmask = tl.full([XBLOCK], True, tl.int1)[:, None]
    r0_index = tl.arange(0, R0_BLOCK)[None, :]
    r0_offset = 0
    r0_mask = tl.full([R0_BLOCK], True, tl.int1)[None, :]
    roffset = r0_offset
    rindex = r0_index
    r0_0 = r0_index
    tmp0 = tl.load(in_out_ptr0 + (r0_0), None)
    tmp1 = tl.broadcast_to(tmp0, [XBLOCK, R0_BLOCK])
    tmp3 = tl.broadcast_to(tmp1, [XBLOCK, R0_BLOCK])
    tmp5 = triton_helpers.max2(tmp3, 1)[:, None].to(tl.float32)
    tmp6 = tmp1 - tmp5
    tmp7 = libdevice.exp(tmp6)
    tmp8 = tl.broadcast_to(tmp7, [XBLOCK, R0_BLOCK])
    tmp10 = tl.sum(tmp8, 1)[:, None].to(tl.float32)
    tmp11 = tmp0 - tmp5
    tmp12 = libdevice.exp(tmp11)
    tmp13 = (tmp12 / tmp10)
    tl.store(in_out_ptr0 + (tl.broadcast_to(r0_0, [XBLOCK, R0_BLOCK])), tmp13, None)
''', device_str='cuda')


# Original path: /content/q35moe-round-profile-20261109/infer-opt/infer_opt/quant_kernels.py:72
_w8a16_group_gemv_kernel_3 = async_compile.triton('_w8a16_group_gemv_kernel', '''

import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties

@triton_heuristics.user_autotune(
    configs=[{'num_warps': 2, 'num_stages': 2}],
    inductor_meta={'grid_type': 'FixedGrid', 'fixed_grid': ['_grid_0', '_grid_1', '_grid_2'], 'extra_launcher_args': ['_grid_0', '_grid_1', '_grid_2'], 'kernel_name': '_w8a16_group_gemv_kernel_3', 'backend_hash': 'F7205DDDCE8E401A1728E5D602D369DE155D3FCCD3ACF038A9886E6E0DD93A54', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'max_autotune': True, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': False, 'are_deterministic_algorithms_enabled': False, 'coordinate_descent_tuning': True, 'coordinate_descent_search_radius': 1, 'coordinate_descent_check_all_directions': False},
    triton_meta={'signature': {'x_ptr': '*bf16', 'q_ptr': '*i8', 's_ptr': '*bf16', 'y_ptr': '*bf16', 'N': 'i32', 'K': 'i32', 'GROUP': 'constexpr', 'BLOCK_N': 'constexpr', 'BLOCK_K': 'constexpr', 'VEC': 'constexpr'}, 'device': DeviceProperties(type='cuda', index=0, multi_processor_count=108, cc=80, major=8, regs_per_multiprocessor=65536, max_threads_per_multi_processor=2048, max_threads_per_block=1024, warp_size=32), 'constants': {'GROUP': 128, 'BLOCK_N': 1, 'BLOCK_K': 1024, 'VEC': 16}, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]], (3,): [['tt.divisibility', 16]], (4,): [['tt.divisibility', 16]], (5,): [['tt.divisibility', 16]]}]},
    filename=__file__,
    custom_kernel=True,
)
@triton.jit
def _w8a16_group_gemv_kernel(x_ptr, q_ptr, s_ptr, y_ptr, N, K, GROUP: tl.constexpr,
                             BLOCK_N: tl.constexpr, BLOCK_K: tl.constexpr, VEC: tl.constexpr):
    NV: tl.constexpr = BLOCK_K // VEC
    pid = tl.program_id(0)
    rows = pid * BLOCK_N + tl.arange(0, BLOCK_N)
    row_ok = rows < N
    jv = tl.arange(0, NV)
    cols = jv[None, :, None] * VEC + tl.arange(0, VEC)[None, None, :]  # [1, NV, VEC]
    groups = K // GROUP
    q_ptrs = q_ptr + rows[:, None, None].to(tl.int64) * K + cols
    x_ptrs = x_ptr + rows[:, None, None] * 0 + cols  # q's shape, so x gets q's layout
    s_row = s_ptr + rows[:, None, None] * groups  # [BLOCK_N, 1, 1]
    s_step = (jv * VEC // GROUP)[None, :, None]  # [1, NV, 1]: one scale per VEC weights, when GROUP divides BLOCK_K
    acc = tl.zeros((BLOCK_N, NV), dtype=tl.float32)
    for k0 in range(0, K, BLOCK_K):
        x = tl.load(x_ptrs + k0).to(tl.float32)
        q = tl.load(q_ptrs + k0, mask=row_ok[:, None, None], other=0, eviction_policy="evict_first").to(tl.float32)
        if BLOCK_K % GROUP == 0:  # hoisted offsets: recomputing them every step was 13% slower on a 9B shape
            s_ptrs = s_row + k0 // GROUP + s_step
        else:
            s_ptrs = s_row + ((k0 + jv * VEC) // GROUP)[None, :, None]
        s = tl.sum(tl.load(s_ptrs, mask=row_ok[:, None, None], other=0.0).to(tl.float32), axis=2)
        acc += tl.sum(q * x, axis=2) * s
    tl.store(y_ptr + rows, tl.sum(acc, axis=1).to(y_ptr.dtype.element_ty), mask=row_ok)
''', device_str='cuda')


# kernel path: /tmp/infer-opt-models/q35moe-round-profile-20261109/inductor/fz/cfzbzenlhzitfjiqnvv4z4enpxfkf6c53g4hxoj6byonif4omwbg.py
# Topologically Sorted Source Nodes: [silu, mul_20, y_4], Original ATen: [aten.split, aten.silu, aten.mul]
# Source node to ATen node mapping:
#   mul_20 => mul_21, split_6
#   silu => add_16, convert_element_type_28, convert_element_type_29, div_3, exp_2, neg_2, split_5
#   y_4 => triton_kernel_wrapper_mutation
# Graph fragment:
#   %buf49 : Tensor  = PlaceHolder[target=buf49]
#   %split_5 : [num_users=1] = call_function[target=torch.ops.aten.split.Tensor](args = (%empty_6, 512, -1), kwargs = {})
#   %split_6 : [num_users=1] = call_function[target=torch.ops.aten.split.Tensor](args = (%empty_6, 512, -1), kwargs = {})
#   %convert_element_type_28 : Tensor "f32[1, 512][1024, 1]cuda:0"[num_users=2] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%getitem_52, torch.float32), kwargs = {})
#   %neg_2 : Tensor "f32[1, 512][512, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.neg.default](args = (%convert_element_type_28,), kwargs = {})
#   %exp_2 : Tensor "f32[1, 512][512, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.exp.default](args = (%neg_2,), kwargs = {})
#   %add_16 : Tensor "f32[1, 512][512, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%exp_2, 1), kwargs = {})
#   %div_3 : Tensor "f32[1, 512][512, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.div.Tensor](args = (%convert_element_type_28, %add_16), kwargs = {})
#   %convert_element_type_29 : Tensor "bf16[1, 512][512, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%div_3, torch.bfloat16), kwargs = {})
#   %mul_21 : Tensor "bf16[1, 512][512, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%convert_element_type_29, %getitem_55), kwargs = {})
#   %triton_kernel_wrapper_mutation : [num_users=0] = call_function[target=torch.ops.higher_order.triton_kernel_wrapper_mutation](args = (), kwargs = {kernel_idx: 2925, constant_args_idx: 3540, grid: [(2048, 1, 1)], tma_descriptor_metadata: {}, kwargs: {x_ptr: %mul_21, q_ptr: %arg26_1, s_ptr: %arg27_1, y_ptr: %empty_7, N: 2048, K: 512, GROUP: 128, BLOCK_N: 1, BLOCK_K: 512, VEC: 16}})
#   return %buf51
triton_poi_fused_mul_silu_split_17 = async_compile.triton('triton_poi_fused_mul_silu_split_17', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.pointwise(
    size_hints={'x': 512}, 
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*bf16', 'out_ptr0': '*bf16', 'xnumel': 'i32', 'XBLOCK': 'constexpr'}, 'device': DeviceProperties(type='cuda', index=0, multi_processor_count=108, cc=80, major=8, regs_per_multiprocessor=65536, max_threads_per_multi_processor=2048, max_threads_per_block=1024, warp_size=32), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'autotune_hints': set(), 'kernel_name': 'triton_poi_fused_mul_silu_split_17', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 2, 'num_store': 1, 'num_reduction': 0, 'backend_hash': 'F7205DDDCE8E401A1728E5D602D369DE155D3FCCD3ACF038A9886E6E0DD93A54', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'max_autotune': True, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': False, 'are_deterministic_algorithms_enabled': False, 'coordinate_descent_tuning': True, 'coordinate_descent_search_radius': 1, 'coordinate_descent_check_all_directions': False, 'tiling_scores': {'x': 2048}},
    min_elem_per_thread=0
)
@triton.jit
def triton_poi_fused_mul_silu_split_17(in_ptr0, out_ptr0, xnumel, XBLOCK : tl.constexpr):
    xnumel = 512
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:]
    xmask = xindex < xnumel
    x0 = xindex
    tmp0 = tl.load(in_ptr0 + (x0), xmask).to(tl.float32)
    tmp8 = tl.load(in_ptr0 + (512 + x0), xmask).to(tl.float32)
    tmp1 = tmp0.to(tl.float32)
    tmp2 = -tmp1
    tmp3 = libdevice.exp(tmp2)
    tmp4 = tl.full([1], 1.0, tl.float32)
    tmp5 = tmp3 + tmp4
    tmp6 = (tmp1 / tmp5)
    tmp7 = tmp6.to(tl.float32)
    tmp9 = tmp7 * tmp8
    tl.store(out_ptr0 + (x0), tmp9, xmask)
''', device_str='cuda')


# Original path: /content/q35moe-round-profile-20261109/infer-opt/infer_opt/quant_kernels.py:72
_w8a16_group_gemv_kernel_4 = async_compile.triton('_w8a16_group_gemv_kernel', '''

import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties

@triton_heuristics.user_autotune(
    configs=[{'num_warps': 2, 'num_stages': 2}],
    inductor_meta={'grid_type': 'FixedGrid', 'fixed_grid': ['_grid_0', '_grid_1', '_grid_2'], 'extra_launcher_args': ['_grid_0', '_grid_1', '_grid_2'], 'kernel_name': '_w8a16_group_gemv_kernel_4', 'backend_hash': 'F7205DDDCE8E401A1728E5D602D369DE155D3FCCD3ACF038A9886E6E0DD93A54', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'max_autotune': True, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': False, 'are_deterministic_algorithms_enabled': False, 'coordinate_descent_tuning': True, 'coordinate_descent_search_radius': 1, 'coordinate_descent_check_all_directions': False},
    triton_meta={'signature': {'x_ptr': '*bf16', 'q_ptr': '*i8', 's_ptr': '*bf16', 'y_ptr': '*bf16', 'N': 'i32', 'K': 'i32', 'GROUP': 'constexpr', 'BLOCK_N': 'constexpr', 'BLOCK_K': 'constexpr', 'VEC': 'constexpr'}, 'device': DeviceProperties(type='cuda', index=0, multi_processor_count=108, cc=80, major=8, regs_per_multiprocessor=65536, max_threads_per_multi_processor=2048, max_threads_per_block=1024, warp_size=32), 'constants': {'GROUP': 128, 'BLOCK_N': 1, 'BLOCK_K': 512, 'VEC': 16}, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]], (3,): [['tt.divisibility', 16]], (4,): [['tt.divisibility', 16]], (5,): [['tt.divisibility', 16]]}]},
    filename=__file__,
    custom_kernel=True,
)
@triton.jit
def _w8a16_group_gemv_kernel(x_ptr, q_ptr, s_ptr, y_ptr, N, K, GROUP: tl.constexpr,
                             BLOCK_N: tl.constexpr, BLOCK_K: tl.constexpr, VEC: tl.constexpr):
    NV: tl.constexpr = BLOCK_K // VEC
    pid = tl.program_id(0)
    rows = pid * BLOCK_N + tl.arange(0, BLOCK_N)
    row_ok = rows < N
    jv = tl.arange(0, NV)
    cols = jv[None, :, None] * VEC + tl.arange(0, VEC)[None, None, :]  # [1, NV, VEC]
    groups = K // GROUP
    q_ptrs = q_ptr + rows[:, None, None].to(tl.int64) * K + cols
    x_ptrs = x_ptr + rows[:, None, None] * 0 + cols  # q's shape, so x gets q's layout
    s_row = s_ptr + rows[:, None, None] * groups  # [BLOCK_N, 1, 1]
    s_step = (jv * VEC // GROUP)[None, :, None]  # [1, NV, 1]: one scale per VEC weights, when GROUP divides BLOCK_K
    acc = tl.zeros((BLOCK_N, NV), dtype=tl.float32)
    for k0 in range(0, K, BLOCK_K):
        x = tl.load(x_ptrs + k0).to(tl.float32)
        q = tl.load(q_ptrs + k0, mask=row_ok[:, None, None], other=0, eviction_policy="evict_first").to(tl.float32)
        if BLOCK_K % GROUP == 0:  # hoisted offsets: recomputing them every step was 13% slower on a 9B shape
            s_ptrs = s_row + k0 // GROUP + s_step
        else:
            s_ptrs = s_row + ((k0 + jv * VEC) // GROUP)[None, :, None]
        s = tl.sum(tl.load(s_ptrs, mask=row_ok[:, None, None], other=0.0).to(tl.float32), axis=2)
        acc += tl.sum(q * x, axis=2) * s
    tl.store(y_ptr + rows, tl.sum(acc, axis=1).to(y_ptr.dtype.element_ty), mask=row_ok)
''', device_str='cuda')


# kernel path: /tmp/infer-opt-models/q35moe-round-profile-20261109/inductor/bf/cbfkup3q5phifjwyjsfvyotb5436y7d6lvz6manjv5nmkoynk2jl.py
# Topologically Sorted Source Nodes: [hidden_states_1, float_12, pow_6, mean_5, add_14, rsqrt_5, output_10, float_13, add_15, output_11, hidden_states_2, x, sum_3, truediv_1, weights_1, routed], Original ATen: [aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul, aten.view, aten.sum, aten.div, infer_opt.selected_int8_experts]
# Source node to ATen node mapping:
#   add_14 => add_14
#   add_15 => add_15
#   float_12 => convert_element_type_20
#   float_13 => convert_element_type_21
#   hidden_states_1 => add_13
#   hidden_states_2 => convert_element_type_22
#   mean_5 => mean_5
#   output_10 => mul_18
#   output_11 => mul_19
#   pow_6 => pow_6
#   routed => selected_int8_experts
#   rsqrt_5 => rsqrt_5
#   sum_3 => sum_5
#   truediv_1 => div_2
#   weights_1 => convert_element_type_27
#   x => view_19
# Graph fragment:
#   %getitem_47 : Tensor "f32[1, 8][8, 1]cuda:0" = PlaceHolder[target=getitem_47]
#   %sum_5 : Tensor "f32[1, 1][1, 1]cuda:0" = PlaceHolder[target=sum_5]
#   %add_13 : Tensor "bf16[1, 1, 2048][2048, 2048, 1]cuda:0"[num_users=2] = call_function[target=torch.ops.aten.add.Tensor](args = (%empty, %empty_5), kwargs = {})
#   %convert_element_type_20 : Tensor "f32[1, 1, 2048][2048, 2048, 1]cuda:0"[num_users=2] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%add_13, torch.float32), kwargs = {})
#   %pow_6 : Tensor "f32[1, 1, 2048][2048, 2048, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.pow.Tensor_Scalar](args = (%convert_element_type_20, 2), kwargs = {})
#   %mean_5 : Tensor "f32[1, 1, 1][1, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mean.dim](args = (%pow_6, [-1], True), kwargs = {})
#   %add_14 : Tensor "f32[1, 1, 1][1, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%mean_5, 1e-06), kwargs = {})
#   %rsqrt_5 : Tensor "f32[1, 1, 1][1, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.rsqrt.default](args = (%add_14,), kwargs = {})
#   %mul_18 : Tensor "f32[1, 1, 2048][2048, 2048, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%convert_element_type_20, %rsqrt_5), kwargs = {})
#   %convert_element_type_21 : Tensor "f32[2048][1]cuda:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%arg18_1, torch.float32), kwargs = {})
#   %add_15 : Tensor "f32[2048][1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%convert_element_type_21, 1.0), kwargs = {})
#   %mul_19 : Tensor "f32[1, 1, 2048][2048, 2048, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%mul_18, %add_15), kwargs = {})
#   %convert_element_type_22 : Tensor "bf16[1, 1, 2048][2048, 2048, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%mul_19, torch.bfloat16), kwargs = {})
#   %view_19 : Tensor "bf16[1, 2048][2048, 1]cuda:0"[num_users=4] = call_function[target=torch.ops.aten.reshape.default](args = (%convert_element_type_22, [-1, 2048]), kwargs = {})
#   %sum_5 : Tensor "f32[1, 1][1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.sum.dim_IntList](args = (%getitem_47, [-1], True), kwargs = {})
#   %div_2 : Tensor "f32[1, 8][8, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.div.Tensor](args = (%getitem_47, %sum_5), kwargs = {})
#   %convert_element_type_27 : Tensor "bf16[1, 8][8, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%div_2, torch.bfloat16), kwargs = {})
#   %selected_int8_experts : Tensor "bf16[1, 2048][2048, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.infer_opt.selected_int8_experts.default](args = (%view_19, %getitem_48, %convert_element_type_27, %arg20_1, %arg21_1, %arg22_1, %arg23_1), kwargs = {})
#   return %sum_5,%buf54
triton_per_fused__to_copy_add_div_mean_mul_pow_rsqrt_selected_int8_experts_sum_view_18 = async_compile.triton('triton_per_fused__to_copy_add_div_mean_mul_pow_rsqrt_selected_int8_experts_sum_view_18', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.persistent_reduction(
    size_hints={'x': 1, 'r0_': 8},
    reduction_hint=ReductionHint.INNER,
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*fp32', 'out_ptr1': '*bf16', 'xnumel': 'constexpr', 'r0_numel': 'i32', 'XBLOCK': 'constexpr'}, 'device': DeviceProperties(type='cuda', index=0, multi_processor_count=108, cc=80, major=8, regs_per_multiprocessor=65536, max_threads_per_multi_processor=2048, max_threads_per_block=1024, warp_size=32), 'constants': {'xnumel': 1}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'autotune_hints': set(), 'kernel_name': 'triton_per_fused__to_copy_add_div_mean_mul_pow_rsqrt_selected_int8_experts_sum_view_18', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': None, 'atomic_add_found': False, 'num_load': 1, 'num_store': 1, 'num_reduction': 1, 'backend_hash': 'F7205DDDCE8E401A1728E5D602D369DE155D3FCCD3ACF038A9886E6E0DD93A54', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'max_autotune': True, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': False, 'are_deterministic_algorithms_enabled': False, 'coordinate_descent_tuning': True, 'coordinate_descent_search_radius': 1, 'coordinate_descent_check_all_directions': False, 'tiling_scores': {'r0_': 64}}
)
@triton.jit
def triton_per_fused__to_copy_add_div_mean_mul_pow_rsqrt_selected_int8_experts_sum_view_18(in_ptr0, out_ptr1, xnumel, r0_numel, XBLOCK : tl.constexpr):
    xnumel = 1
    r0_numel = 8
    R0_BLOCK: tl.constexpr = 8
    rnumel = r0_numel
    RBLOCK: tl.constexpr = R0_BLOCK
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:, None]
    xmask = tl.full([XBLOCK], True, tl.int1)[:, None]
    r0_index = tl.arange(0, R0_BLOCK)[None, :]
    r0_offset = 0
    r0_mask = tl.full([R0_BLOCK], True, tl.int1)[None, :]
    roffset = r0_offset
    rindex = r0_index
    r0_0 = r0_index
    tmp0 = tl.load(in_ptr0 + (r0_0), None)
    tmp1 = tl.broadcast_to(tmp0, [XBLOCK, R0_BLOCK])
    tmp3 = tl.sum(tmp1, 1)[:, None].to(tl.float32)
    tmp4 = (tmp0 / tmp3)
    tmp5 = tmp4.to(tl.float32)
    tl.store(out_ptr1 + (tl.broadcast_to(r0_0, [XBLOCK, R0_BLOCK])), tmp5, None)
''', device_str='cuda')


# kernel path: /tmp/infer-opt-models/q35moe-round-profile-20261109/inductor/h2/ch24slbxqalvtlhlgg7zekbpha3tahwu5oq2iqmq4g4mizmwio5w.py
# Topologically Sorted Source Nodes: [hidden_states_1, linear_1, sigmoid_1, shared, add_16, hidden_states_3, add_17, float_14, pow_7, mean_6, add_18, rsqrt_6, output_12, float_15, add_19, output_13, out_1], Original ATen: [aten.add, aten.mm, aten.sigmoid, aten.mul, aten.view, aten._to_copy, aten.pow, aten.mean, aten.rsqrt]
# Source node to ATen node mapping:
#   add_16 => add_17
#   add_17 => add_18
#   add_18 => add_19
#   add_19 => add_20
#   float_14 => convert_element_type_33
#   float_15 => convert_element_type_34
#   hidden_states_1 => add_13
#   hidden_states_3 => view_20
#   linear_1 => convert_element_type_32
#   mean_6 => mean_6
#   out_1 => convert_element_type_35
#   output_12 => mul_24
#   output_13 => mul_25
#   pow_7 => pow_7
#   rsqrt_6 => rsqrt_6
#   shared => mul_23
#   sigmoid_1 => sigmoid_1
# Graph fragment:
#   %buf6 : Tensor  = PlaceHolder[target=buf6]
#   %buf38 : Tensor  = PlaceHolder[target=buf38]
#   %selected_int8_experts : Tensor "bf16[1, 2048][2048, 1]cuda:0" = PlaceHolder[target=selected_int8_experts]
#   %buf52 : Tensor  = PlaceHolder[target=buf52]
#   %sum_6 : Tensor "f32[1, 1][1, 1]cuda:0" = PlaceHolder[target=sum_6]
#   %convert_element_type_33 : Tensor "f32[1, 1, 2048][2048, 2048, 1]cuda:0" = PlaceHolder[target=convert_element_type_33]
#   %buf59 : Tensor "f32[1, 1, 1][1, 1, 1]cuda:0" = PlaceHolder[target=buf59]
#   %arg29_1 : Tensor "bf16[2048][1]cuda:0" = PlaceHolder[target=arg29_1]
#   %add_13 : Tensor "bf16[1, 1, 2048][2048, 2048, 1]cuda:0"[num_users=2] = call_function[target=torch.ops.aten.add.Tensor](args = (%empty, %empty_5), kwargs = {})
#   %convert_element_type_32 : Tensor "bf16[1, 1][1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%sum_6, torch.bfloat16), kwargs = {})
#   %sigmoid_1 : Tensor "bf16[1, 1][1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.sigmoid.default](args = (%convert_element_type_32,), kwargs = {})
#   %mul_23 : Tensor "bf16[1, 2048][2048, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%empty_7, %sigmoid_1), kwargs = {})
#   %add_17 : Tensor "bf16[1, 2048][2048, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%selected_int8_experts, %mul_23), kwargs = {})
#   %view_20 : Tensor "bf16[1, 1, 2048][2048, 2048, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%add_17, [1, 1, 2048]), kwargs = {})
#   %add_18 : Tensor "bf16[1, 1, 2048][2048, 2048, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%add_13, %view_20), kwargs = {})
#   %convert_element_type_33 : Tensor "f32[1, 1, 2048][2048, 2048, 1]cuda:0"[num_users=2] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%add_18, torch.float32), kwargs = {})
#   %pow_7 : Tensor "f32[1, 1, 2048][2048, 2048, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.pow.Tensor_Scalar](args = (%convert_element_type_33, 2), kwargs = {})
#   %mean_6 : Tensor "f32[1, 1, 1][1, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mean.dim](args = (%pow_7, [-1], True), kwargs = {})
#   %add_19 : Tensor "f32[1, 1, 1][1, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%mean_6, 1e-06), kwargs = {})
#   %rsqrt_6 : Tensor "f32[1, 1, 1][1, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.rsqrt.default](args = (%add_19,), kwargs = {})
#   %mul_24 : Tensor "f32[1, 1, 2048][2048, 2048, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%convert_element_type_33, %rsqrt_6), kwargs = {})
#   %convert_element_type_34 : Tensor "f32[2048][1]cuda:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%arg29_1, torch.float32), kwargs = {})
#   %add_20 : Tensor "f32[2048][1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%convert_element_type_34, 1.0), kwargs = {})
#   %mul_25 : Tensor "f32[1, 1, 2048][2048, 2048, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%mul_24, %add_20), kwargs = {})
#   %convert_element_type_35 : Tensor "bf16[1, 1, 2048][2048, 2048, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%mul_25, torch.bfloat16), kwargs = {})
#   return %convert_element_type_33,%buf59,%convert_element_type_35
triton_per_fused__to_copy_add_mean_mm_mul_pow_rsqrt_sigmoid_view_19 = async_compile.triton('triton_per_fused__to_copy_add_mean_mm_mul_pow_rsqrt_sigmoid_view_19', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.persistent_reduction(
    size_hints={'x': 1, 'r0_': 2048},
    reduction_hint=ReductionHint.INNER,
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*bf16', 'in_ptr1': '*bf16', 'in_ptr2': '*bf16', 'in_ptr3': '*bf16', 'in_ptr4': '*fp32', 'in_ptr5': '*bf16', 'out_ptr2': '*bf16', 'xnumel': 'constexpr', 'r0_numel': 'i32', 'XBLOCK': 'constexpr'}, 'device': DeviceProperties(type='cuda', index=0, multi_processor_count=108, cc=80, major=8, regs_per_multiprocessor=65536, max_threads_per_multi_processor=2048, max_threads_per_block=1024, warp_size=32), 'constants': {'xnumel': 1}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]], (3,): [['tt.divisibility', 16]], (4,): [['tt.divisibility', 16]], (5,): [['tt.divisibility', 16]], (6,): [['tt.divisibility', 16]], (8,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'autotune_hints': set(), 'kernel_name': 'triton_per_fused__to_copy_add_mean_mm_mul_pow_rsqrt_sigmoid_view_19', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': None, 'atomic_add_found': False, 'num_load': 6, 'num_store': 1, 'num_reduction': 1, 'backend_hash': 'F7205DDDCE8E401A1728E5D602D369DE155D3FCCD3ACF038A9886E6E0DD93A54', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'max_autotune': True, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': False, 'are_deterministic_algorithms_enabled': False, 'coordinate_descent_tuning': True, 'coordinate_descent_search_radius': 1, 'coordinate_descent_check_all_directions': False, 'tiling_scores': {'r0_': 16384}}
)
@triton.jit
def triton_per_fused__to_copy_add_mean_mm_mul_pow_rsqrt_sigmoid_view_19(in_ptr0, in_ptr1, in_ptr2, in_ptr3, in_ptr4, in_ptr5, out_ptr2, xnumel, r0_numel, XBLOCK : tl.constexpr):
    xnumel = 1
    r0_numel = 2048
    R0_BLOCK: tl.constexpr = 2048
    rnumel = r0_numel
    RBLOCK: tl.constexpr = R0_BLOCK
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:, None]
    xmask = tl.full([XBLOCK], True, tl.int1)[:, None]
    r0_index = tl.arange(0, R0_BLOCK)[None, :]
    r0_offset = 0
    r0_mask = tl.full([R0_BLOCK], True, tl.int1)[None, :]
    roffset = r0_offset
    rindex = r0_index
    r0_0 = r0_index
    tmp0 = tl.load(in_ptr0 + (r0_0), None).to(tl.float32)
    tmp1 = tl.load(in_ptr1 + (r0_0), None).to(tl.float32)
    tmp3 = tl.load(in_ptr2 + (r0_0), None).to(tl.float32)
    tmp4 = tl.load(in_ptr3 + (r0_0), None).to(tl.float32)
    tmp5 = tl.load(in_ptr4 + (0))
    tmp6 = tl.broadcast_to(tmp5, [1, 1])
    tmp23 = tl.load(in_ptr5 + (r0_0), None).to(tl.float32)
    tmp2 = tmp0 + tmp1
    tmp7 = tmp6.to(tl.float32)
    tmp8 = tl.sigmoid(tmp7)
    tmp9 = tmp4 * tmp8
    tmp10 = tmp3 + tmp9
    tmp11 = tmp2 + tmp10
    tmp12 = tmp11.to(tl.float32)
    tmp13 = tmp12 * tmp12
    tmp14 = tl.broadcast_to(tmp13, [XBLOCK, R0_BLOCK])
    tmp16 = tl.sum(tmp14, 1)[:, None].to(tl.float32)
    tmp17 = tl.full([1, 1], 2048.0, tl.float32)
    tmp18 = (tmp16 / tmp17)
    tmp19 = tl.full([1, 1], 1e-06, tl.float32)
    tmp20 = tmp18 + tmp19
    tmp21 = libdevice.rsqrt(tmp20)
    tmp22 = tmp12 * tmp21
    tmp24 = tmp23.to(tl.float32)
    tmp25 = tl.full([1, 1], 1.0, tl.float32)
    tmp26 = tmp24 + tmp25
    tmp27 = tmp22 * tmp26
    tmp28 = tmp27.to(tl.float32)
    tl.store(out_ptr2 + (tl.broadcast_to(r0_0, [XBLOCK, R0_BLOCK])), tmp28, None)
''', device_str='cuda')


# kernel path: /tmp/infer-opt-models/q35moe-round-profile-20261109/inductor/ya/cya3abqye6kwqrojkia5b5h2cne4uysr7j5o3564dx6sl5mmt64t.py
# Topologically Sorted Source Nodes: [add_], Original ATen: [aten.add, aten.copy_]
# Source node to ATen node mapping:
#   add_ => add_21
# Graph fragment:
#   %copy_ : Tensor "i64[1][1]cuda:0" = PlaceHolder[target=copy_]
#   %add_21 : Tensor "i64[1][1]cuda:0" = PlaceHolder[target=add_21]
#   %slice_scatter_default_2 : Tensor "f32[1, 1, 32][32, 32, 1]cuda:0" = PlaceHolder[target=slice_scatter_default_2]
#   %mul_11 : Tensor "bf16[1, 16, 1, 64][1024, 64, 1024, 1]cuda:0" = PlaceHolder[target=mul_11]
#   %slice_scatter_default_3 : Tensor "f32[1, 1, 32][32, 32, 1]cuda:0" = PlaceHolder[target=slice_scatter_default_3]
#   %add_11 : Tensor "bf16[1, 16, 1, 64][4096, 256, 256, 1]cuda:0" = PlaceHolder[target=add_11]
#   %mul_13 : Tensor "bf16[1, 2, 1, 64][128, 64, 128, 1]cuda:0" = PlaceHolder[target=mul_13]
#   %add_12 : Tensor "bf16[1, 2, 1, 64][512, 256, 256, 1]cuda:0" = PlaceHolder[target=add_12]
#   %buf25 : Tensor "bf16[1, 2, 2048, 256][1048576, 524288, 256, 1]cuda:0" = PlaceHolder[target=buf25]
#   %buf26 : Tensor "bf16[1, 2, 2048, 256][1048576, 524288, 256, 1]cuda:0" = PlaceHolder[target=buf26]
#   %buf30 : Tensor  = PlaceHolder[target=buf30]
#   %buf31 : Tensor  = PlaceHolder[target=buf31]
#   %buf32 : Tensor  = PlaceHolder[target=buf32]
#   %add_21 : Tensor "i64[1][1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%arg2_1, 1), kwargs = {})
#   %copy_ : Tensor "i64[1][1]cuda:0"[num_users=0] = call_function[target=torch.ops.aten.copy_.default](args = (%arg2_1, %add_21), kwargs = {})
#   return %add_21,%buf79
triton_poi_fused_add_copy__20 = async_compile.triton('triton_poi_fused_add_copy__20', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.pointwise(
    size_hints={'x': 1}, 
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*i64', 'out_ptr1': '*i64', 'xnumel': 'constexpr', 'XBLOCK': 'constexpr'}, 'device': DeviceProperties(type='cuda', index=0, multi_processor_count=108, cc=80, major=8, regs_per_multiprocessor=65536, max_threads_per_multi_processor=2048, max_threads_per_block=1024, warp_size=32), 'constants': {'xnumel': 1}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'autotune_hints': set(), 'kernel_name': 'triton_poi_fused_add_copy__20', 'mutated_arg_names': ['in_ptr0', 'out_ptr1'], 'optimize_mem': True, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 1, 'num_store': 1, 'num_reduction': 0, 'backend_hash': 'F7205DDDCE8E401A1728E5D602D369DE155D3FCCD3ACF038A9886E6E0DD93A54', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'max_autotune': True, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': False, 'are_deterministic_algorithms_enabled': False, 'coordinate_descent_tuning': True, 'coordinate_descent_search_radius': 1, 'coordinate_descent_check_all_directions': False},
    min_elem_per_thread=0
)
@triton.jit
def triton_poi_fused_add_copy__20(in_ptr0, out_ptr1, xnumel, XBLOCK : tl.constexpr):
    xnumel = 1
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:]
    xmask = tl.full([XBLOCK], True, tl.int1)[:]
    tmp0 = tl.load(in_ptr0 + (0))
    tmp1 = tl.broadcast_to(tmp0, [XBLOCK])
    tmp2 = tl.full([1], 1, tl.int64)
    tmp3 = tmp1 + tmp2
    tl.store(out_ptr1 + (tl.full([XBLOCK], 0, tl.int32).broadcast_to(XBLOCK)), tmp3, None)
''', device_str='cuda')


async_compile.wait(globals())
del async_compile

class Runner:
    def __init__(self, partitions):
        self.partitions = partitions

    def recursively_apply_fns(self, fns):
        new_callables = []
        for fn, c in zip(fns, self.partitions):
            new_callables.append(fn(c))
        self.partitions = new_callables

    def call(self, args):
        arg0_1, arg1_1, arg2_1, arg3_1, arg4_1, arg5_1, arg6_1, arg7_1, arg8_1, arg9_1, arg10_1, arg11_1, arg12_1, arg13_1, arg14_1, arg15_1, arg16_1, arg17_1, arg18_1, arg19_1, arg20_1, arg21_1, arg22_1, arg23_1, arg24_1, arg25_1, arg26_1, arg27_1, arg28_1, arg29_1 = args
        args.clear()
        assert_size_stride(arg0_1, (248320, 2048), (2048, 1))
        assert_size_stride(arg1_1, (1, 1), (1, 1))
        assert_size_stride(arg2_1, (1, ), (1, ))
        assert_size_stride(arg3_1, (32, ), (1, ))
        assert_size_stride(arg4_1, (2048, ), (1, ))
        assert_size_stride(arg5_1, (1, 1, 2048), (2048, 2048, 1))
        assert_size_stride(arg6_1, (2048, ), (1, ))
        assert_size_stride(arg7_1, (2048, 4096), (4096, 1))
        assert_size_stride(arg8_1, (2048, 32), (32, 1))
        assert_size_stride(arg9_1, (2048, ), (1, ))
        assert_size_stride(arg10_1, (9216, 2048), (2048, 1))
        assert_size_stride(arg11_1, (9216, 16), (16, 1))
        assert_size_stride(arg12_1, (256, ), (1, ))
        assert_size_stride(arg13_1, (256, ), (1, ))
        assert_size_stride(arg14_1, (1, 2, 2048, 256), (1048576, 524288, 256, 1))
        assert_size_stride(arg15_1, (1, 2, 2048, 256), (1048576, 524288, 256, 1))
        assert_size_stride(arg16_1, (2048, 4096), (4096, 1))
        assert_size_stride(arg17_1, (2048, 32), (32, 1))
        assert_size_stride(arg18_1, (2048, ), (1, ))
        assert_size_stride(arg19_1, (256, 2048), (2048, 1))
        assert_size_stride(arg20_1, (256, 1024, 2048), (2097152, 2048, 1))
        assert_size_stride(arg21_1, (256, 1024, 16), (16384, 16, 1))
        assert_size_stride(arg22_1, (256, 2048, 512), (1048576, 512, 1))
        assert_size_stride(arg23_1, (256, 2048, 4), (8192, 4, 1))
        assert_size_stride(arg24_1, (1024, 2048), (2048, 1))
        assert_size_stride(arg25_1, (1024, 16), (16, 1))
        assert_size_stride(arg26_1, (2048, 512), (512, 1))
        assert_size_stride(arg27_1, (2048, 4), (4, 1))
        assert_size_stride(arg28_1, (1, 2048), (2048, 1))
        assert_size_stride(arg29_1, (2048, ), (1, ))
        with torch.cuda._DeviceGuard(0):
            torch.cuda.set_device(0)
            buf4 = empty_strided_cuda((1, 1, 4096), (4096, 4096, 1), torch.bfloat16)
            buf2 = reinterpret_tensor(buf4, (1, 1, 2048), (4096, 4096, 1), 0)  # alias
            # Topologically Sorted Source Nodes: [embeds, float_2, pow_1, mean, add_1, rsqrt, output, float_3, add_2, output_1, type_as], Original ATen: [aten.embedding, aten._to_copy, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul]
            stream0 = get_raw_stream(0)
            triton_per_fused__to_copy_add_embedding_mean_mul_pow_rsqrt_0.run(arg1_1, arg0_1, arg4_1, buf2, 1, 2048, stream=stream0)
            del arg0_1
            del arg1_1
            del arg4_1
            buf3 = reinterpret_tensor(buf4, (1, 1, 2048), (4096, 4096, 1), 2048)  # alias
            # Topologically Sorted Source Nodes: [float_4, pow_2, mean_1, add_3, rsqrt_1, output_2, float_5, add_4, output_3, type_as_1], Original ATen: [aten._to_copy, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul]
            stream0 = get_raw_stream(0)
            triton_per_fused__to_copy_add_mean_mul_pow_rsqrt_1.run(arg5_1, arg6_1, buf3, 1, 2048, stream=stream0)
            del arg5_1
            del arg6_1
            buf5 = empty_strided_cuda((1, 1, 2048), (2048, 2048, 1), torch.bfloat16)
            del buf2
            del buf3
            # Topologically Sorted Source Nodes: [y], Original ATen: []
            stream0 = get_raw_stream(0)
            _w8a16_group_gemv_kernel_0.run(buf4, arg7_1, arg8_1, buf5, 2048, 4096, 2048, 1, 1, stream=stream0)
            del arg7_1
            del arg8_1
            buf9 = empty_strided_cuda((1, 1, 2048), (2048, 2048, 1), torch.bfloat16)
            # Topologically Sorted Source Nodes: [float_6, pow_3, mean_2, add_5, rsqrt_2, output_4, float_7, add_6, output_5, hidden_states, y_1], Original ATen: [aten._to_copy, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul]
            stream0 = get_raw_stream(0)
            triton_per_fused__to_copy_add_mean_mul_pow_rsqrt_2.run(buf5, arg9_1, buf9, 1, 2048, stream=stream0)
            del arg9_1
            buf8 = empty_strided_cuda((1, 1, 9216), (9216, 9216, 1), torch.bfloat16)
            # Topologically Sorted Source Nodes: [float_6, pow_3, mean_2, add_5, rsqrt_2, output_4, float_7, add_6, output_5, hidden_states, y_1], Original ATen: [aten._to_copy, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul]
            stream0 = get_raw_stream(0)
            _w8a16_group_gemv_kernel_1.run(buf9, arg10_1, arg11_1, buf8, 9216, 2048, 9216, 1, 1, stream=stream0)
            del arg10_1
            del arg11_1
            del buf9
            buf11 = empty_strided_cuda((1, 1, 16, 1), (16, 16, 1, 16), torch.float32)
            # Topologically Sorted Source Nodes: [float_8, pow_4, mean_3], Original ATen: [aten.split_with_sizes, aten.view, aten.split, aten._to_copy, aten.pow, aten.mean]
            stream0 = get_raw_stream(0)
            triton_per_fused__to_copy_mean_pow_split_split_with_sizes_view_3.run(buf8, buf11, 16, 256, stream=stream0)
            buf12 = empty_strided_cuda((1, 1, 32), (32, 32, 1), torch.float32)
            buf15 = empty_strided_cuda((1, 1, 32), (32, 32, 1), torch.float32)
            # Topologically Sorted Source Nodes: [arange, positions, view, expand, position_ids, getitem, float_1, to, freqs, cos, getitem_2, sin, getitem_5, setitem_1, setitem_3], Original ATen: [aten.arange, aten.add, aten.view, aten.expand, aten.unsqueeze, aten._to_copy, aten.mul, aten.cos, aten.select, aten.slice, aten.sin]
            stream0 = get_raw_stream(0)
            triton_poi_fused__to_copy_add_arange_cos_expand_mul_select_sin_slice_unsqueeze_view_4.run(arg2_1, arg3_1, buf12, buf15, 32, stream=stream0)
            buf18 = reinterpret_tensor(buf4, (1, 16, 1, 256), (4096, 256, 256, 1), 0); del buf4  # reuse
            buf16 = reinterpret_tensor(buf18, (1, 16, 1, 64), (4096, 256, 256, 1), 0)  # alias
            # Topologically Sorted Source Nodes: [arange, positions, view, expand, position_ids, getitem, float_1, to, freqs, cos, getitem_2, sin, getitem_5, float_8, pow_4, mean_3, add_7, rsqrt_3, output_6, float_9, add_8, output_7, type_as_3, query_states_1, q_rot, cos_1, cos_2, cos_3, mul_11, x2, neg, x1, cat_3, sin_1, sin_2, sin_3, mul_12, q_embed], Original ATen: [aten.arange, aten.add, aten.view, aten.expand, aten.unsqueeze, aten._to_copy, aten.mul, aten.cos, aten.select, aten.slice, aten.sin, aten.split_with_sizes, aten.split, aten.pow, aten.mean, aten.rsqrt, aten.transpose, aten.cat, aten.neg]
            stream0 = get_raw_stream(0)
            triton_poi_fused__to_copy_add_arange_cat_cos_expand_mean_mul_neg_pow_rsqrt_select_sin_slice_split_split_with_sizes_transpose_unsqueeze_view_5.run(buf8, buf11, arg12_1, buf12, arg2_1, arg3_1, buf15, buf16, 1024, stream=stream0)
            buf17 = reinterpret_tensor(buf18, (1, 16, 1, 192), (4096, 256, 256, 1), 64)  # alias
            # Topologically Sorted Source Nodes: [float_8, pow_4, mean_3, add_7, rsqrt_3, output_6, float_9, add_8, output_7, type_as_3, query_states_1, q_pass, query_states_2], Original ATen: [aten.split_with_sizes, aten.view, aten.split, aten._to_copy, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.transpose, aten.slice, aten.cat]
            stream0 = get_raw_stream(0)
            triton_poi_fused__to_copy_add_cat_mean_mul_pow_rsqrt_slice_split_split_with_sizes_transpose_view_6.run(buf8, buf11, arg12_1, buf17, 3072, stream=stream0)
            del arg12_1
            buf19 = empty_strided_cuda((1, 1, 2, 1), (2, 2, 1, 2), torch.float32)
            # Topologically Sorted Source Nodes: [float_10, pow_5, mean_4], Original ATen: [aten.split_with_sizes, aten.view, aten._to_copy, aten.pow, aten.mean]
            stream0 = get_raw_stream(0)
            triton_per_fused__to_copy_mean_pow_split_with_sizes_view_7.run(buf8, buf19, 2, 256, stream=stream0)
            del buf16
            del buf17
            buf24 = empty_strided_cuda((1, 2, 1, 256), (512, 256, 256, 1), torch.bfloat16)
            buf22 = reinterpret_tensor(buf24, (1, 2, 1, 64), (512, 256, 256, 1), 0)  # alias
            # Topologically Sorted Source Nodes: [arange, positions, view, expand, position_ids, getitem, float_1, to, freqs, cos, getitem_2, sin, getitem_5, float_10, cos_1, cos_2, cos_3, sin_1, sin_2, sin_3, pow_5, mean_4, add_9, rsqrt_4, output_8, float_11, add_10, output_9, type_as_4, key_states, k_rot, mul_13, x2_1, neg_1, x1_1, cat_4, mul_14, k_embed], Original ATen: [aten.arange, aten.add, aten.view, aten.expand, aten.unsqueeze, aten._to_copy, aten.mul, aten.cos, aten.select, aten.slice, aten.sin, aten.split_with_sizes, aten.cat, aten.pow, aten.mean, aten.rsqrt, aten.transpose, aten.neg]
            stream0 = get_raw_stream(0)
            triton_poi_fused__to_copy_add_arange_cat_cos_expand_mean_mul_neg_pow_rsqrt_select_sin_slice_split_with_sizes_transpose_unsqueeze_view_8.run(buf8, buf19, arg13_1, buf12, arg2_1, arg3_1, buf15, buf22, 128, stream=stream0)
            del arg3_1
            del buf12
            del buf15
            buf23 = reinterpret_tensor(buf24, (1, 2, 1, 192), (512, 256, 256, 1), 64)  # alias
            # Topologically Sorted Source Nodes: [float_10, pow_5, mean_4, add_9, rsqrt_4, output_8, float_11, add_10, output_9, type_as_4, key_states, k_pass, key_states_1], Original ATen: [aten.split_with_sizes, aten.view, aten._to_copy, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.transpose, aten.slice, aten.cat]
            stream0 = get_raw_stream(0)
            triton_poi_fused__to_copy_add_cat_mean_mul_pow_rsqrt_slice_split_with_sizes_transpose_view_9.run(buf8, buf19, arg13_1, buf23, 384, stream=stream0)
            del arg13_1
            del buf19
            # Topologically Sorted Source Nodes: [index_copy_], Original ATen: [aten.index_copy]
            stream0 = get_raw_stream(0)
            triton_poi_fused_index_copy_10.run(arg2_1, buf24, arg14_1, 512, stream=stream0)
            del buf22
            del buf23
            del buf24
            # Topologically Sorted Source Nodes: [index_copy__1], Original ATen: [aten.split_with_sizes, aten.view, aten.transpose, aten.index_copy]
            stream0 = get_raw_stream(0)
            triton_poi_fused_index_copy_split_with_sizes_transpose_view_11.run(arg2_1, buf8, arg15_1, 512, stream=stream0)
            buf27 = empty_strided_cuda((1, 2, 32, 8), (512, 256, 8, 1), torch.float32)
            buf28 = empty_strided_cuda((1, 2, 32, 8), (512, 256, 8, 1), torch.float32)
            buf29 = empty_strided_cuda((1, 2, 32, 8, 256), (131072, 65536, 2048, 256, 1), torch.float32)
            # Topologically Sorted Source Nodes: [query, decode_attention_partials_default], Original ATen: [aten.view]
            stream0 = get_raw_stream(0)
            _decode_attention_kernel_2.run(reinterpret_tensor(buf18, (1, 2, 8, 256), (4096, 2048, 256, 1), 0), arg14_1, arg15_1, arg2_1, buf27, buf28, buf29, 2048, 0.0625, 2, 32, 1, stream=stream0)
            del arg14_1
            del arg15_1
            buf33 = reinterpret_tensor(buf11, (1, 2, 1, 8), (16, 8, 16, 1), 0); del buf11  # reuse
            buf35 = empty_strided_cuda((1, 2, 8), (16, 8, 1), torch.float32)
            # Topologically Sorted Source Nodes: [amax, sub, weight, mul_16, sum_2], Original ATen: [aten.amax, aten.sub, aten.exp, aten.mul, aten.sum]
            stream0 = get_raw_stream(0)
            triton_per_fused_amax_exp_mul_sub_sum_12.run(buf27, buf28, buf33, buf35, 16, 32, stream=stream0)
            del buf28
            buf37 = reinterpret_tensor(buf18, (1, 1, 4096), (4096, 4096, 1), 0); del buf18  # reuse
            # Topologically Sorted Source Nodes: [gate_1, sub, weight, unsqueeze_2, mul_15, sum_1, unsqueeze_3, out, attn_output, attn_output_1, transpose_3, reshape_2, sigmoid, attn_output_4, y_2], Original ATen: [aten.split_with_sizes, aten.view, aten.split, aten.sub, aten.exp, aten.unsqueeze, aten.mul, aten.sum, aten.div, aten._to_copy, aten.transpose, aten.clone, aten._unsafe_view, aten.sigmoid]
            stream0 = get_raw_stream(0)
            triton_per_fused__to_copy__unsafe_view_clone_div_exp_mul_sigmoid_split_split_with_sizes_sub_sum_transpose_unsqueeze_view_13.run(buf27, buf33, buf29, buf35, buf8, buf37, 4096, 32, stream=stream0)
            del buf27
            del buf29
            del buf33
            del buf35
            del buf8
            buf36 = empty_strided_cuda((1, 1, 2048), (2048, 2048, 1), torch.bfloat16)
            # Topologically Sorted Source Nodes: [gate_1, unsqueeze_3, out, attn_output, attn_output_1, transpose_3, reshape_2, sigmoid, attn_output_4, y_2], Original ATen: [aten.split_with_sizes, aten.view, aten.split, aten.unsqueeze, aten.div, aten._to_copy, aten.transpose, aten.clone, aten._unsafe_view, aten.sigmoid, aten.mul]
            stream0 = get_raw_stream(0)
            _w8a16_group_gemv_kernel_0.run(buf37, arg16_1, arg17_1, buf36, 2048, 4096, 2048, 1, 1, stream=stream0)
            del arg16_1
            del arg17_1
            del buf37
            buf40 = empty_strided_cuda((1, 1, 2048), (2048, 2048, 1), torch.bfloat16)
            buf57 = empty_strided_cuda((1, 1), (1, 1), torch.float32)
            # Topologically Sorted Source Nodes: [hidden_states_1, float_12, pow_6, mean_5, add_14, rsqrt_5, output_10, float_13, add_15, output_11, hidden_states_2, x, linear_1], Original ATen: [aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul, aten.view, aten.mm, aten.t]
            stream0 = get_raw_stream(0)
            triton_per_fused__to_copy_add_mean_mm_mul_pow_rsqrt_t_view_14.run(buf5, buf36, arg18_1, arg28_1, buf40, buf57, 1, 2048, stream=stream0)
            del arg18_1
            del arg28_1
            buf41 = empty_strided_cuda((1, 256), (256, 1), torch.float32)
            # Topologically Sorted Source Nodes: [hidden_states_1, float_12, pow_6, mean_5, add_14, rsqrt_5, output_10, float_13, add_15, output_11, hidden_states_2, x, logits], Original ATen: [aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul, aten.view, aten.mm, aten.t]
            stream0 = get_raw_stream(0)
            triton_per_fused__to_copy_add_mean_mm_mul_pow_rsqrt_t_view_15.run(buf40, arg19_1, buf41, 256, 2048, stream=stream0)
            del arg19_1
            buf44 = buf41; del buf41  # reuse
            # Topologically Sorted Source Nodes: [probs], Original ATen: [prims.prepare_softmax_online, aten.sub, aten.exp, aten._softmax]
            stream0 = get_raw_stream(0)
            triton_per_fused__softmax_exp_prepare_softmax_online_sub_16.run(buf44, 1, 256, stream=stream0)
            # Topologically Sorted Source Nodes: [probs, topk], Original ATen: [aten.sub, aten.exp, aten._softmax, aten.topk]
            buf45 = torch.ops.aten.topk.default(buf44, 8)
            del buf44
            buf46 = buf45[0]
            assert_size_stride(buf46, (1, 8), (8, 1), 'torch.ops.aten.topk.default')
            assert_alignment(buf46, 16, 'torch.ops.aten.topk.default')
            buf47 = buf45[1]
            assert_size_stride(buf47, (1, 8), (8, 1), 'torch.ops.aten.topk.default')
            assert_alignment(buf47, 16, 'torch.ops.aten.topk.default')
            del buf45
            buf48 = empty_strided_cuda((1, 1024), (1024, 1), torch.bfloat16)
            # Topologically Sorted Source Nodes: [hidden_states_1, float_12, pow_6, mean_5, add_14, rsqrt_5, output_10, float_13, add_15, output_11, hidden_states_2, x, y_3], Original ATen: [aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul, aten.view]
            stream0 = get_raw_stream(0)
            _w8a16_group_gemv_kernel_3.run(reinterpret_tensor(buf40, (1, 2048), (2048, 1), 0), arg24_1, arg25_1, buf48, 1024, 2048, 1024, 1, 1, stream=stream0)
            del arg24_1
            del arg25_1
            buf50 = empty_strided_cuda((1, 2048), (2048, 1), torch.bfloat16)
            buf51 = empty_strided_cuda((1, 512), (512, 1), torch.bfloat16)
            # Topologically Sorted Source Nodes: [silu, mul_20, y_4], Original ATen: [aten.split, aten.silu, aten.mul]
            stream0 = get_raw_stream(0)
            triton_poi_fused_mul_silu_split_17.run(buf48, buf51, 512, stream=stream0)
            del buf48
            # Topologically Sorted Source Nodes: [silu, mul_20, y_4], Original ATen: [aten.split, aten.silu, aten.mul]
            stream0 = get_raw_stream(0)
            _w8a16_group_gemv_kernel_4.run(buf51, arg26_1, arg27_1, buf50, 2048, 512, 2048, 1, 1, stream=stream0)
            del arg26_1
            del arg27_1
            del buf51
            buf54 = empty_strided_cuda((1, 8), (8, 1), torch.bfloat16)
            # Topologically Sorted Source Nodes: [hidden_states_1, float_12, pow_6, mean_5, add_14, rsqrt_5, output_10, float_13, add_15, output_11, hidden_states_2, x, sum_3, truediv_1, weights_1, routed], Original ATen: [aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul, aten.view, aten.sum, aten.div, infer_opt.selected_int8_experts]
            stream0 = get_raw_stream(0)
            triton_per_fused__to_copy_add_div_mean_mul_pow_rsqrt_selected_int8_experts_sum_view_18.run(buf46, buf54, 1, 8, stream=stream0)
            del buf46
            # Topologically Sorted Source Nodes: [hidden_states_1, float_12, pow_6, mean_5, add_14, rsqrt_5, output_10, float_13, add_15, output_11, hidden_states_2, x, truediv_1, weights_1, routed], Original ATen: [aten.add, aten._to_copy, aten.pow, aten.mean, aten.rsqrt, aten.mul, aten.view, aten.div, infer_opt.selected_int8_experts]
            buf55 = torch.ops.infer_opt.selected_int8_experts.default(reinterpret_tensor(buf40, (1, 2048), (2048, 1), 0), buf47, buf54, arg20_1, arg21_1, arg22_1, arg23_1)
            del arg20_1
            del arg21_1
            del arg22_1
            del arg23_1
            del buf47
            del buf54
            buf56 = buf55
            assert_size_stride(buf56, (1, 2048), (2048, 1), 'torch.ops.infer_opt.selected_int8_experts.default')
            assert_alignment(buf56, 16, 'torch.ops.infer_opt.selected_int8_experts.default')
            del buf55
            buf60 = buf40; del buf40  # reuse
            # Topologically Sorted Source Nodes: [hidden_states_1, linear_1, sigmoid_1, shared, add_16, hidden_states_3, add_17, float_14, pow_7, mean_6, add_18, rsqrt_6, output_12, float_15, add_19, output_13, out_1], Original ATen: [aten.add, aten.mm, aten.sigmoid, aten.mul, aten.view, aten._to_copy, aten.pow, aten.mean, aten.rsqrt]
            stream0 = get_raw_stream(0)
            triton_per_fused__to_copy_add_mean_mm_mul_pow_rsqrt_sigmoid_view_19.run(buf5, buf36, buf56, buf50, buf57, arg29_1, buf60, 1, 2048, stream=stream0)
            del arg29_1
            del buf36
            del buf5
            del buf50
            del buf56
            del buf57
            # Topologically Sorted Source Nodes: [add_], Original ATen: [aten.add, aten.copy_]
            stream0 = get_raw_stream(0)
            triton_poi_fused_add_copy__20.run(arg2_1, arg2_1, 1, stream=stream0)
            del arg2_1
        return (buf60, )

runner = Runner(partitions=[])
call = runner.call
recursively_apply_fns = runner.recursively_apply_fns


def get_args():
    from torch._dynamo.testing import rand_strided
    arg0_1 = rand_strided((248320, 2048), (2048, 1), device='cuda:0', dtype=torch.bfloat16)
    arg1_1 = rand_strided((1, 1), (1, 1), device='cuda:0', dtype=torch.int64)
    arg2_1 = rand_strided((1, ), (1, ), device='cuda:0', dtype=torch.int64)
    arg3_1 = rand_strided((32, ), (1, ), device='cuda:0', dtype=torch.bfloat16)
    arg4_1 = rand_strided((2048, ), (1, ), device='cuda:0', dtype=torch.bfloat16)
    arg5_1 = rand_strided((1, 1, 2048), (2048, 2048, 1), device='cuda:0', dtype=torch.bfloat16)
    arg6_1 = rand_strided((2048, ), (1, ), device='cuda:0', dtype=torch.bfloat16)
    arg7_1 = rand_strided((2048, 4096), (4096, 1), device='cuda:0', dtype=torch.int8)
    arg8_1 = rand_strided((2048, 32), (32, 1), device='cuda:0', dtype=torch.bfloat16)
    arg9_1 = rand_strided((2048, ), (1, ), device='cuda:0', dtype=torch.bfloat16)
    arg10_1 = rand_strided((9216, 2048), (2048, 1), device='cuda:0', dtype=torch.int8)
    arg11_1 = rand_strided((9216, 16), (16, 1), device='cuda:0', dtype=torch.bfloat16)
    arg12_1 = rand_strided((256, ), (1, ), device='cuda:0', dtype=torch.bfloat16)
    arg13_1 = rand_strided((256, ), (1, ), device='cuda:0', dtype=torch.bfloat16)
    arg14_1 = rand_strided((1, 2, 2048, 256), (1048576, 524288, 256, 1), device='cuda:0', dtype=torch.bfloat16)
    arg15_1 = rand_strided((1, 2, 2048, 256), (1048576, 524288, 256, 1), device='cuda:0', dtype=torch.bfloat16)
    arg16_1 = rand_strided((2048, 4096), (4096, 1), device='cuda:0', dtype=torch.int8)
    arg17_1 = rand_strided((2048, 32), (32, 1), device='cuda:0', dtype=torch.bfloat16)
    arg18_1 = rand_strided((2048, ), (1, ), device='cuda:0', dtype=torch.bfloat16)
    arg19_1 = rand_strided((256, 2048), (2048, 1), device='cuda:0', dtype=torch.bfloat16)
    arg20_1 = rand_strided((256, 1024, 2048), (2097152, 2048, 1), device='cuda:0', dtype=torch.int8)
    arg21_1 = rand_strided((256, 1024, 16), (16384, 16, 1), device='cuda:0', dtype=torch.bfloat16)
    arg22_1 = rand_strided((256, 2048, 512), (1048576, 512, 1), device='cuda:0', dtype=torch.int8)
    arg23_1 = rand_strided((256, 2048, 4), (8192, 4, 1), device='cuda:0', dtype=torch.bfloat16)
    arg24_1 = rand_strided((1024, 2048), (2048, 1), device='cuda:0', dtype=torch.int8)
    arg25_1 = rand_strided((1024, 16), (16, 1), device='cuda:0', dtype=torch.bfloat16)
    arg26_1 = rand_strided((2048, 512), (512, 1), device='cuda:0', dtype=torch.int8)
    arg27_1 = rand_strided((2048, 4), (4, 1), device='cuda:0', dtype=torch.bfloat16)
    arg28_1 = rand_strided((1, 2048), (2048, 1), device='cuda:0', dtype=torch.bfloat16)
    arg29_1 = rand_strided((2048, ), (1, ), device='cuda:0', dtype=torch.bfloat16)
    return [arg0_1, arg1_1, arg2_1, arg3_1, arg4_1, arg5_1, arg6_1, arg7_1, arg8_1, arg9_1, arg10_1, arg11_1, arg12_1, arg13_1, arg14_1, arg15_1, arg16_1, arg17_1, arg18_1, arg19_1, arg20_1, arg21_1, arg22_1, arg23_1, arg24_1, arg25_1, arg26_1, arg27_1, arg28_1, arg29_1]


def benchmark_compiled_module(args, times=10, repeat=10):
    from torch._inductor.utils import print_performance
    fn = lambda: call(list(args))
    return print_performance(fn, times=times, repeat=repeat)


if __name__ == "__main__":
    from torch._inductor.wrapper_benchmark import compiled_module_main
    args = get_args()
    compiled_module_main('None', lambda times, repeat: benchmark_compiled_module(args, times=times, repeat=repeat))
