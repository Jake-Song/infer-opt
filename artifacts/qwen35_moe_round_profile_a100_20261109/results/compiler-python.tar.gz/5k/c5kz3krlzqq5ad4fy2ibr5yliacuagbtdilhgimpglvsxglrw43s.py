

import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties

@triton_heuristics.user_autotune(
    configs=[{'num_warps': 1, 'num_stages': 3}],
    inductor_meta={'grid_type': 'FixedGrid', 'fixed_grid': ['_grid_0', '_grid_1', '_grid_2'], 'extra_launcher_args': ['_grid_0', '_grid_1', '_grid_2'], 'kernel_name': '_gated_delta_verify_kernel_1', 'backend_hash': 'F7205DDDCE8E401A1728E5D602D369DE155D3FCCD3ACF038A9886E6E0DD93A54', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'max_autotune': True, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': False, 'are_deterministic_algorithms_enabled': False, 'coordinate_descent_tuning': True, 'coordinate_descent_search_radius': 1, 'coordinate_descent_check_all_directions': False},
    triton_meta={'signature': {'q_ptr': '*bf16', 'k_ptr': '*bf16', 'v_ptr': '*bf16', 'g_ptr': '*fp32', 'beta_ptr': '*bf16', 'h0_ptr': '*fp32', 'states_ptr': '*fp32', 'o_ptr': '*bf16', 'scale': 'fp64', 'NH': 'i32', 'T': 'constexpr', 'H': 'constexpr', 'HV': 'constexpr', 'K': 'constexpr', 'V': 'constexpr', 'BV': 'constexpr'}, 'device': DeviceProperties(type='cuda', index=0, multi_processor_count=108, cc=80, major=8, regs_per_multiprocessor=65536, max_threads_per_multi_processor=2048, max_threads_per_block=1024, warp_size=32), 'constants': {'T': 2, 'H': 16, 'HV': 32, 'K': 128, 'V': 128, 'BV': 8}, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]], (3,): [['tt.divisibility', 16]], (4,): [['tt.divisibility', 16]], (5,): [['tt.divisibility', 16]], (6,): [['tt.divisibility', 16]], (7,): [['tt.divisibility', 16]], (9,): [['tt.divisibility', 16]]}]},
    filename=__file__,
    custom_kernel=True,
)
@triton.jit
def _gated_delta_verify_kernel(q_ptr, k_ptr, v_ptr, g_ptr, beta_ptr, h0_ptr, states_ptr, o_ptr, scale, NH,
                               T: tl.constexpr, H: tl.constexpr, HV: tl.constexpr, K: tl.constexpr,
                               V: tl.constexpr, BV: tl.constexpr):
    pid = tl.program_id(0).to(tl.int64)
    NV: tl.constexpr = V // BV
    i_v, i_nh = pid % NV, pid // NV  # i_nh: batch * HV + value head
    i_n, i_hv = i_nh // HV, i_nh % HV
    i_h = i_hv // (HV // H)
    o_k = tl.arange(0, K)
    o_v = i_v * BV + tl.arange(0, BV)
    block = o_k[:, None] * V + o_v[None, :]
    b_h = tl.load(h0_ptr + i_nh * K * V + block).to(tl.float32)
    for t in tl.static_range(T):
        row = i_n * T + t  # token t of sequence i_n in the [B, T, ...] inputs
        b_q = tl.load(q_ptr + (row * H + i_h) * K + o_k).to(tl.float32)
        b_k = tl.load(k_ptr + (row * H + i_h) * K + o_k).to(tl.float32)
        b_v = tl.load(v_ptr + (row * HV + i_hv) * V + o_v).to(tl.float32)
        b_q = b_q / tl.sqrt(tl.sum(b_q * b_q) + 1e-6)
        b_k = b_k / tl.sqrt(tl.sum(b_k * b_k) + 1e-6)
        b_q = b_q * scale
        b_beta = tl.load(beta_ptr + row * HV + i_hv).to(tl.float32)
        b_h *= tl.exp(tl.load(g_ptr + row * HV + i_hv).to(tl.float32))
        b_v = b_beta * (b_v - tl.sum(b_h * b_k[:, None], 0))
        b_h += b_k[:, None] * b_v
        b_o = tl.sum(b_h * b_q[:, None], 0)
        tl.store(o_ptr + (row * HV + i_hv) * V + o_v, b_o.to(o_ptr.dtype.element_ty))
        tl.store(states_ptr + (t * NH + i_nh) * K * V + block, b_h)  # states: [T, B, HV, K, V]
