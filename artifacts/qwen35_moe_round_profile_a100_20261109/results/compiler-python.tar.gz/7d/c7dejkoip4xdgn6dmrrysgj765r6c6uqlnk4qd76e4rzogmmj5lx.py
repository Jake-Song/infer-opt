# AOT ID: ['4_inference']
from ctypes import c_void_p, c_long, c_int
import torch
import math
import random
import os
import tempfile
from math import inf, nan
from cmath import nanj
from torch._inductor.hooks import run_intermediate_hooks
from torch._inductor.utils import maybe_profile
from torch._inductor.codegen.memory_planning import _align as align
from torch import device, empty_strided
from torch._inductor.async_compile import AsyncCompile
from torch._inductor.select_algorithm import extern_kernels
import triton
import triton.language as tl
from torch._inductor.runtime.triton_heuristics import start_graph, end_graph
from torch._C import _cuda_getCurrentRawStream as get_raw_stream

aten = torch.ops.aten
inductor_ops = torch.ops.inductor
_quantized = torch.ops._quantized
assert_size_stride = torch._C._dynamo.guards.assert_size_stride
assert_alignment = torch._C._dynamo.guards.assert_alignment
empty_strided_cpu = torch._C._dynamo.guards._empty_strided_cpu
empty_strided_cpu_pinned = torch._C._dynamo.guards._empty_strided_cpu_pinned
empty_strided_cuda = torch._C._dynamo.guards._empty_strided_cuda
empty_strided_xpu = torch._C._dynamo.guards._empty_strided_xpu
empty_strided_mtia = torch._C._dynamo.guards._empty_strided_mtia
reinterpret_tensor = torch._C._dynamo.guards._reinterpret_tensor
alloc_from_pool = torch.ops.inductor._alloc_from_pool
async_compile = AsyncCompile()
empty_strided_p2p = torch._C._distributed_c10d._SymmetricMemory.empty_strided_p2p


# kernel path: /tmp/infer-opt-models/q35moe-round-profile-20261109/inductor/g4/cg4ein4yrf4amm7sqqleabf5dmip4zcqk2cq42y5peeoy2dwwtv5.py
# Topologically Sorted Source Nodes: [embeds, float_2, pow_1, mean, add_1, rsqrt, output, float_3, add_2, output_1, type_as], Original ATen: [aten.embedding, aten._to_copy, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul]
# Source node to ATen node mapping:
#   add_1 => add_1
#   add_2 => add_2
#   embeds => embedding
#   float_2 => convert_element_type_4
#   float_3 => convert_element_type_5
#   mean => mean
#   output => mul_1
#   output_1 => mul_2
#   pow_1 => pow_1
#   rsqrt => rsqrt
#   type_as => convert_element_type_6
# Graph fragment:
#   %arg1_1 : Tensor "i64[1, 2][2, 1]cuda:0" = PlaceHolder[target=arg1_1]
#   %arg0_1 : Tensor "bf16[248320, 2048][2048, 1]cuda:0" = PlaceHolder[target=arg0_1]
#   %buf0 : Tensor "f32[1, 2, 1][2, 1, 2]cuda:0" = PlaceHolder[target=buf0]
#   %arg4_1 : Tensor "bf16[2048][1]cuda:0" = PlaceHolder[target=arg4_1]
#   %embedding : Tensor "bf16[1, 2, 2048][4096, 2048, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.embedding.default](args = (%arg0_1, %arg1_1), kwargs = {})
#   %convert_element_type_4 : Tensor "f32[1, 2, 2048][4096, 2048, 1]cuda:0"[num_users=2] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%embedding, torch.float32), kwargs = {})
#   %pow_1 : Tensor "f32[1, 2, 2048][4096, 2048, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.pow.Tensor_Scalar](args = (%convert_element_type_4, 2), kwargs = {})
#   %mean : Tensor "f32[1, 2, 1][2, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mean.dim](args = (%pow_1, [-1], True), kwargs = {})
#   %add_1 : Tensor "f32[1, 2, 1][2, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%mean, 1e-06), kwargs = {})
#   %rsqrt : Tensor "f32[1, 2, 1][2, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.rsqrt.default](args = (%add_1,), kwargs = {})
#   %mul_1 : Tensor "f32[1, 2, 2048][4096, 2048, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%convert_element_type_4, %rsqrt), kwargs = {})
#   %convert_element_type_5 : Tensor "f32[2048][1]cuda:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%arg4_1, torch.float32), kwargs = {})
#   %add_2 : Tensor "f32[2048][1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%convert_element_type_5, 1.0), kwargs = {})
#   %mul_2 : Tensor "f32[1, 2, 2048][4096, 2048, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%mul_1, %add_2), kwargs = {})
#   %convert_element_type_6 : Tensor "bf16[1, 2, 2048][4096, 2048, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%mul_2, torch.bfloat16), kwargs = {})
#   return %buf0,%convert_element_type_6
triton_red_fused__to_copy_add_embedding_mean_mul_pow_rsqrt_0 = async_compile.triton('triton_red_fused__to_copy_add_embedding_mean_mul_pow_rsqrt_0', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.reduction(
    size_hints={'x': 2, 'r0_': 2048},
    reduction_hint=ReductionHint.INNER,
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*i64', 'in_ptr1': '*bf16', 'in_ptr2': '*bf16', 'out_ptr1': '*bf16', 'xnumel': 'i32', 'r0_numel': 'i32', 'XBLOCK': 'constexpr', 'R0_BLOCK': 'constexpr'}, 'device': DeviceProperties(type='cuda', index=0, multi_processor_count=108, cc=80, major=8, regs_per_multiprocessor=65536, max_threads_per_multi_processor=2048, max_threads_per_block=1024, warp_size=32), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]], (3,): [['tt.divisibility', 16]], (5,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'autotune_hints': set(), 'kernel_name': 'triton_red_fused__to_copy_add_embedding_mean_mul_pow_rsqrt_0', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 2, 'num_store': 1, 'num_reduction': 1, 'backend_hash': 'F7205DDDCE8E401A1728E5D602D369DE155D3FCCD3ACF038A9886E6E0DD93A54', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'max_autotune': True, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': False, 'are_deterministic_algorithms_enabled': False, 'coordinate_descent_tuning': True, 'coordinate_descent_search_radius': 1, 'coordinate_descent_check_all_directions': False, 'tiling_scores': {'x': 4, 'r0_': 20480}}
)
@triton.jit
def triton_red_fused__to_copy_add_embedding_mean_mul_pow_rsqrt_0(in_ptr0, in_ptr1, in_ptr2, out_ptr1, xnumel, r0_numel, XBLOCK : tl.constexpr, R0_BLOCK : tl.constexpr):
    xnumel = 2
    r0_numel = 2048
    rnumel = r0_numel
    RBLOCK: tl.constexpr = R0_BLOCK
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:, None]
    xmask = xindex < xnumel
    r0_base = tl.arange(0, R0_BLOCK)[None, :]
    rbase = r0_base
    x0 = xindex
    tmp0 = tl.load(in_ptr0 + (x0), xmask, eviction_policy='evict_last')
    _tmp10 = tl.full([XBLOCK, R0_BLOCK], 0, tl.float32)
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_1 = r0_index
        tmp1 = tl.full([1, 1], 248320, tl.int32)
        tmp2 = tmp0 + tmp1
        tmp3 = tmp0 < 0
        tmp4 = tl.where(tmp3, tmp2, tmp0)
        tl.device_assert(((0 <= tmp4) & (tmp4 < 248320)) | ~(xmask), "index out of bounds: 0 <= tmp4 < 248320")
        tmp6 = tl.load(in_ptr1 + (r0_1 + 2048*tmp4), r0_mask & xmask, eviction_policy='evict_last', other=0.0).to(tl.float32)
        tmp7 = tmp6.to(tl.float32)
        tmp8 = tmp7 * tmp7
        tmp9 = tl.broadcast_to(tmp8, [XBLOCK, R0_BLOCK])
        tmp11 = _tmp10 + tmp9
        _tmp10 = tl.where(r0_mask & xmask, tmp11, _tmp10)
    tmp10 = tl.sum(_tmp10, 1)[:, None]
    for r0_offset in tl.range(0, r0_numel, R0_BLOCK):
        r0_index = r0_offset + r0_base
        r0_mask = r0_index < r0_numel
        roffset = r0_offset
        rindex = r0_index
        r0_1 = r0_index
        tmp25 = tl.load(in_ptr2 + (r0_1), r0_mask, eviction_policy='evict_last', other=0.0).to(tl.float32)
        tmp12 = tl.full([1, 1], 248320, tl.int32)
        tmp13 = tmp0 + tmp12
        tmp14 = tmp0 < 0
        tmp15 = tl.where(tmp14, tmp13, tmp0)
        tl.device_assert(((0 <= tmp15) & (tmp15 < 248320)) | ~(xmask), "index out of bounds: 0 <= tmp15 < 248320")
        tmp17 = tl.load(in_ptr1 + (r0_1 + 2048*tmp15), r0_mask & xmask, eviction_policy='evict_first', other=0.0).to(tl.float32)
        tmp18 = tmp17.to(tl.float32)
        tmp19 = tl.full([1, 1], 2048.0, tl.float32)
        tmp20 = (tmp10 / tmp19)
        tmp21 = tl.full([1, 1], 1e-06, tl.float32)
        tmp22 = tmp20 + tmp21
        tmp23 = libdevice.rsqrt(tmp22)
        tmp24 = tmp18 * tmp23
        tmp26 = tmp25.to(tl.float32)
        tmp27 = tl.full([1, 1], 1.0, tl.float32)
        tmp28 = tmp26 + tmp27
        tmp29 = tmp24 * tmp28
        tmp30 = tmp29.to(tl.float32)
        tl.store(out_ptr1 + (r0_1 + 4096*x0), tmp30, r0_mask & xmask)
''', device_str='cuda')


# kernel path: /tmp/infer-opt-models/q35moe-round-profile-20261109/inductor/fh/cfhssbztsui6u2xvyn4fccw2g2jzu26nk2wjkfhirees6ftjrt4y.py
# Topologically Sorted Source Nodes: [float_4, pow_2, mean_1, add_3, rsqrt_1, output_2, float_5, add_4, output_3, type_as_1], Original ATen: [aten._to_copy, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul]
# Source node to ATen node mapping:
#   add_3 => add_3
#   add_4 => add_4
#   float_4 => convert_element_type_7
#   float_5 => convert_element_type_8
#   mean_1 => mean_1
#   output_2 => mul_3
#   output_3 => mul_4
#   pow_2 => pow_2
#   rsqrt_1 => rsqrt_1
#   type_as_1 => convert_element_type_9
# Graph fragment:
#   %arg5_1 : Tensor "bf16[1, 2, 2048][4096, 2048, 1]cuda:0" = PlaceHolder[target=arg5_1]
#   %buf1 : Tensor "f32[1, 2, 1][2, 1, 2]cuda:0" = PlaceHolder[target=buf1]
#   %arg6_1 : Tensor "bf16[2048][1]cuda:0" = PlaceHolder[target=arg6_1]
#   %convert_element_type_7 : Tensor "f32[1, 2, 2048][4096, 2048, 1]cuda:0"[num_users=2] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%arg5_1, torch.float32), kwargs = {})
#   %pow_2 : Tensor "f32[1, 2, 2048][4096, 2048, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.pow.Tensor_Scalar](args = (%convert_element_type_7, 2), kwargs = {})
#   %mean_1 : Tensor "f32[1, 2, 1][2, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mean.dim](args = (%pow_2, [-1], True), kwargs = {})
#   %add_3 : Tensor "f32[1, 2, 1][2, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%mean_1, 1e-06), kwargs = {})
#   %rsqrt_1 : Tensor "f32[1, 2, 1][2, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.rsqrt.default](args = (%add_3,), kwargs = {})
#   %mul_3 : Tensor "f32[1, 2, 2048][4096, 2048, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%convert_element_type_7, %rsqrt_1), kwargs = {})
#   %convert_element_type_8 : Tensor "f32[2048][1]cuda:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%arg6_1, torch.float32), kwargs = {})
#   %add_4 : Tensor "f32[2048][1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%convert_element_type_8, 1.0), kwargs = {})
#   %mul_4 : Tensor "f32[1, 2, 2048][4096, 2048, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%mul_3, %add_4), kwargs = {})
#   %convert_element_type_9 : Tensor "bf16[1, 2, 2048][4096, 2048, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%mul_4, torch.bfloat16), kwargs = {})
#   return %buf1,%convert_element_type_9
triton_per_fused__to_copy_add_mean_mul_pow_rsqrt_1 = async_compile.triton('triton_per_fused__to_copy_add_mean_mul_pow_rsqrt_1', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.persistent_reduction(
    size_hints={'x': 2, 'r0_': 2048},
    reduction_hint=ReductionHint.INNER,
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*bf16', 'in_ptr1': '*bf16', 'out_ptr1': '*bf16', 'xnumel': 'i32', 'r0_numel': 'i32', 'XBLOCK': 'constexpr'}, 'device': DeviceProperties(type='cuda', index=0, multi_processor_count=108, cc=80, major=8, regs_per_multiprocessor=65536, max_threads_per_multi_processor=2048, max_threads_per_block=1024, warp_size=32), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]], (4,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'autotune_hints': set(), 'kernel_name': 'triton_per_fused__to_copy_add_mean_mul_pow_rsqrt_1', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': None, 'atomic_add_found': False, 'num_load': 2, 'num_store': 1, 'num_reduction': 1, 'backend_hash': 'F7205DDDCE8E401A1728E5D602D369DE155D3FCCD3ACF038A9886E6E0DD93A54', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'max_autotune': True, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': False, 'are_deterministic_algorithms_enabled': False, 'coordinate_descent_tuning': True, 'coordinate_descent_search_radius': 1, 'coordinate_descent_check_all_directions': False, 'tiling_scores': {'x': 0, 'r0_': 28672}}
)
@triton.jit
def triton_per_fused__to_copy_add_mean_mul_pow_rsqrt_1(in_ptr0, in_ptr1, out_ptr1, xnumel, r0_numel, XBLOCK : tl.constexpr):
    xnumel = 2
    r0_numel = 2048
    R0_BLOCK: tl.constexpr = 2048
    rnumel = r0_numel
    RBLOCK: tl.constexpr = R0_BLOCK
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:, None]
    xmask = xindex < xnumel
    r0_index = tl.arange(0, R0_BLOCK)[None, :]
    r0_offset = 0
    r0_mask = tl.full([R0_BLOCK], True, tl.int1)[None, :]
    roffset = r0_offset
    rindex = r0_index
    r0_1 = r0_index
    x0 = xindex
    tmp0 = tl.load(in_ptr0 + (r0_1 + 2048*x0), xmask, other=0.0).to(tl.float32)
    tmp13 = tl.load(in_ptr1 + (r0_1), None, eviction_policy='evict_last').to(tl.float32)
    tmp1 = tmp0.to(tl.float32)
    tmp2 = tmp1 * tmp1
    tmp3 = tl.broadcast_to(tmp2, [XBLOCK, R0_BLOCK])
    tmp5 = tl.where(xmask, tmp3, 0)
    tmp6 = tl.sum(tmp5, 1)[:, None].to(tl.float32)
    tmp7 = tl.full([1, 1], 2048.0, tl.float32)
    tmp8 = (tmp6 / tmp7)
    tmp9 = tl.full([1, 1], 1e-06, tl.float32)
    tmp10 = tmp8 + tmp9
    tmp11 = libdevice.rsqrt(tmp10)
    tmp12 = tmp1 * tmp11
    tmp14 = tmp13.to(tl.float32)
    tmp15 = tl.full([1, 1], 1.0, tl.float32)
    tmp16 = tmp14 + tmp15
    tmp17 = tmp12 * tmp16
    tmp18 = tmp17.to(tl.float32)
    tl.store(out_ptr1 + (r0_1 + 4096*x0), tmp18, xmask)
''', device_str='cuda')


# Original path: /content/q35moe-round-profile-20261109/infer-opt/infer_opt/quant_kernels.py:176
_w8a16_group_gemv_rows_kernel_0 = async_compile.triton('_w8a16_group_gemv_rows_kernel', '''

import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties

@triton_heuristics.user_autotune(
    configs=[{'num_warps': 8, 'num_stages': 3}],
    inductor_meta={'grid_type': 'FixedGrid', 'fixed_grid': ['_grid_0', '_grid_1', '_grid_2'], 'extra_launcher_args': ['_grid_0', '_grid_1', '_grid_2'], 'kernel_name': '_w8a16_group_gemv_rows_kernel_0', 'backend_hash': 'F7205DDDCE8E401A1728E5D602D369DE155D3FCCD3ACF038A9886E6E0DD93A54', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'max_autotune': True, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': False, 'are_deterministic_algorithms_enabled': False, 'coordinate_descent_tuning': True, 'coordinate_descent_search_radius': 1, 'coordinate_descent_check_all_directions': False},
    triton_meta={'signature': {'x_ptr': '*bf16', 'q_ptr': '*i8', 's_ptr': '*bf16', 'y_ptr': '*fp32', 'M': 'i32', 'N': 'i32', 'K': 'i32', 'GROUP': 'constexpr', 'BLOCK_M': 'constexpr', 'BLOCK_N': 'constexpr', 'SPLIT': 'constexpr'}, 'device': DeviceProperties(type='cuda', index=0, multi_processor_count=108, cc=80, major=8, regs_per_multiprocessor=65536, max_threads_per_multi_processor=2048, max_threads_per_block=1024, warp_size=32), 'constants': {'GROUP': 128, 'BLOCK_M': 16, 'BLOCK_N': 64, 'SPLIT': 4}, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]], (3,): [['tt.divisibility', 16]], (5,): [['tt.divisibility', 16]], (6,): [['tt.divisibility', 16]]}]},
    filename=__file__,
    custom_kernel=True,
)
@triton.jit
def _w8a16_group_gemv_rows_kernel(x_ptr, q_ptr, s_ptr, y_ptr, M, N, K, GROUP: tl.constexpr, BLOCK_M: tl.constexpr,
                                  BLOCK_N: tl.constexpr, SPLIT: tl.constexpr):
    # one group of columns per step: [BLOCK_M, GROUP] x [GROUP, BLOCK_N] on the tensor cores, then the group's scale.
    # With SPLIT > 1 program (pid, s) takes the s-th of SPLIT equal runs of groups and writes fp32 partials [SPLIT, M, N].
    pid = tl.program_id(0)
    split = tl.program_id(1)
    rows = pid * BLOCK_N + tl.arange(0, BLOCK_N)
    row_ok = rows < N
    m = tl.arange(0, BLOCK_M)
    m_ok = m < M
    cols = tl.arange(0, GROUP)
    groups = K // GROUP
    x_ptrs = x_ptr + m[:, None] * K + cols[None, :]
    q_ptrs = q_ptr + rows[:, None].to(tl.int64) * K + cols[None, :]
    s_ptrs = s_ptr + rows * groups
    acc = tl.zeros((BLOCK_M, BLOCK_N), dtype=tl.float32)
    per_split = groups // SPLIT
    for g in range(split * per_split, (split + 1) * per_split):
        x = tl.load(x_ptrs + g * GROUP, mask=m_ok[:, None], other=0.0)
        q = tl.load(q_ptrs + g * GROUP, mask=row_ok[:, None], other=0, eviction_policy="evict_first")
        s = tl.load(s_ptrs + g, mask=row_ok, other=0.0).to(tl.float32)
        acc += tl.dot(x, tl.trans(q.to(x.dtype))) * s[None, :]  # int8 values are exact in fp16/bf16
    y_ptrs = y_ptr + split * M * N + m[:, None] * N + rows[None, :]
    tl.store(y_ptrs, acc.to(y_ptr.dtype.element_ty), mask=m_ok[:, None] & row_ok[None, :])
''', device_str='cuda')


# kernel path: /tmp/infer-opt-models/q35moe-round-profile-20261109/inductor/3r/c3rl7lnxfodgwn6nj4p345q4kq3lkzvil237i6lpvrf3six56rdf.py
# Topologically Sorted Source Nodes: [y, float_6, pow_3, mean_2, add_5, rsqrt_2, output_4, float_7, add_6, output_5, hidden_states, y_1], Original ATen: [aten.sum, aten._to_copy, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul]
# Source node to ATen node mapping:
#   add_5 => add_5
#   add_6 => add_6
#   float_6 => convert_element_type_11
#   float_7 => convert_element_type_12
#   hidden_states => convert_element_type_13
#   mean_2 => mean_2
#   output_4 => mul_5
#   output_5 => mul_6
#   pow_3 => pow_3
#   rsqrt_2 => rsqrt_2
#   y => convert_element_type_10, sum_1
#   y_1 => triton_kernel_wrapper_mutation_4
# Graph fragment:
#   %buf6 : Tensor  = PlaceHolder[target=buf6]
#   %buf7 : Tensor "f32[1, 2, 1][2, 1, 2]cuda:0" = PlaceHolder[target=buf7]
#   %arg9_1 : Tensor "bf16[2048][1]cuda:0" = PlaceHolder[target=arg9_1]
#   %sum_1 : Tensor "f32[1, 2, 2048][4096, 2048, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.sum.dim_IntList](args = (%empty, [0]), kwargs = {})
#   %convert_element_type_10 : Tensor "bf16[1, 2, 2048][4096, 2048, 1]cuda:0"[num_users=2] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%sum_1, torch.bfloat16), kwargs = {})
#   %convert_element_type_11 : Tensor "f32[1, 2, 2048][4096, 2048, 1]cuda:0"[num_users=2] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%convert_element_type_10, torch.float32), kwargs = {})
#   %pow_3 : Tensor "f32[1, 2, 2048][4096, 2048, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.pow.Tensor_Scalar](args = (%convert_element_type_11, 2), kwargs = {})
#   %mean_2 : Tensor "f32[1, 2, 1][2, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mean.dim](args = (%pow_3, [-1], True), kwargs = {})
#   %add_5 : Tensor "f32[1, 2, 1][2, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%mean_2, 1e-06), kwargs = {})
#   %rsqrt_2 : Tensor "f32[1, 2, 1][2, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.rsqrt.default](args = (%add_5,), kwargs = {})
#   %mul_5 : Tensor "f32[1, 2, 2048][4096, 2048, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%convert_element_type_11, %rsqrt_2), kwargs = {})
#   %convert_element_type_12 : Tensor "f32[2048][1]cuda:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%arg9_1, torch.float32), kwargs = {})
#   %add_6 : Tensor "f32[2048][1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%convert_element_type_12, 1.0), kwargs = {})
#   %mul_6 : Tensor "f32[1, 2, 2048][4096, 2048, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%mul_5, %add_6), kwargs = {})
#   %convert_element_type_13 : Tensor "bf16[1, 2, 2048][4096, 2048, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%mul_6, torch.bfloat16), kwargs = {})
#   %triton_kernel_wrapper_mutation_4 : [num_users=0] = call_function[target=torch.ops.higher_order.triton_kernel_wrapper_mutation](args = (), kwargs = {kernel_idx: 1068, constant_args_idx: 1185, grid: [(288, 1, 1)], tma_descriptor_metadata: {}, kwargs: {x_ptr: %convert_element_type_13, q_ptr: %arg10_1, s_ptr: %arg11_1, y_ptr: %empty_1, M: 2, N: 9216, K: 2048, GROUP: 128, BLOCK_M: 16, BLOCK_N: 32, SPLIT: 1}})
#   return %buf7,%buf9
triton_per_fused__to_copy_add_mean_mul_pow_rsqrt_sum_2 = async_compile.triton('triton_per_fused__to_copy_add_mean_mul_pow_rsqrt_sum_2', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.persistent_reduction(
    size_hints={'x': 2, 'r0_': 2048},
    reduction_hint=ReductionHint.INNER,
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*fp32', 'in_ptr1': '*bf16', 'out_ptr1': '*bf16', 'xnumel': 'i32', 'r0_numel': 'i32', 'XBLOCK': 'constexpr'}, 'device': DeviceProperties(type='cuda', index=0, multi_processor_count=108, cc=80, major=8, regs_per_multiprocessor=65536, max_threads_per_multi_processor=2048, max_threads_per_block=1024, warp_size=32), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]], (4,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'autotune_hints': set(), 'kernel_name': 'triton_per_fused__to_copy_add_mean_mul_pow_rsqrt_sum_2', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': None, 'atomic_add_found': False, 'num_load': 5, 'num_store': 1, 'num_reduction': 1, 'backend_hash': 'F7205DDDCE8E401A1728E5D602D369DE155D3FCCD3ACF038A9886E6E0DD93A54', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'max_autotune': True, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': False, 'are_deterministic_algorithms_enabled': False, 'coordinate_descent_tuning': True, 'coordinate_descent_search_radius': 1, 'coordinate_descent_check_all_directions': False, 'tiling_scores': {'x': 0, 'r0_': 20480}}
)
@triton.jit
def triton_per_fused__to_copy_add_mean_mul_pow_rsqrt_sum_2(in_ptr0, in_ptr1, out_ptr1, xnumel, r0_numel, XBLOCK : tl.constexpr):
    xnumel = 2
    r0_numel = 2048
    R0_BLOCK: tl.constexpr = 2048
    rnumel = r0_numel
    RBLOCK: tl.constexpr = R0_BLOCK
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:, None]
    xmask = xindex < xnumel
    r0_index = tl.arange(0, R0_BLOCK)[None, :]
    r0_offset = 0
    r0_mask = tl.full([R0_BLOCK], True, tl.int1)[None, :]
    roffset = r0_offset
    rindex = r0_index
    r0_1 = r0_index
    x0 = xindex
    tmp0 = tl.load(in_ptr0 + (r0_1 + 2048*x0), xmask, other=0.0)
    tmp1 = tl.load(in_ptr0 + (4096 + r0_1 + 2048*x0), xmask, other=0.0)
    tmp3 = tl.load(in_ptr0 + (8192 + r0_1 + 2048*x0), xmask, other=0.0)
    tmp5 = tl.load(in_ptr0 + (12288 + r0_1 + 2048*x0), xmask, other=0.0)
    tmp20 = tl.load(in_ptr1 + (r0_1), None, eviction_policy='evict_last').to(tl.float32)
    tmp2 = tmp0 + tmp1
    tmp4 = tmp2 + tmp3
    tmp6 = tmp4 + tmp5
    tmp7 = tmp6.to(tl.float32)
    tmp8 = tmp7.to(tl.float32)
    tmp9 = tmp8 * tmp8
    tmp10 = tl.broadcast_to(tmp9, [XBLOCK, R0_BLOCK])
    tmp12 = tl.where(xmask, tmp10, 0)
    tmp13 = tl.sum(tmp12, 1)[:, None].to(tl.float32)
    tmp14 = tl.full([1, 1], 2048.0, tl.float32)
    tmp15 = (tmp13 / tmp14)
    tmp16 = tl.full([1, 1], 1e-06, tl.float32)
    tmp17 = tmp15 + tmp16
    tmp18 = libdevice.rsqrt(tmp17)
    tmp19 = tmp8 * tmp18
    tmp21 = tmp20.to(tl.float32)
    tmp22 = tl.full([1, 1], 1.0, tl.float32)
    tmp23 = tmp21 + tmp22
    tmp24 = tmp19 * tmp23
    tmp25 = tmp24.to(tl.float32)
    tl.store(out_ptr1 + (r0_1 + 2048*x0), tmp25, xmask)
''', device_str='cuda')


# Original path: /content/q35moe-round-profile-20261109/infer-opt/infer_opt/quant_kernels.py:176
_w8a16_group_gemv_rows_kernel_1 = async_compile.triton('_w8a16_group_gemv_rows_kernel', '''

import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties

@triton_heuristics.user_autotune(
    configs=[{'num_warps': 4, 'num_stages': 4}],
    inductor_meta={'grid_type': 'FixedGrid', 'fixed_grid': ['_grid_0', '_grid_1', '_grid_2'], 'extra_launcher_args': ['_grid_0', '_grid_1', '_grid_2'], 'kernel_name': '_w8a16_group_gemv_rows_kernel_1', 'backend_hash': 'F7205DDDCE8E401A1728E5D602D369DE155D3FCCD3ACF038A9886E6E0DD93A54', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'max_autotune': True, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': False, 'are_deterministic_algorithms_enabled': False, 'coordinate_descent_tuning': True, 'coordinate_descent_search_radius': 1, 'coordinate_descent_check_all_directions': False},
    triton_meta={'signature': {'x_ptr': '*bf16', 'q_ptr': '*i8', 's_ptr': '*bf16', 'y_ptr': '*bf16', 'M': 'i32', 'N': 'i32', 'K': 'i32', 'GROUP': 'constexpr', 'BLOCK_M': 'constexpr', 'BLOCK_N': 'constexpr', 'SPLIT': 'constexpr'}, 'device': DeviceProperties(type='cuda', index=0, multi_processor_count=108, cc=80, major=8, regs_per_multiprocessor=65536, max_threads_per_multi_processor=2048, max_threads_per_block=1024, warp_size=32), 'constants': {'GROUP': 128, 'BLOCK_M': 16, 'BLOCK_N': 32, 'SPLIT': 1}, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]], (3,): [['tt.divisibility', 16]], (5,): [['tt.divisibility', 16]], (6,): [['tt.divisibility', 16]]}]},
    filename=__file__,
    custom_kernel=True,
)
@triton.jit
def _w8a16_group_gemv_rows_kernel(x_ptr, q_ptr, s_ptr, y_ptr, M, N, K, GROUP: tl.constexpr, BLOCK_M: tl.constexpr,
                                  BLOCK_N: tl.constexpr, SPLIT: tl.constexpr):
    # one group of columns per step: [BLOCK_M, GROUP] x [GROUP, BLOCK_N] on the tensor cores, then the group's scale.
    # With SPLIT > 1 program (pid, s) takes the s-th of SPLIT equal runs of groups and writes fp32 partials [SPLIT, M, N].
    pid = tl.program_id(0)
    split = tl.program_id(1)
    rows = pid * BLOCK_N + tl.arange(0, BLOCK_N)
    row_ok = rows < N
    m = tl.arange(0, BLOCK_M)
    m_ok = m < M
    cols = tl.arange(0, GROUP)
    groups = K // GROUP
    x_ptrs = x_ptr + m[:, None] * K + cols[None, :]
    q_ptrs = q_ptr + rows[:, None].to(tl.int64) * K + cols[None, :]
    s_ptrs = s_ptr + rows * groups
    acc = tl.zeros((BLOCK_M, BLOCK_N), dtype=tl.float32)
    per_split = groups // SPLIT
    for g in range(split * per_split, (split + 1) * per_split):
        x = tl.load(x_ptrs + g * GROUP, mask=m_ok[:, None], other=0.0)
        q = tl.load(q_ptrs + g * GROUP, mask=row_ok[:, None], other=0, eviction_policy="evict_first")
        s = tl.load(s_ptrs + g, mask=row_ok, other=0.0).to(tl.float32)
        acc += tl.dot(x, tl.trans(q.to(x.dtype))) * s[None, :]  # int8 values are exact in fp16/bf16
    y_ptrs = y_ptr + split * M * N + m[:, None] * N + rows[None, :]
    tl.store(y_ptrs, acc.to(y_ptr.dtype.element_ty), mask=m_ok[:, None] & row_ok[None, :])
''', device_str='cuda')


# kernel path: /tmp/infer-opt-models/q35moe-round-profile-20261109/inductor/t5/ct53xwqzy6bjvdv6qvdbrok74ah7denjapqzd5jq4qtrnpbn74uw.py
# Topologically Sorted Source Nodes: [float_8, pow_4, mean_3], Original ATen: [aten.split_with_sizes, aten.view, aten.split, aten._to_copy, aten.pow, aten.mean]
# Source node to ATen node mapping:
#   float_8 => convert_element_type_14, split_3, split_with_sizes_5, view_9
#   mean_3 => mean_3
#   pow_4 => pow_4
# Graph fragment:
#   %buf10 : Tensor  = PlaceHolder[target=buf10]
#   %split_with_sizes_5 : [num_users=1] = call_function[target=torch.ops.aten.split_with_sizes.default](args = (%empty_1, [8192, 512, 512], -1), kwargs = {})
#   %view_9 : Tensor "bf16[1, 2, 16, 512][18432, 9216, 512, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%getitem_23, [1, 2, -1, 512]), kwargs = {})
#   %split_3 : [num_users=1] = call_function[target=torch.ops.aten.split.Tensor](args = (%view_9, 256, -1), kwargs = {})
#   %convert_element_type_14 : Tensor "f32[1, 2, 16, 256][8192, 4096, 256, 1]cuda:0"[num_users=2] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%getitem_26, torch.float32), kwargs = {})
#   %pow_4 : Tensor "f32[1, 2, 16, 256][8192, 4096, 256, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.pow.Tensor_Scalar](args = (%convert_element_type_14, 2), kwargs = {})
#   %mean_3 : Tensor "f32[1, 2, 16, 1][32, 16, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mean.dim](args = (%pow_4, [-1], True), kwargs = {})
#   return %buf11
triton_per_fused__to_copy_mean_pow_split_split_with_sizes_view_3 = async_compile.triton('triton_per_fused__to_copy_mean_pow_split_split_with_sizes_view_3', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.persistent_reduction(
    size_hints={'x': 32, 'r0_': 256},
    reduction_hint=ReductionHint.INNER,
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*bf16', 'out_ptr0': '*fp32', 'xnumel': 'i32', 'r0_numel': 'i32', 'XBLOCK': 'constexpr'}, 'device': DeviceProperties(type='cuda', index=0, multi_processor_count=108, cc=80, major=8, regs_per_multiprocessor=65536, max_threads_per_multi_processor=2048, max_threads_per_block=1024, warp_size=32), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]], (3,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'autotune_hints': set(), 'kernel_name': 'triton_per_fused__to_copy_mean_pow_split_split_with_sizes_view_3', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': None, 'atomic_add_found': False, 'num_load': 1, 'num_store': 1, 'num_reduction': 1, 'backend_hash': 'F7205DDDCE8E401A1728E5D602D369DE155D3FCCD3ACF038A9886E6E0DD93A54', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'max_autotune': True, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': False, 'are_deterministic_algorithms_enabled': False, 'coordinate_descent_tuning': True, 'coordinate_descent_search_radius': 1, 'coordinate_descent_check_all_directions': False, 'tiling_scores': {'x': 256, 'r0_': 0}}
)
@triton.jit
def triton_per_fused__to_copy_mean_pow_split_split_with_sizes_view_3(in_ptr0, out_ptr0, xnumel, r0_numel, XBLOCK : tl.constexpr):
    xnumel = 32
    r0_numel = 256
    R0_BLOCK: tl.constexpr = 256
    rnumel = r0_numel
    RBLOCK: tl.constexpr = R0_BLOCK
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:, None]
    xmask = xindex < xnumel
    r0_index = tl.arange(0, R0_BLOCK)[None, :]
    r0_offset = 0
    r0_mask = tl.full([R0_BLOCK], True, tl.int1)[None, :]
    roffset = r0_offset
    rindex = r0_index
    r0_2 = r0_index
    x0 = (xindex % 16)
    x1 = xindex // 16
    x3 = xindex
    tmp0 = tl.load(in_ptr0 + (r0_2 + 512*x0 + 9216*x1), xmask, other=0.0).to(tl.float32)
    tmp1 = tmp0.to(tl.float32)
    tmp2 = tmp1 * tmp1
    tmp3 = tl.broadcast_to(tmp2, [XBLOCK, R0_BLOCK])
    tmp5 = tl.where(xmask, tmp3, 0)
    tmp6 = tl.sum(tmp5, 1)[:, None].to(tl.float32)
    tl.store(out_ptr0 + (x3), tmp6, xmask)
''', device_str='cuda')


# kernel path: /tmp/infer-opt-models/q35moe-round-profile-20261109/inductor/ro/cropvx3vmdh7v7xqd5g3klxianrmxaqxin3gkp6tgy46idqiprlt.py
# Topologically Sorted Source Nodes: [arange, positions, view, expand, position_ids, getitem, float_1, to, freqs, cos, getitem_2, sin, getitem_5, setitem_1, setitem_3], Original ATen: [aten.arange, aten.add, aten.view, aten.expand, aten.unsqueeze, aten._to_copy, aten.mul, aten.cos, aten.select, aten.slice, aten.sin]
# Source node to ATen node mapping:
#   arange => iota
#   cos => cos
#   expand => expand
#   float_1 => convert_element_type
#   freqs => mul
#   getitem => unsqueeze
#   getitem_2 => select_1, slice_1
#   getitem_5 => select_13, slice_9
#   position_ids => expand_1
#   positions => add
#   setitem_1 => select_8, slice_7
#   setitem_3 => select_20, slice_15
#   sin => sin
#   to => convert_element_type_1
#   view => view
# Graph fragment:
#   %copy_ : Tensor "i64[1][1]cuda:0" = PlaceHolder[target=copy_]
#   %arg3_1 : Tensor "bf16[32][1]cuda:0" = PlaceHolder[target=arg3_1]
#   %iota : Tensor "i64[2][1]cuda:0"[num_users=1] = call_function[target=torch.ops.prims.iota.default](args = (2,), kwargs = {start: 0, step: 1, dtype: torch.int64, device: cuda:0, requires_grad: False})
#   %add : Tensor "i64[2][1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%iota, %arg2_1), kwargs = {})
#   %view : Tensor "i64[1, 1, 2][2, 2, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%add, [1, 1, 2]), kwargs = {})
#   %expand : Tensor "i64[3, 1, 2][0, 2, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.expand.default](args = (%view, [3, 1, 2]), kwargs = {})
#   %expand_1 : Tensor "i64[3, 1, 2][0, 2, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.expand.default](args = (%expand, [3, -1, -1]), kwargs = {})
#   %unsqueeze : Tensor "i64[3, 1, 2, 1][0, 2, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%expand_1, 3), kwargs = {})
#   %convert_element_type : Tensor "f32[3, 1, 2, 1][2, 2, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%unsqueeze, torch.float32), kwargs = {})
#   %convert_element_type_1 : Tensor "f32[32][1]cuda:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%arg3_1, torch.float32), kwargs = {})
#   %mul : Tensor "f32[3, 1, 2, 32][64, 64, 32, 1]cuda:0"[num_users=2] = call_function[target=torch.ops.aten.mul.Tensor](args = (%convert_element_type, %convert_element_type_1), kwargs = {})
#   %cos : Tensor "f32[3, 1, 2, 32][64, 64, 32, 1]cuda:0"[num_users=5] = call_function[target=torch.ops.aten.cos.default](args = (%mul,), kwargs = {})
#   %select_1 : Tensor "f32[1, 2, 32][64, 32, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.select.int](args = (%cos, 0, 1), kwargs = {})
#   %slice_1 : Tensor "f32[1, 2, 11][64, 32, 3]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.slice.Tensor](args = (%select_1, 2, 1, 33, 3), kwargs = {})
#   %select_int : Tensor "f32[1, 2, 32][64, 32, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.select.int](args = (%cos, 0, 0), kwargs = {})
#   %slice_scatter_default : Tensor "f32[1, 2, 32][64, 32, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.slice_scatter.default](args = (%select_int, %slice_1, 2, 1, 33, 3), kwargs = {})
#   %select_scatter_default : Tensor "f32[3, 1, 2, 32][64, 64, 32, 1]cuda:0"[num_users=5] = call_function[target=torch.ops.aten.select_scatter.default](args = (%cos, %slice_scatter_default, 0, 0), kwargs = {})
#   %sin : Tensor "f32[3, 1, 2, 32][64, 64, 32, 1]cuda:0"[num_users=5] = call_function[target=torch.ops.aten.sin.default](args = (%mul,), kwargs = {})
#   %select_13 : Tensor "f32[1, 2, 32][64, 32, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.select.int](args = (%sin, 0, 1), kwargs = {})
#   %slice_9 : Tensor "f32[1, 2, 11][64, 32, 3]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.slice.Tensor](args = (%select_13, 2, 1, 33, 3), kwargs = {})
#   %select_int_1 : Tensor "f32[1, 2, 32][64, 32, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.select.int](args = (%sin, 0, 0), kwargs = {})
#   %slice_scatter_default_1 : Tensor "f32[1, 2, 32][64, 32, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.slice_scatter.default](args = (%select_int_1, %slice_9, 2, 1, 33, 3), kwargs = {})
#   %select_scatter_default_1 : Tensor "f32[3, 1, 2, 32][64, 64, 32, 1]cuda:0"[num_users=5] = call_function[target=torch.ops.aten.select_scatter.default](args = (%sin, %slice_scatter_default_1, 0, 0), kwargs = {})
#   %select_8 : Tensor "f32[1, 2, 32][64, 32, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.select.int](args = (%select_scatter_default, 0, 2), kwargs = {})
#   %slice_7 : Tensor "f32[1, 2, 10][64, 32, 3]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.slice.Tensor](args = (%select_8, 2, 2, 30, 3), kwargs = {})
#   %select_int_2 : Tensor "f32[1, 2, 32][64, 32, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.select.int](args = (%select_scatter_default, 0, 0), kwargs = {})
#   %slice_scatter_default_2 : Tensor "f32[1, 2, 32][64, 32, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.slice_scatter.default](args = (%select_int_2, %slice_7, 2, 2, 30, 3), kwargs = {})
#   %select_20 : Tensor "f32[1, 2, 32][64, 32, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.select.int](args = (%select_scatter_default_1, 0, 2), kwargs = {})
#   %slice_15 : Tensor "f32[1, 2, 10][64, 32, 3]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.slice.Tensor](args = (%select_20, 2, 2, 30, 3), kwargs = {})
#   %select_int_3 : Tensor "f32[1, 2, 32][64, 32, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.select.int](args = (%select_scatter_default_1, 0, 0), kwargs = {})
#   %slice_scatter_default_3 : Tensor "f32[1, 2, 32][64, 32, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.slice_scatter.default](args = (%select_int_3, %slice_15, 2, 2, 30, 3), kwargs = {})
#   return %slice_scatter_default_2,%slice_scatter_default_3
triton_poi_fused__to_copy_add_arange_cos_expand_mul_select_sin_slice_unsqueeze_view_4 = async_compile.triton('triton_poi_fused__to_copy_add_arange_cos_expand_mul_select_sin_slice_unsqueeze_view_4', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.pointwise(
    size_hints={'x': 64}, 
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*i64', 'in_ptr1': '*bf16', 'out_ptr0': '*fp32', 'out_ptr1': '*fp32', 'xnumel': 'i32', 'XBLOCK': 'constexpr'}, 'device': DeviceProperties(type='cuda', index=0, multi_processor_count=108, cc=80, major=8, regs_per_multiprocessor=65536, max_threads_per_multi_processor=2048, max_threads_per_block=1024, warp_size=32), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]], (3,): [['tt.divisibility', 16]], (4,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'autotune_hints': set(), 'kernel_name': 'triton_poi_fused__to_copy_add_arange_cos_expand_mul_select_sin_slice_unsqueeze_view_4', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 8, 'num_store': 2, 'num_reduction': 0, 'backend_hash': 'F7205DDDCE8E401A1728E5D602D369DE155D3FCCD3ACF038A9886E6E0DD93A54', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'max_autotune': True, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': False, 'are_deterministic_algorithms_enabled': False, 'coordinate_descent_tuning': True, 'coordinate_descent_search_radius': 1, 'coordinate_descent_check_all_directions': False, 'tiling_scores': {'x': 1216}},
    min_elem_per_thread=0
)
@triton.jit
def triton_poi_fused__to_copy_add_arange_cos_expand_mul_select_sin_slice_unsqueeze_view_4(in_ptr0, in_ptr1, out_ptr0, out_ptr1, xnumel, XBLOCK : tl.constexpr):
    xnumel = 64
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:]
    xmask = xindex < xnumel
    x0 = (xindex % 32)
    x1 = xindex // 32
    x2 = xindex
    tmp65 = tl.load(in_ptr0 + (0))
    tmp66 = tl.broadcast_to(tmp65, [XBLOCK])
    tmp70 = tl.load(in_ptr1 + (x0), xmask, eviction_policy='evict_last').to(tl.float32)
    tmp0 = x0
    tmp1 = tl.full([1], 2, tl.int64)
    tmp2 = tmp0 >= tmp1
    tmp3 = tl.full([1], 30, tl.int64)
    tmp4 = tmp0 < tmp3
    tmp5 = (((-2) + x0) % 3)
    tmp6 = tl.full([1], 0, tl.int64)
    tmp7 = tmp5 == tmp6
    tmp8 = tmp2 & tmp4
    tmp9 = tmp8 & tmp7
    tmp10 = tl.full([1], 2, tl.int32)
    tmp11 = tl.full([1], 0, tl.int32)
    tmp12 = tmp10 == tmp11
    tmp13 = 2 + 3*(triton_helpers.div_floor_integer((-2) + x0,  3))
    tmp14 = tl.full([1], 1, tl.int64)
    tmp15 = tmp13 >= tmp14
    tmp16 = tl.full([1], 0, tl.int64)
    tmp17 = tmp14 == tmp16
    tmp18 = tmp15 & tmp17
    tmp19 = tmp18 & tmp9
    tmp20 = tl.load(in_ptr0 + (0))
    tmp21 = tl.broadcast_to(tmp20, [XBLOCK])
    tmp22 = tl.where(tmp19, tmp21, 0)
    tmp23 = x1
    tmp24 = tmp23 + tmp22
    tmp25 = tmp24.to(tl.float32)
    tmp26 = tl.load(in_ptr1 + (1 + 3*(triton_helpers.div_floor_integer((-2) + x0,  3))), tmp19 & xmask, eviction_policy='evict_last', other=0.0).to(tl.float32)
    tmp27 = tmp26.to(tl.float32)
    tmp28 = tmp25 * tmp27
    tmp29 = tl_math.cos(tmp28)
    tmp30 = tl.full(tmp29.shape, 0.0, tmp29.dtype)
    tmp31 = tl.where(tmp19, tmp29, tmp30)
    tmp32 = tl.load(in_ptr0 + (0))
    tmp33 = tl.broadcast_to(tmp32, [XBLOCK])
    tmp34 = tl.where(tmp9, tmp33, 0)
    tmp35 = x1
    tmp36 = tmp35 + tmp34
    tmp37 = tmp36.to(tl.float32)
    tmp38 = tl.load(in_ptr1 + (2 + 3*(triton_helpers.div_floor_integer((-2) + x0,  3))), tmp9 & xmask, eviction_policy='evict_last', other=0.0).to(tl.float32)
    tmp39 = tmp38.to(tl.float32)
    tmp40 = tmp37 * tmp39
    tmp41 = tl_math.cos(tmp40)
    tmp42 = tl.where(tmp18, tmp31, tmp41)
    tmp43 = tl.where(tmp12, tmp42, tmp41)
    tmp44 = tl.full(tmp43.shape, 0.0, tmp43.dtype)
    tmp45 = tl.where(tmp9, tmp43, tmp44)
    tmp46 = tl.full([1], 0, tl.int32)
    tmp47 = tmp46 == tmp46
    tmp48 = tl.full([1], 1, tl.int64)
    tmp49 = tmp0 >= tmp48
    tmp50 = (((-1) + x0) % 3)
    tmp51 = tmp50 == tmp6
    tmp52 = tmp49 & tmp51
    tmp53 = tl.load(in_ptr0 + (0))
    tmp54 = tl.broadcast_to(tmp53, [XBLOCK])
    tmp55 = tl.where(tmp52, tmp54, 0)
    tmp56 = x1
    tmp57 = tmp56 + tmp55
    tmp58 = tmp57.to(tl.float32)
    tmp59 = tl.load(in_ptr1 + (1 + 3*(triton_helpers.div_floor_integer((-1) + x0,  3))), tmp52 & xmask, eviction_policy='evict_last', other=0.0).to(tl.float32)
    tmp60 = tmp59.to(tl.float32)
    tmp61 = tmp58 * tmp60
    tmp62 = tl_math.cos(tmp61)
    tmp63 = tl.full(tmp62.shape, 0.0, tmp62.dtype)
    tmp64 = tl.where(tmp52, tmp62, tmp63)
    tmp67 = x1
    tmp68 = tmp67 + tmp66
    tmp69 = tmp68.to(tl.float32)
    tmp71 = tmp70.to(tl.float32)
    tmp72 = tmp69 * tmp71
    tmp73 = tl_math.cos(tmp72)
    tmp74 = tl.where(tmp52, tmp64, tmp73)
    tmp75 = tl.where(tmp47, tmp74, tmp73)
    tmp76 = tl.where(tmp9, tmp45, tmp75)
    tmp77 = tl_math.sin(tmp28)
    tmp78 = tl.full(tmp77.shape, 0.0, tmp77.dtype)
    tmp79 = tl.where(tmp19, tmp77, tmp78)
    tmp80 = tl_math.sin(tmp40)
    tmp81 = tl.where(tmp18, tmp79, tmp80)
    tmp82 = tl.where(tmp12, tmp81, tmp80)
    tmp83 = tl.full(tmp82.shape, 0.0, tmp82.dtype)
    tmp84 = tl.where(tmp9, tmp82, tmp83)
    tmp85 = tl_math.sin(tmp61)
    tmp86 = tl.full(tmp85.shape, 0.0, tmp85.dtype)
    tmp87 = tl.where(tmp52, tmp85, tmp86)
    tmp88 = tl_math.sin(tmp72)
    tmp89 = tl.where(tmp52, tmp87, tmp88)
    tmp90 = tl.where(tmp47, tmp89, tmp88)
    tmp91 = tl.where(tmp9, tmp84, tmp90)
    tl.store(out_ptr0 + (x2), tmp76, xmask)
    tl.store(out_ptr1 + (x2), tmp91, xmask)
''', device_str='cuda')


# kernel path: /tmp/infer-opt-models/q35moe-round-profile-20261109/inductor/wr/cwrcc6ma6ythcutjzqrbzegwmtaswn4u7t3etbgglcna5daqh3vw.py
# Topologically Sorted Source Nodes: [arange, positions, view, expand, position_ids, getitem, float_1, to, freqs, cos, getitem_2, sin, getitem_5, float_8, pow_4, mean_3, add_7, rsqrt_3, output_6, float_9, add_8, output_7, type_as_3, query_states_1, q_rot, cos_1, cos_2, cos_3, mul_11, x2, neg, x1, cat_3, sin_1, sin_2, sin_3, mul_12, q_embed], Original ATen: [aten.arange, aten.add, aten.view, aten.expand, aten.unsqueeze, aten._to_copy, aten.mul, aten.cos, aten.select, aten.slice, aten.sin, aten.split_with_sizes, aten.split, aten.pow, aten.mean, aten.rsqrt, aten.transpose, aten.cat, aten.neg]
# Source node to ATen node mapping:
#   add_7 => add_7
#   add_8 => add_8
#   arange => iota
#   cat_3 => cat_1
#   cos => cos
#   cos_1 => clone, expand_2, select_11, unsqueeze_1, view_1
#   cos_2 => convert_element_type_2
#   cos_3 => unsqueeze_3
#   expand => expand
#   float_1 => convert_element_type
#   float_8 => convert_element_type_14, split_3, split_with_sizes_5, view_9
#   float_9 => convert_element_type_15
#   freqs => mul
#   getitem => unsqueeze
#   getitem_2 => select_1, slice_1
#   getitem_5 => select_13, slice_9
#   mean_3 => mean_3
#   mul_11 => mul_11
#   mul_12 => mul_12
#   neg => neg
#   output_6 => mul_7
#   output_7 => mul_8
#   position_ids => expand_1
#   positions => add
#   pow_4 => pow_4
#   q_embed => add_11
#   q_rot => slice_17
#   query_states_1 => permute
#   rsqrt_3 => rsqrt_3
#   sin => sin
#   sin_1 => clone_2, expand_3, select_23, unsqueeze_2, view_2
#   sin_2 => convert_element_type_3
#   sin_3 => unsqueeze_4
#   to => convert_element_type_1
#   type_as_3 => convert_element_type_16
#   view => view
#   x1 => slice_21
#   x2 => slice_22
# Graph fragment:
#   %buf10 : Tensor  = PlaceHolder[target=buf10]
#   %buf11 : Tensor "f32[1, 2, 16, 1][32, 16, 1, 32]cuda:0" = PlaceHolder[target=buf11]
#   %arg12_1 : Tensor "bf16[256][1]cuda:0" = PlaceHolder[target=arg12_1]
#   %slice_scatter_default_2 : Tensor "f32[1, 2, 32][64, 32, 1]cuda:0" = PlaceHolder[target=slice_scatter_default_2]
#   %copy_ : Tensor "i64[1][1]cuda:0" = PlaceHolder[target=copy_]
#   %arg3_1 : Tensor "bf16[32][1]cuda:0" = PlaceHolder[target=arg3_1]
#   %mul_11 : Tensor "bf16[1, 16, 2, 64][2048, 64, 1024, 1]cuda:0" = PlaceHolder[target=mul_11]
#   %cat_1 : Tensor "bf16[1, 16, 2, 64][2048, 64, 1024, 1]cuda:0" = PlaceHolder[target=cat_1]
#   %slice_scatter_default_3 : Tensor "f32[1, 2, 32][64, 32, 1]cuda:0" = PlaceHolder[target=slice_scatter_default_3]
#   %iota : Tensor "i64[2][1]cuda:0"[num_users=1] = call_function[target=torch.ops.prims.iota.default](args = (2,), kwargs = {start: 0, step: 1, dtype: torch.int64, device: cuda:0, requires_grad: False})
#   %add : Tensor "i64[2][1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%iota, %arg2_1), kwargs = {})
#   %view : Tensor "i64[1, 1, 2][2, 2, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%add, [1, 1, 2]), kwargs = {})
#   %expand : Tensor "i64[3, 1, 2][0, 2, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.expand.default](args = (%view, [3, 1, 2]), kwargs = {})
#   %expand_1 : Tensor "i64[3, 1, 2][0, 2, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.expand.default](args = (%expand, [3, -1, -1]), kwargs = {})
#   %unsqueeze : Tensor "i64[3, 1, 2, 1][0, 2, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%expand_1, 3), kwargs = {})
#   %convert_element_type : Tensor "f32[3, 1, 2, 1][2, 2, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%unsqueeze, torch.float32), kwargs = {})
#   %convert_element_type_1 : Tensor "f32[32][1]cuda:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%arg3_1, torch.float32), kwargs = {})
#   %mul : Tensor "f32[3, 1, 2, 32][64, 64, 32, 1]cuda:0"[num_users=2] = call_function[target=torch.ops.aten.mul.Tensor](args = (%convert_element_type, %convert_element_type_1), kwargs = {})
#   %cos : Tensor "f32[3, 1, 2, 32][64, 64, 32, 1]cuda:0"[num_users=5] = call_function[target=torch.ops.aten.cos.default](args = (%mul,), kwargs = {})
#   %select_1 : Tensor "f32[1, 2, 32][64, 32, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.select.int](args = (%cos, 0, 1), kwargs = {})
#   %slice_1 : Tensor "f32[1, 2, 11][64, 32, 3]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.slice.Tensor](args = (%select_1, 2, 1, 33, 3), kwargs = {})
#   %select_int : Tensor "f32[1, 2, 32][64, 32, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.select.int](args = (%cos, 0, 0), kwargs = {})
#   %slice_scatter_default : Tensor "f32[1, 2, 32][64, 32, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.slice_scatter.default](args = (%select_int, %slice_1, 2, 1, 33, 3), kwargs = {})
#   %select_scatter_default : Tensor "f32[3, 1, 2, 32][64, 64, 32, 1]cuda:0"[num_users=5] = call_function[target=torch.ops.aten.select_scatter.default](args = (%cos, %slice_scatter_default, 0, 0), kwargs = {})
#   %sin : Tensor "f32[3, 1, 2, 32][64, 64, 32, 1]cuda:0"[num_users=5] = call_function[target=torch.ops.aten.sin.default](args = (%mul,), kwargs = {})
#   %select_13 : Tensor "f32[1, 2, 32][64, 32, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.select.int](args = (%sin, 0, 1), kwargs = {})
#   %slice_9 : Tensor "f32[1, 2, 11][64, 32, 3]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.slice.Tensor](args = (%select_13, 2, 1, 33, 3), kwargs = {})
#   %select_int_1 : Tensor "f32[1, 2, 32][64, 32, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.select.int](args = (%sin, 0, 0), kwargs = {})
#   %slice_scatter_default_1 : Tensor "f32[1, 2, 32][64, 32, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.slice_scatter.default](args = (%select_int_1, %slice_9, 2, 1, 33, 3), kwargs = {})
#   %select_scatter_default_1 : Tensor "f32[3, 1, 2, 32][64, 64, 32, 1]cuda:0"[num_users=5] = call_function[target=torch.ops.aten.select_scatter.default](args = (%sin, %slice_scatter_default_1, 0, 0), kwargs = {})
#   %split_with_sizes_5 : [num_users=1] = call_function[target=torch.ops.aten.split_with_sizes.default](args = (%empty_1, [8192, 512, 512], -1), kwargs = {})
#   %view_9 : Tensor "bf16[1, 2, 16, 512][18432, 9216, 512, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%getitem_23, [1, 2, -1, 512]), kwargs = {})
#   %split_3 : [num_users=1] = call_function[target=torch.ops.aten.split.Tensor](args = (%view_9, 256, -1), kwargs = {})
#   %convert_element_type_14 : Tensor "f32[1, 2, 16, 256][8192, 4096, 256, 1]cuda:0"[num_users=2] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%getitem_26, torch.float32), kwargs = {})
#   %pow_4 : Tensor "f32[1, 2, 16, 256][8192, 4096, 256, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.pow.Tensor_Scalar](args = (%convert_element_type_14, 2), kwargs = {})
#   %mean_3 : Tensor "f32[1, 2, 16, 1][32, 16, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mean.dim](args = (%pow_4, [-1], True), kwargs = {})
#   %add_7 : Tensor "f32[1, 2, 16, 1][32, 16, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%mean_3, 1e-06), kwargs = {})
#   %rsqrt_3 : Tensor "f32[1, 2, 16, 1][32, 16, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.rsqrt.default](args = (%add_7,), kwargs = {})
#   %mul_7 : Tensor "f32[1, 2, 16, 256][8192, 4096, 256, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%convert_element_type_14, %rsqrt_3), kwargs = {})
#   %convert_element_type_15 : Tensor "f32[256][1]cuda:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%arg12_1, torch.float32), kwargs = {})
#   %add_8 : Tensor "f32[256][1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%convert_element_type_15, 1.0), kwargs = {})
#   %mul_8 : Tensor "f32[1, 2, 16, 256][8192, 4096, 256, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%mul_7, %add_8), kwargs = {})
#   %convert_element_type_16 : Tensor "bf16[1, 2, 16, 256][8192, 4096, 256, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%mul_8, torch.bfloat16), kwargs = {})
#   %permute : Tensor "bf16[1, 16, 2, 256][8192, 256, 4096, 1]cuda:0"[num_users=2] = call_function[target=torch.ops.aten.permute.default](args = (%convert_element_type_16, [0, 2, 1, 3]), kwargs = {})
#   %slice_17 : Tensor "bf16[1, 16, 2, 64][8192, 256, 4096, 1]cuda:0"[num_users=3] = call_function[target=torch.ops.aten.slice.Tensor](args = (%permute, 3, 0, 64), kwargs = {})
#   %select_scatter_default_2 : Tensor "f32[3, 1, 2, 32][64, 64, 32, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.select_scatter.default](args = (%select_scatter_default, %slice_scatter_default_2, 0, 0), kwargs = {})
#   %select_11 : Tensor "f32[1, 2, 32][64, 32, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.select.int](args = (%select_scatter_default_2, 0, 0), kwargs = {})
#   %unsqueeze_1 : Tensor "f32[1, 2, 1, 32][64, 32, 32, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%select_11, 2), kwargs = {})
#   %expand_2 : Tensor "f32[1, 2, 2, 32][64, 32, 0, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.expand.default](args = (%unsqueeze_1, [1, 2, 2, 32]), kwargs = {})
#   %clone : Tensor "f32[1, 2, 2, 32][128, 64, 32, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.clone.default](args = (%expand_2,), kwargs = {memory_format: torch.contiguous_format})
#   %view_1 : Tensor "f32[1, 2, 64][128, 64, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%clone, [1, 2, 64]), kwargs = {})
#   %convert_element_type_2 : Tensor "bf16[1, 2, 64][128, 64, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%view_1, torch.bfloat16), kwargs = {})
#   %unsqueeze_3 : Tensor "bf16[1, 1, 2, 64][128, 128, 64, 1]cuda:0"[num_users=2] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%convert_element_type_2, 1), kwargs = {})
#   %mul_11 : Tensor "bf16[1, 16, 2, 64][2048, 64, 1024, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%slice_17, %unsqueeze_3), kwargs = {})
#   %slice_22 : Tensor "bf16[1, 16, 2, 32][8192, 256, 4096, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.slice.Tensor](args = (%slice_17, 3, 32, 9223372036854775807), kwargs = {})
#   %neg : Tensor "bf16[1, 16, 2, 32][1024, 32, 512, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.neg.default](args = (%slice_22,), kwargs = {})
#   %slice_21 : Tensor "bf16[1, 16, 2, 32][8192, 256, 4096, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.slice.Tensor](args = (%slice_17, 3, 0, 32), kwargs = {})
#   %cat_1 : Tensor "bf16[1, 16, 2, 64][2048, 128, 64, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.cat.default](args = ([%neg, %slice_21], -1), kwargs = {})
#   %select_scatter_default_3 : Tensor "f32[3, 1, 2, 32][64, 64, 32, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.select_scatter.default](args = (%select_scatter_default_1, %slice_scatter_default_3, 0, 0), kwargs = {})
#   %select_23 : Tensor "f32[1, 2, 32][64, 32, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.select.int](args = (%select_scatter_default_3, 0, 0), kwargs = {})
#   %unsqueeze_2 : Tensor "f32[1, 2, 1, 32][64, 32, 32, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%select_23, 2), kwargs = {})
#   %expand_3 : Tensor "f32[1, 2, 2, 32][64, 32, 0, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.expand.default](args = (%unsqueeze_2, [1, 2, 2, 32]), kwargs = {})
#   %clone_2 : Tensor "f32[1, 2, 2, 32][128, 64, 32, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.clone.default](args = (%expand_3,), kwargs = {memory_format: torch.contiguous_format})
#   %view_2 : Tensor "f32[1, 2, 64][128, 64, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%clone_2, [1, 2, 64]), kwargs = {})
#   %convert_element_type_3 : Tensor "bf16[1, 2, 64][128, 64, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%view_2, torch.bfloat16), kwargs = {})
#   %unsqueeze_4 : Tensor "bf16[1, 1, 2, 64][128, 128, 64, 1]cuda:0"[num_users=2] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%convert_element_type_3, 1), kwargs = {})
#   %mul_12 : Tensor "bf16[1, 16, 2, 64][2048, 128, 64, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%cat_1, %unsqueeze_4), kwargs = {})
#   %add_11 : Tensor "bf16[1, 16, 2, 64][2048, 64, 1024, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%mul_11, %mul_12), kwargs = {})
#   return %cat_1,%mul_11,%add_11
triton_poi_fused__to_copy_add_arange_cat_cos_expand_mean_mul_neg_pow_rsqrt_select_sin_slice_split_split_with_sizes_transpose_unsqueeze_view_5 = async_compile.triton('triton_poi_fused__to_copy_add_arange_cat_cos_expand_mean_mul_neg_pow_rsqrt_select_sin_slice_split_split_with_sizes_transpose_unsqueeze_view_5', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.pointwise(
    size_hints={'y': 32, 'x': 64}, tile_hint=TileHint.DEFAULT,
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*bf16', 'in_ptr1': '*fp32', 'in_ptr2': '*bf16', 'in_ptr3': '*fp32', 'in_ptr4': '*i64', 'in_ptr5': '*bf16', 'in_ptr6': '*fp32', 'out_ptr2': '*bf16', 'ynumel': 'i32', 'xnumel': 'i32', 'YBLOCK': 'constexpr', 'XBLOCK': 'constexpr'}, 'device': DeviceProperties(type='cuda', index=0, multi_processor_count=108, cc=80, major=8, regs_per_multiprocessor=65536, max_threads_per_multi_processor=2048, max_threads_per_block=1024, warp_size=32), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]], (3,): [['tt.divisibility', 16]], (4,): [['tt.divisibility', 16]], (5,): [['tt.divisibility', 16]], (6,): [['tt.divisibility', 16]], (7,): [['tt.divisibility', 16]], (8,): [['tt.divisibility', 16]], (9,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid2D', 'autotune_hints': set(), 'kernel_name': 'triton_poi_fused__to_copy_add_arange_cat_cos_expand_mean_mul_neg_pow_rsqrt_select_sin_slice_split_split_with_sizes_transpose_unsqueeze_view_5', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 15, 'num_store': 1, 'num_reduction': 0, 'backend_hash': 'F7205DDDCE8E401A1728E5D602D369DE155D3FCCD3ACF038A9886E6E0DD93A54', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'max_autotune': True, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': False, 'are_deterministic_algorithms_enabled': False, 'coordinate_descent_tuning': True, 'coordinate_descent_search_radius': 1, 'coordinate_descent_check_all_directions': False, 'tiling_scores': {'y': 128, 'x': 9152}},
    min_elem_per_thread=0
)
@triton.jit
def triton_poi_fused__to_copy_add_arange_cat_cos_expand_mean_mul_neg_pow_rsqrt_select_sin_slice_split_split_with_sizes_transpose_unsqueeze_view_5(in_ptr0, in_ptr1, in_ptr2, in_ptr3, in_ptr4, in_ptr5, in_ptr6, out_ptr2, ynumel, xnumel, YBLOCK : tl.constexpr, XBLOCK : tl.constexpr):
    ynumel = 32
    xnumel = 64
    yoffset = tl.program_id(1) * YBLOCK
    yindex = yoffset + tl.arange(0, YBLOCK)[:, None]
    ymask = yindex < ynumel
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[None, :]
    xmask = xindex < xnumel
    x2 = xindex
    y0 = (yindex % 16)
    y1 = yindex // 16
    y3 = yindex
    tmp44 = tl.load(in_ptr0 + (x2 + 512*y0 + 9216*y1), xmask & ymask, eviction_policy='evict_last').to(tl.float32)
    tmp46 = tl.load(in_ptr1 + (y3), ymask, eviction_policy='evict_last')
    tmp53 = tl.load(in_ptr2 + (x2), xmask, eviction_policy='evict_last').to(tl.float32)
    tmp61 = tl.load(in_ptr3 + (32*y1 + ((x2 % 32))), xmask & ymask, eviction_policy='evict_last')
    tmp80 = tl.load(in_ptr4 + (0))
    tmp81 = tl.broadcast_to(tmp80, [1, 1])
    tmp85 = tl.load(in_ptr5 + ((x2 % 32)), xmask, eviction_policy='evict_last').to(tl.float32)
    tmp94 = tl.load(in_ptr6 + (32*y1 + ((x2 % 32))), xmask & ymask, eviction_policy='evict_last')
    tmp0 = x2
    tmp1 = tl.full([1, 1], 0, tl.int64)
    tmp2 = tmp0 >= tmp1
    tmp3 = tl.full([1, 1], 32, tl.int64)
    tmp4 = tmp0 < tmp3
    tmp5 = tl.load(in_ptr0 + (32 + 512*y0 + 9216*y1 + (x2)), tmp4 & xmask & ymask, eviction_policy='evict_last', other=0.0).to(tl.float32)
    tmp6 = tmp5.to(tl.float32)
    tmp7 = tl.load(in_ptr1 + (tl.broadcast_to(y3, [YBLOCK, XBLOCK])), tmp4 & xmask & ymask, eviction_policy='evict_last', other=0.0)
    tmp8 = tl.full([1, 1], 256.0, tl.float32)
    tmp9 = (tmp7 / tmp8)
    tmp10 = tl.full([1, 1], 1e-06, tl.float32)
    tmp11 = tmp9 + tmp10
    tmp12 = libdevice.rsqrt(tmp11)
    tmp13 = tmp6 * tmp12
    tmp14 = tl.load(in_ptr2 + (tl.broadcast_to(32 + (x2), [YBLOCK, XBLOCK])), tmp4 & xmask & ymask, eviction_policy='evict_last', other=0.0).to(tl.float32)
    tmp15 = tmp14.to(tl.float32)
    tmp16 = tl.full([1, 1], 1.0, tl.float32)
    tmp17 = tmp15 + tmp16
    tmp18 = tmp13 * tmp17
    tmp19 = tmp18.to(tl.float32)
    tmp20 = -tmp19
    tmp21 = tl.full(tmp20.shape, 0.0, tmp20.dtype)
    tmp22 = tl.where(tmp4, tmp20, tmp21)
    tmp23 = tmp0 >= tmp3
    tmp24 = tl.full([1, 1], 64, tl.int64)
    tmp25 = tmp0 < tmp24
    tmp26 = tl.load(in_ptr0 + (512*y0 + 9216*y1 + ((-32) + x2)), tmp23 & xmask & ymask, eviction_policy='evict_last', other=0.0).to(tl.float32)
    tmp27 = tmp26.to(tl.float32)
    tmp28 = tl.load(in_ptr1 + (tl.broadcast_to(y3, [YBLOCK, XBLOCK])), tmp23 & xmask & ymask, eviction_policy='evict_last', other=0.0)
    tmp29 = tl.full([1, 1], 256.0, tl.float32)
    tmp30 = (tmp28 / tmp29)
    tmp31 = tl.full([1, 1], 1e-06, tl.float32)
    tmp32 = tmp30 + tmp31
    tmp33 = libdevice.rsqrt(tmp32)
    tmp34 = tmp27 * tmp33
    tmp35 = tl.load(in_ptr2 + (tl.broadcast_to((-32) + x2, [YBLOCK, XBLOCK])), tmp23 & xmask & ymask, eviction_policy='evict_last', other=0.0).to(tl.float32)
    tmp36 = tmp35.to(tl.float32)
    tmp37 = tl.full([1, 1], 1.0, tl.float32)
    tmp38 = tmp36 + tmp37
    tmp39 = tmp34 * tmp38
    tmp40 = tmp39.to(tl.float32)
    tmp41 = tl.full(tmp40.shape, 0.0, tmp40.dtype)
    tmp42 = tl.where(tmp23, tmp40, tmp41)
    tmp43 = tl.where(tmp4, tmp22, tmp42)
    tmp45 = tmp44.to(tl.float32)
    tmp47 = tl.full([1, 1], 256.0, tl.float32)
    tmp48 = (tmp46 / tmp47)
    tmp49 = tl.full([1, 1], 1e-06, tl.float32)
    tmp50 = tmp48 + tmp49
    tmp51 = libdevice.rsqrt(tmp50)
    tmp52 = tmp45 * tmp51
    tmp54 = tmp53.to(tl.float32)
    tmp55 = tl.full([1, 1], 1.0, tl.float32)
    tmp56 = tmp54 + tmp55
    tmp57 = tmp52 * tmp56
    tmp58 = tmp57.to(tl.float32)
    tmp59 = tl.full([1, 1], 0, tl.int32)
    tmp60 = tmp59 == tmp59
    tmp62 = (x2 % 32)
    tmp63 = tl.full([1, 1], 1, tl.int64)
    tmp64 = tmp62 >= tmp63
    tmp65 = (((-1) + ((x2 % 32))) % 3)
    tmp66 = tmp65 == tmp1
    tmp67 = tmp64 & tmp66
    tmp68 = tl.load(in_ptr4 + (0))
    tmp69 = tl.broadcast_to(tmp68, [1, 1])
    tmp70 = tl.where(tmp67, tmp69, 0)
    tmp71 = tl.broadcast_to(y1, [YBLOCK, XBLOCK])
    tmp72 = tmp71 + tmp70
    tmp73 = tmp72.to(tl.float32)
    tmp74 = tl.load(in_ptr5 + (tl.broadcast_to(1 + 3*(triton_helpers.div_floor_integer((-1) + ((x2 % 32)),  3)), [YBLOCK, XBLOCK])), tmp67 & xmask & ymask, eviction_policy='evict_last', other=0.0).to(tl.float32)
    tmp75 = tmp74.to(tl.float32)
    tmp76 = tmp73 * tmp75
    tmp77 = tl_math.cos(tmp76)
    tmp78 = tl.full(tmp77.shape, 0.0, tmp77.dtype)
    tmp79 = tl.where(tmp67, tmp77, tmp78)
    tmp82 = y1
    tmp83 = tmp82 + tmp81
    tmp84 = tmp83.to(tl.float32)
    tmp86 = tmp85.to(tl.float32)
    tmp87 = tmp84 * tmp86
    tmp88 = tl_math.cos(tmp87)
    tmp89 = tl.where(tmp67, tmp79, tmp88)
    tmp90 = tl.where(tmp60, tmp89, tmp88)
    tmp91 = tl.where(tmp60, tmp61, tmp90)
    tmp92 = tmp91.to(tl.float32)
    tmp93 = tmp58 * tmp92
    tmp95 = tl_math.sin(tmp76)
    tmp96 = tl.full(tmp95.shape, 0.0, tmp95.dtype)
    tmp97 = tl.where(tmp67, tmp95, tmp96)
    tmp98 = tl_math.sin(tmp87)
    tmp99 = tl.where(tmp67, tmp97, tmp98)
    tmp100 = tl.where(tmp60, tmp99, tmp98)
    tmp101 = tl.where(tmp60, tmp94, tmp100)
    tmp102 = tmp101.to(tl.float32)
    tmp103 = tmp43 * tmp102
    tmp104 = tmp93 + tmp103
    tl.store(out_ptr2 + (x2 + 256*y1 + 512*y0), tmp104, xmask & ymask)
''', device_str='cuda')


# kernel path: /tmp/infer-opt-models/q35moe-round-profile-20261109/inductor/it/citikjnrbfktbwgxocvnv2kekldx5psnqpzalsvpudmryirzevlp.py
# Topologically Sorted Source Nodes: [float_8, pow_4, mean_3, add_7, rsqrt_3, output_6, float_9, add_8, output_7, type_as_3, query_states_1, q_pass, query_states_2], Original ATen: [aten.split_with_sizes, aten.view, aten.split, aten._to_copy, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.transpose, aten.slice, aten.cat]
# Source node to ATen node mapping:
#   add_7 => add_7
#   add_8 => add_8
#   float_8 => convert_element_type_14, split_3, split_with_sizes_5, view_9
#   float_9 => convert_element_type_15
#   mean_3 => mean_3
#   output_6 => mul_7
#   output_7 => mul_8
#   pow_4 => pow_4
#   q_pass => slice_18
#   query_states_1 => permute
#   query_states_2 => cat_3
#   rsqrt_3 => rsqrt_3
#   type_as_3 => convert_element_type_16
# Graph fragment:
#   %buf10 : Tensor  = PlaceHolder[target=buf10]
#   %buf11 : Tensor "f32[1, 2, 16, 1][32, 16, 1, 32]cuda:0" = PlaceHolder[target=buf11]
#   %arg12_1 : Tensor "bf16[256][1]cuda:0" = PlaceHolder[target=arg12_1]
#   %split_with_sizes_5 : [num_users=1] = call_function[target=torch.ops.aten.split_with_sizes.default](args = (%empty_1, [8192, 512, 512], -1), kwargs = {})
#   %view_9 : Tensor "bf16[1, 2, 16, 512][18432, 9216, 512, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%getitem_23, [1, 2, -1, 512]), kwargs = {})
#   %split_3 : [num_users=1] = call_function[target=torch.ops.aten.split.Tensor](args = (%view_9, 256, -1), kwargs = {})
#   %convert_element_type_14 : Tensor "f32[1, 2, 16, 256][8192, 4096, 256, 1]cuda:0"[num_users=2] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%getitem_26, torch.float32), kwargs = {})
#   %pow_4 : Tensor "f32[1, 2, 16, 256][8192, 4096, 256, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.pow.Tensor_Scalar](args = (%convert_element_type_14, 2), kwargs = {})
#   %mean_3 : Tensor "f32[1, 2, 16, 1][32, 16, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mean.dim](args = (%pow_4, [-1], True), kwargs = {})
#   %add_7 : Tensor "f32[1, 2, 16, 1][32, 16, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%mean_3, 1e-06), kwargs = {})
#   %rsqrt_3 : Tensor "f32[1, 2, 16, 1][32, 16, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.rsqrt.default](args = (%add_7,), kwargs = {})
#   %mul_7 : Tensor "f32[1, 2, 16, 256][8192, 4096, 256, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%convert_element_type_14, %rsqrt_3), kwargs = {})
#   %convert_element_type_15 : Tensor "f32[256][1]cuda:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%arg12_1, torch.float32), kwargs = {})
#   %add_8 : Tensor "f32[256][1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%convert_element_type_15, 1.0), kwargs = {})
#   %mul_8 : Tensor "f32[1, 2, 16, 256][8192, 4096, 256, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%mul_7, %add_8), kwargs = {})
#   %convert_element_type_16 : Tensor "bf16[1, 2, 16, 256][8192, 4096, 256, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%mul_8, torch.bfloat16), kwargs = {})
#   %permute : Tensor "bf16[1, 16, 2, 256][8192, 256, 4096, 1]cuda:0"[num_users=2] = call_function[target=torch.ops.aten.permute.default](args = (%convert_element_type_16, [0, 2, 1, 3]), kwargs = {})
#   %slice_18 : Tensor "bf16[1, 16, 2, 192][8192, 256, 4096, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.slice.Tensor](args = (%permute, 3, 64, 9223372036854775807), kwargs = {})
#   %cat_3 : Tensor "bf16[1, 16, 2, 256][8192, 512, 256, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.cat.default](args = ([%add_11, %slice_18], -1), kwargs = {})
#   return %buf17
triton_poi_fused__to_copy_add_cat_mean_mul_pow_rsqrt_slice_split_split_with_sizes_transpose_view_6 = async_compile.triton('triton_poi_fused__to_copy_add_cat_mean_mul_pow_rsqrt_slice_split_split_with_sizes_transpose_view_6', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.pointwise(
    size_hints={'y': 32, 'x': 256}, tile_hint=TileHint.DEFAULT,
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*bf16', 'in_ptr1': '*fp32', 'in_ptr2': '*bf16', 'out_ptr0': '*bf16', 'ynumel': 'i32', 'xnumel': 'i32', 'YBLOCK': 'constexpr', 'XBLOCK': 'constexpr'}, 'device': DeviceProperties(type='cuda', index=0, multi_processor_count=108, cc=80, major=8, regs_per_multiprocessor=65536, max_threads_per_multi_processor=2048, max_threads_per_block=1024, warp_size=32), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]], (3,): [['tt.divisibility', 16]], (4,): [['tt.divisibility', 16]], (5,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid2D', 'autotune_hints': set(), 'kernel_name': 'triton_poi_fused__to_copy_add_cat_mean_mul_pow_rsqrt_slice_split_split_with_sizes_transpose_view_6', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 3, 'num_store': 1, 'num_reduction': 0, 'backend_hash': 'F7205DDDCE8E401A1728E5D602D369DE155D3FCCD3ACF038A9886E6E0DD93A54', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'max_autotune': True, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': False, 'are_deterministic_algorithms_enabled': False, 'coordinate_descent_tuning': True, 'coordinate_descent_search_radius': 1, 'coordinate_descent_check_all_directions': False, 'tiling_scores': {'y': 128, 'x': 24960}},
    min_elem_per_thread=0
)
@triton.jit
def triton_poi_fused__to_copy_add_cat_mean_mul_pow_rsqrt_slice_split_split_with_sizes_transpose_view_6(in_ptr0, in_ptr1, in_ptr2, out_ptr0, ynumel, xnumel, YBLOCK : tl.constexpr, XBLOCK : tl.constexpr):
    ynumel = 32
    xnumel = 192
    yoffset = tl.program_id(1) * YBLOCK
    yindex = yoffset + tl.arange(0, YBLOCK)[:, None]
    ymask = yindex < ynumel
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[None, :]
    xmask = xindex < xnumel
    x2 = xindex
    y0 = (yindex % 16)
    y1 = yindex // 16
    y3 = yindex
    tmp0 = tl.load(in_ptr0 + (64 + x2 + 512*y0 + 9216*y1), xmask & ymask, eviction_policy='evict_last').to(tl.float32)
    tmp2 = tl.load(in_ptr1 + (y3), ymask, eviction_policy='evict_last')
    tmp9 = tl.load(in_ptr2 + (64 + x2), xmask, eviction_policy='evict_last').to(tl.float32)
    tmp1 = tmp0.to(tl.float32)
    tmp3 = tl.full([1, 1], 256.0, tl.float32)
    tmp4 = (tmp2 / tmp3)
    tmp5 = tl.full([1, 1], 1e-06, tl.float32)
    tmp6 = tmp4 + tmp5
    tmp7 = libdevice.rsqrt(tmp6)
    tmp8 = tmp1 * tmp7
    tmp10 = tmp9.to(tl.float32)
    tmp11 = tl.full([1, 1], 1.0, tl.float32)
    tmp12 = tmp10 + tmp11
    tmp13 = tmp8 * tmp12
    tmp14 = tmp13.to(tl.float32)
    tl.store(out_ptr0 + (x2 + 256*y1 + 512*y0), tmp14, xmask & ymask)
''', device_str='cuda')


# kernel path: /tmp/infer-opt-models/q35moe-round-profile-20261109/inductor/xq/cxq7dkwas6c55bgdcil45zz4vutkfzc7gigou3il2ih2tpvk7n7d.py
# Topologically Sorted Source Nodes: [float_10, pow_5, mean_4], Original ATen: [aten.split_with_sizes, aten.view, aten._to_copy, aten.pow, aten.mean]
# Source node to ATen node mapping:
#   float_10 => convert_element_type_17, split_with_sizes_7, view_12
#   mean_4 => mean_4
#   pow_5 => pow_5
# Graph fragment:
#   %buf10 : Tensor  = PlaceHolder[target=buf10]
#   %split_with_sizes_7 : [num_users=1] = call_function[target=torch.ops.aten.split_with_sizes.default](args = (%empty_1, [8192, 512, 512], -1), kwargs = {})
#   %view_12 : Tensor "bf16[1, 2, 2, 256][18432, 9216, 256, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%getitem_32, [1, 2, -1, 256]), kwargs = {})
#   %convert_element_type_17 : Tensor "f32[1, 2, 2, 256][1024, 512, 256, 1]cuda:0"[num_users=2] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%view_12, torch.float32), kwargs = {})
#   %pow_5 : Tensor "f32[1, 2, 2, 256][1024, 512, 256, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.pow.Tensor_Scalar](args = (%convert_element_type_17, 2), kwargs = {})
#   %mean_4 : Tensor "f32[1, 2, 2, 1][4, 2, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mean.dim](args = (%pow_5, [-1], True), kwargs = {})
#   return %buf19
triton_per_fused__to_copy_mean_pow_split_with_sizes_view_7 = async_compile.triton('triton_per_fused__to_copy_mean_pow_split_with_sizes_view_7', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.persistent_reduction(
    size_hints={'x': 4, 'r0_': 256},
    reduction_hint=ReductionHint.INNER,
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*bf16', 'out_ptr0': '*fp32', 'xnumel': 'i32', 'r0_numel': 'i32', 'XBLOCK': 'constexpr'}, 'device': DeviceProperties(type='cuda', index=0, multi_processor_count=108, cc=80, major=8, regs_per_multiprocessor=65536, max_threads_per_multi_processor=2048, max_threads_per_block=1024, warp_size=32), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (3,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'autotune_hints': set(), 'kernel_name': 'triton_per_fused__to_copy_mean_pow_split_with_sizes_view_7', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': None, 'atomic_add_found': False, 'num_load': 1, 'num_store': 1, 'num_reduction': 1, 'backend_hash': 'F7205DDDCE8E401A1728E5D602D369DE155D3FCCD3ACF038A9886E6E0DD93A54', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'max_autotune': True, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': False, 'are_deterministic_algorithms_enabled': False, 'coordinate_descent_tuning': True, 'coordinate_descent_search_radius': 1, 'coordinate_descent_check_all_directions': False, 'tiling_scores': {'x': 16, 'r0_': 0}}
)
@triton.jit
def triton_per_fused__to_copy_mean_pow_split_with_sizes_view_7(in_ptr0, out_ptr0, xnumel, r0_numel, XBLOCK : tl.constexpr):
    xnumel = 4
    r0_numel = 256
    R0_BLOCK: tl.constexpr = 256
    rnumel = r0_numel
    RBLOCK: tl.constexpr = R0_BLOCK
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:, None]
    xmask = xindex < xnumel
    r0_index = tl.arange(0, R0_BLOCK)[None, :]
    r0_offset = 0
    r0_mask = tl.full([R0_BLOCK], True, tl.int1)[None, :]
    roffset = r0_offset
    rindex = r0_index
    r0_2 = r0_index
    x0 = (xindex % 2)
    x1 = xindex // 2
    x3 = xindex
    tmp0 = tl.load(in_ptr0 + (8192 + r0_2 + 256*x0 + 9216*x1), xmask, other=0.0).to(tl.float32)
    tmp1 = tmp0.to(tl.float32)
    tmp2 = tmp1 * tmp1
    tmp3 = tl.broadcast_to(tmp2, [XBLOCK, R0_BLOCK])
    tmp5 = tl.where(xmask, tmp3, 0)
    tmp6 = tl.sum(tmp5, 1)[:, None].to(tl.float32)
    tl.store(out_ptr0 + (x3), tmp6, xmask)
''', device_str='cuda')


# kernel path: /tmp/infer-opt-models/q35moe-round-profile-20261109/inductor/rl/crlwi37gl2fqfd44ndcijaxgd5egv6uc5n73cpuhriosz6ur5tln.py
# Topologically Sorted Source Nodes: [arange, positions, view, expand, position_ids, getitem, float_1, to, freqs, cos, getitem_2, sin, getitem_5, float_10, cos_1, cos_2, cos_3, sin_1, sin_2, sin_3, pow_5, mean_4, add_9, rsqrt_4, output_8, float_11, add_10, output_9, type_as_4, key_states, k_rot, mul_13, x2_1, neg_1, x1_1, cat_4, mul_14, k_embed], Original ATen: [aten.arange, aten.add, aten.view, aten.expand, aten.unsqueeze, aten._to_copy, aten.mul, aten.cos, aten.select, aten.slice, aten.sin, aten.split_with_sizes, aten.cat, aten.pow, aten.mean, aten.rsqrt, aten.transpose, aten.neg]
# Source node to ATen node mapping:
#   add_10 => add_10
#   add_9 => add_9
#   arange => iota
#   cat_4 => cat_2
#   cos => cos
#   cos_1 => clone, expand_2, select_11, unsqueeze_1, view_1
#   cos_2 => convert_element_type_2
#   cos_3 => unsqueeze_3
#   expand => expand
#   float_1 => convert_element_type
#   float_10 => convert_element_type_17, split_with_sizes_7, view_12
#   float_11 => convert_element_type_18
#   freqs => mul
#   getitem => unsqueeze
#   getitem_2 => select_1, slice_1
#   getitem_5 => select_13, slice_9
#   k_embed => add_12
#   k_rot => slice_19
#   key_states => permute_1
#   mean_4 => mean_4
#   mul_13 => mul_13
#   mul_14 => mul_14
#   neg_1 => neg_1
#   output_8 => mul_9
#   output_9 => mul_10
#   position_ids => expand_1
#   positions => add
#   pow_5 => pow_5
#   rsqrt_4 => rsqrt_4
#   sin => sin
#   sin_1 => clone_2, expand_3, select_23, unsqueeze_2, view_2
#   sin_2 => convert_element_type_3
#   sin_3 => unsqueeze_4
#   to => convert_element_type_1
#   type_as_4 => convert_element_type_19
#   view => view
#   x1_1 => slice_23
#   x2_1 => slice_24
# Graph fragment:
#   %buf10 : Tensor  = PlaceHolder[target=buf10]
#   %buf19 : Tensor "f32[1, 2, 2, 1][4, 2, 1, 4]cuda:0" = PlaceHolder[target=buf19]
#   %arg13_1 : Tensor "bf16[256][1]cuda:0" = PlaceHolder[target=arg13_1]
#   %slice_scatter_default_2 : Tensor "f32[1, 2, 32][64, 32, 1]cuda:0" = PlaceHolder[target=slice_scatter_default_2]
#   %copy_ : Tensor "i64[1][1]cuda:0" = PlaceHolder[target=copy_]
#   %arg3_1 : Tensor "bf16[32][1]cuda:0" = PlaceHolder[target=arg3_1]
#   %mul_13 : Tensor "bf16[1, 2, 2, 64][256, 64, 128, 1]cuda:0" = PlaceHolder[target=mul_13]
#   %cat_2 : Tensor "bf16[1, 2, 2, 64][256, 64, 128, 1]cuda:0" = PlaceHolder[target=cat_2]
#   %slice_scatter_default_3 : Tensor "f32[1, 2, 32][64, 32, 1]cuda:0" = PlaceHolder[target=slice_scatter_default_3]
#   %iota : Tensor "i64[2][1]cuda:0"[num_users=1] = call_function[target=torch.ops.prims.iota.default](args = (2,), kwargs = {start: 0, step: 1, dtype: torch.int64, device: cuda:0, requires_grad: False})
#   %add : Tensor "i64[2][1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%iota, %arg2_1), kwargs = {})
#   %view : Tensor "i64[1, 1, 2][2, 2, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%add, [1, 1, 2]), kwargs = {})
#   %expand : Tensor "i64[3, 1, 2][0, 2, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.expand.default](args = (%view, [3, 1, 2]), kwargs = {})
#   %expand_1 : Tensor "i64[3, 1, 2][0, 2, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.expand.default](args = (%expand, [3, -1, -1]), kwargs = {})
#   %unsqueeze : Tensor "i64[3, 1, 2, 1][0, 2, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%expand_1, 3), kwargs = {})
#   %convert_element_type : Tensor "f32[3, 1, 2, 1][2, 2, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%unsqueeze, torch.float32), kwargs = {})
#   %convert_element_type_1 : Tensor "f32[32][1]cuda:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%arg3_1, torch.float32), kwargs = {})
#   %mul : Tensor "f32[3, 1, 2, 32][64, 64, 32, 1]cuda:0"[num_users=2] = call_function[target=torch.ops.aten.mul.Tensor](args = (%convert_element_type, %convert_element_type_1), kwargs = {})
#   %cos : Tensor "f32[3, 1, 2, 32][64, 64, 32, 1]cuda:0"[num_users=5] = call_function[target=torch.ops.aten.cos.default](args = (%mul,), kwargs = {})
#   %select_1 : Tensor "f32[1, 2, 32][64, 32, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.select.int](args = (%cos, 0, 1), kwargs = {})
#   %slice_1 : Tensor "f32[1, 2, 11][64, 32, 3]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.slice.Tensor](args = (%select_1, 2, 1, 33, 3), kwargs = {})
#   %select_int : Tensor "f32[1, 2, 32][64, 32, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.select.int](args = (%cos, 0, 0), kwargs = {})
#   %slice_scatter_default : Tensor "f32[1, 2, 32][64, 32, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.slice_scatter.default](args = (%select_int, %slice_1, 2, 1, 33, 3), kwargs = {})
#   %select_scatter_default : Tensor "f32[3, 1, 2, 32][64, 64, 32, 1]cuda:0"[num_users=5] = call_function[target=torch.ops.aten.select_scatter.default](args = (%cos, %slice_scatter_default, 0, 0), kwargs = {})
#   %sin : Tensor "f32[3, 1, 2, 32][64, 64, 32, 1]cuda:0"[num_users=5] = call_function[target=torch.ops.aten.sin.default](args = (%mul,), kwargs = {})
#   %select_13 : Tensor "f32[1, 2, 32][64, 32, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.select.int](args = (%sin, 0, 1), kwargs = {})
#   %slice_9 : Tensor "f32[1, 2, 11][64, 32, 3]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.slice.Tensor](args = (%select_13, 2, 1, 33, 3), kwargs = {})
#   %select_int_1 : Tensor "f32[1, 2, 32][64, 32, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.select.int](args = (%sin, 0, 0), kwargs = {})
#   %slice_scatter_default_1 : Tensor "f32[1, 2, 32][64, 32, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.slice_scatter.default](args = (%select_int_1, %slice_9, 2, 1, 33, 3), kwargs = {})
#   %select_scatter_default_1 : Tensor "f32[3, 1, 2, 32][64, 64, 32, 1]cuda:0"[num_users=5] = call_function[target=torch.ops.aten.select_scatter.default](args = (%sin, %slice_scatter_default_1, 0, 0), kwargs = {})
#   %split_with_sizes_7 : [num_users=1] = call_function[target=torch.ops.aten.split_with_sizes.default](args = (%empty_1, [8192, 512, 512], -1), kwargs = {})
#   %select_scatter_default_2 : Tensor "f32[3, 1, 2, 32][64, 64, 32, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.select_scatter.default](args = (%select_scatter_default, %slice_scatter_default_2, 0, 0), kwargs = {})
#   %select_11 : Tensor "f32[1, 2, 32][64, 32, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.select.int](args = (%select_scatter_default_2, 0, 0), kwargs = {})
#   %unsqueeze_1 : Tensor "f32[1, 2, 1, 32][64, 32, 32, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%select_11, 2), kwargs = {})
#   %expand_2 : Tensor "f32[1, 2, 2, 32][64, 32, 0, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.expand.default](args = (%unsqueeze_1, [1, 2, 2, 32]), kwargs = {})
#   %clone : Tensor "f32[1, 2, 2, 32][128, 64, 32, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.clone.default](args = (%expand_2,), kwargs = {memory_format: torch.contiguous_format})
#   %view_1 : Tensor "f32[1, 2, 64][128, 64, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%clone, [1, 2, 64]), kwargs = {})
#   %convert_element_type_2 : Tensor "bf16[1, 2, 64][128, 64, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%view_1, torch.bfloat16), kwargs = {})
#   %unsqueeze_3 : Tensor "bf16[1, 1, 2, 64][128, 128, 64, 1]cuda:0"[num_users=2] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%convert_element_type_2, 1), kwargs = {})
#   %select_scatter_default_3 : Tensor "f32[3, 1, 2, 32][64, 64, 32, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.select_scatter.default](args = (%select_scatter_default_1, %slice_scatter_default_3, 0, 0), kwargs = {})
#   %select_23 : Tensor "f32[1, 2, 32][64, 32, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.select.int](args = (%select_scatter_default_3, 0, 0), kwargs = {})
#   %unsqueeze_2 : Tensor "f32[1, 2, 1, 32][64, 32, 32, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%select_23, 2), kwargs = {})
#   %expand_3 : Tensor "f32[1, 2, 2, 32][64, 32, 0, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.expand.default](args = (%unsqueeze_2, [1, 2, 2, 32]), kwargs = {})
#   %clone_2 : Tensor "f32[1, 2, 2, 32][128, 64, 32, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.clone.default](args = (%expand_3,), kwargs = {memory_format: torch.contiguous_format})
#   %view_2 : Tensor "f32[1, 2, 64][128, 64, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%clone_2, [1, 2, 64]), kwargs = {})
#   %convert_element_type_3 : Tensor "bf16[1, 2, 64][128, 64, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%view_2, torch.bfloat16), kwargs = {})
#   %unsqueeze_4 : Tensor "bf16[1, 1, 2, 64][128, 128, 64, 1]cuda:0"[num_users=2] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%convert_element_type_3, 1), kwargs = {})
#   %view_12 : Tensor "bf16[1, 2, 2, 256][18432, 9216, 256, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%getitem_32, [1, 2, -1, 256]), kwargs = {})
#   %convert_element_type_17 : Tensor "f32[1, 2, 2, 256][1024, 512, 256, 1]cuda:0"[num_users=2] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%view_12, torch.float32), kwargs = {})
#   %pow_5 : Tensor "f32[1, 2, 2, 256][1024, 512, 256, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.pow.Tensor_Scalar](args = (%convert_element_type_17, 2), kwargs = {})
#   %mean_4 : Tensor "f32[1, 2, 2, 1][4, 2, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mean.dim](args = (%pow_5, [-1], True), kwargs = {})
#   %add_9 : Tensor "f32[1, 2, 2, 1][4, 2, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%mean_4, 1e-06), kwargs = {})
#   %rsqrt_4 : Tensor "f32[1, 2, 2, 1][4, 2, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.rsqrt.default](args = (%add_9,), kwargs = {})
#   %mul_9 : Tensor "f32[1, 2, 2, 256][1024, 512, 256, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%convert_element_type_17, %rsqrt_4), kwargs = {})
#   %convert_element_type_18 : Tensor "f32[256][1]cuda:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%arg13_1, torch.float32), kwargs = {})
#   %add_10 : Tensor "f32[256][1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%convert_element_type_18, 1.0), kwargs = {})
#   %mul_10 : Tensor "f32[1, 2, 2, 256][1024, 512, 256, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%mul_9, %add_10), kwargs = {})
#   %convert_element_type_19 : Tensor "bf16[1, 2, 2, 256][1024, 512, 256, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%mul_10, torch.bfloat16), kwargs = {})
#   %permute_1 : Tensor "bf16[1, 2, 2, 256][1024, 256, 512, 1]cuda:0"[num_users=2] = call_function[target=torch.ops.aten.permute.default](args = (%convert_element_type_19, [0, 2, 1, 3]), kwargs = {})
#   %slice_19 : Tensor "bf16[1, 2, 2, 64][1024, 256, 512, 1]cuda:0"[num_users=3] = call_function[target=torch.ops.aten.slice.Tensor](args = (%permute_1, 3, 0, 64), kwargs = {})
#   %mul_13 : Tensor "bf16[1, 2, 2, 64][256, 64, 128, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%slice_19, %unsqueeze_3), kwargs = {})
#   %slice_24 : Tensor "bf16[1, 2, 2, 32][1024, 256, 512, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.slice.Tensor](args = (%slice_19, 3, 32, 9223372036854775807), kwargs = {})
#   %neg_1 : Tensor "bf16[1, 2, 2, 32][128, 32, 64, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.neg.default](args = (%slice_24,), kwargs = {})
#   %slice_23 : Tensor "bf16[1, 2, 2, 32][1024, 256, 512, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.slice.Tensor](args = (%slice_19, 3, 0, 32), kwargs = {})
#   %cat_2 : Tensor "bf16[1, 2, 2, 64][256, 128, 64, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.cat.default](args = ([%neg_1, %slice_23], -1), kwargs = {})
#   %mul_14 : Tensor "bf16[1, 2, 2, 64][256, 128, 64, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%cat_2, %unsqueeze_4), kwargs = {})
#   %add_12 : Tensor "bf16[1, 2, 2, 64][256, 64, 128, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%mul_13, %mul_14), kwargs = {})
#   return %cat_2,%mul_13,%add_12
triton_poi_fused__to_copy_add_arange_cat_cos_expand_mean_mul_neg_pow_rsqrt_select_sin_slice_split_with_sizes_transpose_unsqueeze_view_8 = async_compile.triton('triton_poi_fused__to_copy_add_arange_cat_cos_expand_mean_mul_neg_pow_rsqrt_select_sin_slice_split_with_sizes_transpose_unsqueeze_view_8', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.pointwise(
    size_hints={'x': 256}, 
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*bf16', 'in_ptr1': '*fp32', 'in_ptr2': '*bf16', 'in_ptr3': '*fp32', 'in_ptr4': '*i64', 'in_ptr5': '*bf16', 'in_ptr6': '*fp32', 'out_ptr2': '*bf16', 'xnumel': 'i32', 'XBLOCK': 'constexpr'}, 'device': DeviceProperties(type='cuda', index=0, multi_processor_count=108, cc=80, major=8, regs_per_multiprocessor=65536, max_threads_per_multi_processor=2048, max_threads_per_block=1024, warp_size=32), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]], (3,): [['tt.divisibility', 16]], (4,): [['tt.divisibility', 16]], (5,): [['tt.divisibility', 16]], (6,): [['tt.divisibility', 16]], (7,): [['tt.divisibility', 16]], (8,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'autotune_hints': set(), 'kernel_name': 'triton_poi_fused__to_copy_add_arange_cat_cos_expand_mean_mul_neg_pow_rsqrt_select_sin_slice_split_with_sizes_transpose_unsqueeze_view_8', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 15, 'num_store': 1, 'num_reduction': 0, 'backend_hash': 'F7205DDDCE8E401A1728E5D602D369DE155D3FCCD3ACF038A9886E6E0DD93A54', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'max_autotune': True, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': False, 'are_deterministic_algorithms_enabled': False, 'coordinate_descent_tuning': True, 'coordinate_descent_search_radius': 1, 'coordinate_descent_check_all_directions': False, 'tiling_scores': {'x': 1984}},
    min_elem_per_thread=0
)
@triton.jit
def triton_poi_fused__to_copy_add_arange_cat_cos_expand_mean_mul_neg_pow_rsqrt_select_sin_slice_split_with_sizes_transpose_unsqueeze_view_8(in_ptr0, in_ptr1, in_ptr2, in_ptr3, in_ptr4, in_ptr5, in_ptr6, out_ptr2, xnumel, XBLOCK : tl.constexpr):
    xnumel = 256
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:]
    xmask = xindex < xnumel
    x0 = (xindex % 64)
    x1 = ((xindex // 64) % 2)
    x2 = xindex // 128
    x3 = xindex // 64
    x4 = xindex
    tmp44 = tl.load(in_ptr0 + (8192 + x0 + 256*x1 + 9216*x2), xmask).to(tl.float32)
    tmp46 = tl.load(in_ptr1 + (x3), xmask, eviction_policy='evict_last')
    tmp53 = tl.load(in_ptr2 + (x0), xmask, eviction_policy='evict_last').to(tl.float32)
    tmp61 = tl.load(in_ptr3 + (32*x2 + ((x0 % 32))), xmask, eviction_policy='evict_last')
    tmp80 = tl.load(in_ptr4 + (0))
    tmp81 = tl.broadcast_to(tmp80, [XBLOCK])
    tmp85 = tl.load(in_ptr5 + ((x4 % 32)), xmask, eviction_policy='evict_last').to(tl.float32)
    tmp94 = tl.load(in_ptr6 + (32*x2 + ((x0 % 32))), xmask, eviction_policy='evict_last')
    tmp0 = x0
    tmp1 = tl.full([1], 0, tl.int64)
    tmp2 = tmp0 >= tmp1
    tmp3 = tl.full([1], 32, tl.int64)
    tmp4 = tmp0 < tmp3
    tmp5 = tl.load(in_ptr0 + (8224 + 256*x1 + 9216*x2 + (x0)), tmp4 & xmask, eviction_policy='evict_last', other=0.0).to(tl.float32)
    tmp6 = tmp5.to(tl.float32)
    tmp7 = tl.load(in_ptr1 + (x3), tmp4 & xmask, eviction_policy='evict_last', other=0.0)
    tmp8 = tl.full([1], 256.0, tl.float32)
    tmp9 = (tmp7 / tmp8)
    tmp10 = tl.full([1], 1e-06, tl.float32)
    tmp11 = tmp9 + tmp10
    tmp12 = libdevice.rsqrt(tmp11)
    tmp13 = tmp6 * tmp12
    tmp14 = tl.load(in_ptr2 + (32 + (x0)), tmp4 & xmask, eviction_policy='evict_last', other=0.0).to(tl.float32)
    tmp15 = tmp14.to(tl.float32)
    tmp16 = tl.full([1], 1.0, tl.float32)
    tmp17 = tmp15 + tmp16
    tmp18 = tmp13 * tmp17
    tmp19 = tmp18.to(tl.float32)
    tmp20 = -tmp19
    tmp21 = tl.full(tmp20.shape, 0.0, tmp20.dtype)
    tmp22 = tl.where(tmp4, tmp20, tmp21)
    tmp23 = tmp0 >= tmp3
    tmp24 = tl.full([1], 64, tl.int64)
    tmp25 = tmp0 < tmp24
    tmp26 = tl.load(in_ptr0 + (8192 + 256*x1 + 9216*x2 + ((-32) + x0)), tmp23 & xmask, eviction_policy='evict_last', other=0.0).to(tl.float32)
    tmp27 = tmp26.to(tl.float32)
    tmp28 = tl.load(in_ptr1 + (x3), tmp23 & xmask, eviction_policy='evict_last', other=0.0)
    tmp29 = tl.full([1], 256.0, tl.float32)
    tmp30 = (tmp28 / tmp29)
    tmp31 = tl.full([1], 1e-06, tl.float32)
    tmp32 = tmp30 + tmp31
    tmp33 = libdevice.rsqrt(tmp32)
    tmp34 = tmp27 * tmp33
    tmp35 = tl.load(in_ptr2 + ((-32) + x0), tmp23 & xmask, eviction_policy='evict_last', other=0.0).to(tl.float32)
    tmp36 = tmp35.to(tl.float32)
    tmp37 = tl.full([1], 1.0, tl.float32)
    tmp38 = tmp36 + tmp37
    tmp39 = tmp34 * tmp38
    tmp40 = tmp39.to(tl.float32)
    tmp41 = tl.full(tmp40.shape, 0.0, tmp40.dtype)
    tmp42 = tl.where(tmp23, tmp40, tmp41)
    tmp43 = tl.where(tmp4, tmp22, tmp42)
    tmp45 = tmp44.to(tl.float32)
    tmp47 = tl.full([1], 256.0, tl.float32)
    tmp48 = (tmp46 / tmp47)
    tmp49 = tl.full([1], 1e-06, tl.float32)
    tmp50 = tmp48 + tmp49
    tmp51 = libdevice.rsqrt(tmp50)
    tmp52 = tmp45 * tmp51
    tmp54 = tmp53.to(tl.float32)
    tmp55 = tl.full([1], 1.0, tl.float32)
    tmp56 = tmp54 + tmp55
    tmp57 = tmp52 * tmp56
    tmp58 = tmp57.to(tl.float32)
    tmp59 = tl.full([1], 0, tl.int32)
    tmp60 = tmp59 == tmp59
    tmp62 = (x4 % 32)
    tmp63 = tl.full([1], 1, tl.int64)
    tmp64 = tmp62 >= tmp63
    tmp65 = (((-1) + ((x0 % 32))) % 3)
    tmp66 = tmp65 == tmp1
    tmp67 = tmp64 & tmp66
    tmp68 = tl.load(in_ptr4 + (0))
    tmp69 = tl.broadcast_to(tmp68, [XBLOCK])
    tmp70 = tl.where(tmp67, tmp69, 0)
    tmp71 = x2
    tmp72 = tmp71 + tmp70
    tmp73 = tmp72.to(tl.float32)
    tmp74 = tl.load(in_ptr5 + (1 + 3*(triton_helpers.div_floor_integer((-1) + ((x0 % 32)),  3))), tmp67 & xmask, eviction_policy='evict_last', other=0.0).to(tl.float32)
    tmp75 = tmp74.to(tl.float32)
    tmp76 = tmp73 * tmp75
    tmp77 = tl_math.cos(tmp76)
    tmp78 = tl.full(tmp77.shape, 0.0, tmp77.dtype)
    tmp79 = tl.where(tmp67, tmp77, tmp78)
    tmp82 = x2
    tmp83 = tmp82 + tmp81
    tmp84 = tmp83.to(tl.float32)
    tmp86 = tmp85.to(tl.float32)
    tmp87 = tmp84 * tmp86
    tmp88 = tl_math.cos(tmp87)
    tmp89 = tl.where(tmp67, tmp79, tmp88)
    tmp90 = tl.where(tmp60, tmp89, tmp88)
    tmp91 = tl.where(tmp60, tmp61, tmp90)
    tmp92 = tmp91.to(tl.float32)
    tmp93 = tmp58 * tmp92
    tmp95 = tl_math.sin(tmp76)
    tmp96 = tl.full(tmp95.shape, 0.0, tmp95.dtype)
    tmp97 = tl.where(tmp67, tmp95, tmp96)
    tmp98 = tl_math.sin(tmp87)
    tmp99 = tl.where(tmp67, tmp97, tmp98)
    tmp100 = tl.where(tmp60, tmp99, tmp98)
    tmp101 = tl.where(tmp60, tmp94, tmp100)
    tmp102 = tmp101.to(tl.float32)
    tmp103 = tmp43 * tmp102
    tmp104 = tmp93 + tmp103
    tl.store(out_ptr2 + (x0 + 256*x2 + 512*x1), tmp104, xmask)
''', device_str='cuda')


# kernel path: /tmp/infer-opt-models/q35moe-round-profile-20261109/inductor/lk/clkj5nngmieofjr7bvo4ljcpf72okoeb226fag7nsqzbzsh6ilof.py
# Topologically Sorted Source Nodes: [float_10, pow_5, mean_4, add_9, rsqrt_4, output_8, float_11, add_10, output_9, type_as_4, key_states, k_pass, key_states_1], Original ATen: [aten.split_with_sizes, aten.view, aten._to_copy, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.transpose, aten.slice, aten.cat]
# Source node to ATen node mapping:
#   add_10 => add_10
#   add_9 => add_9
#   float_10 => convert_element_type_17, split_with_sizes_7, view_12
#   float_11 => convert_element_type_18
#   k_pass => slice_20
#   key_states => permute_1
#   key_states_1 => cat_4
#   mean_4 => mean_4
#   output_8 => mul_9
#   output_9 => mul_10
#   pow_5 => pow_5
#   rsqrt_4 => rsqrt_4
#   type_as_4 => convert_element_type_19
# Graph fragment:
#   %buf10 : Tensor  = PlaceHolder[target=buf10]
#   %buf19 : Tensor "f32[1, 2, 2, 1][4, 2, 1, 4]cuda:0" = PlaceHolder[target=buf19]
#   %arg13_1 : Tensor "bf16[256][1]cuda:0" = PlaceHolder[target=arg13_1]
#   %split_with_sizes_7 : [num_users=1] = call_function[target=torch.ops.aten.split_with_sizes.default](args = (%empty_1, [8192, 512, 512], -1), kwargs = {})
#   %view_12 : Tensor "bf16[1, 2, 2, 256][18432, 9216, 256, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%getitem_32, [1, 2, -1, 256]), kwargs = {})
#   %convert_element_type_17 : Tensor "f32[1, 2, 2, 256][1024, 512, 256, 1]cuda:0"[num_users=2] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%view_12, torch.float32), kwargs = {})
#   %pow_5 : Tensor "f32[1, 2, 2, 256][1024, 512, 256, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.pow.Tensor_Scalar](args = (%convert_element_type_17, 2), kwargs = {})
#   %mean_4 : Tensor "f32[1, 2, 2, 1][4, 2, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mean.dim](args = (%pow_5, [-1], True), kwargs = {})
#   %add_9 : Tensor "f32[1, 2, 2, 1][4, 2, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%mean_4, 1e-06), kwargs = {})
#   %rsqrt_4 : Tensor "f32[1, 2, 2, 1][4, 2, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.rsqrt.default](args = (%add_9,), kwargs = {})
#   %mul_9 : Tensor "f32[1, 2, 2, 256][1024, 512, 256, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%convert_element_type_17, %rsqrt_4), kwargs = {})
#   %convert_element_type_18 : Tensor "f32[256][1]cuda:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%arg13_1, torch.float32), kwargs = {})
#   %add_10 : Tensor "f32[256][1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%convert_element_type_18, 1.0), kwargs = {})
#   %mul_10 : Tensor "f32[1, 2, 2, 256][1024, 512, 256, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%mul_9, %add_10), kwargs = {})
#   %convert_element_type_19 : Tensor "bf16[1, 2, 2, 256][1024, 512, 256, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%mul_10, torch.bfloat16), kwargs = {})
#   %permute_1 : Tensor "bf16[1, 2, 2, 256][1024, 256, 512, 1]cuda:0"[num_users=2] = call_function[target=torch.ops.aten.permute.default](args = (%convert_element_type_19, [0, 2, 1, 3]), kwargs = {})
#   %slice_20 : Tensor "bf16[1, 2, 2, 192][1024, 256, 512, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.slice.Tensor](args = (%permute_1, 3, 64, 9223372036854775807), kwargs = {})
#   %cat_4 : Tensor "bf16[1, 2, 2, 256][1024, 512, 256, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.cat.default](args = ([%add_12, %slice_20], -1), kwargs = {})
#   return %buf23
triton_poi_fused__to_copy_add_cat_mean_mul_pow_rsqrt_slice_split_with_sizes_transpose_view_9 = async_compile.triton('triton_poi_fused__to_copy_add_cat_mean_mul_pow_rsqrt_slice_split_with_sizes_transpose_view_9', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.pointwise(
    size_hints={'x': 1024}, 
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*bf16', 'in_ptr1': '*fp32', 'in_ptr2': '*bf16', 'out_ptr0': '*bf16', 'xnumel': 'i32', 'XBLOCK': 'constexpr'}, 'device': DeviceProperties(type='cuda', index=0, multi_processor_count=108, cc=80, major=8, regs_per_multiprocessor=65536, max_threads_per_multi_processor=2048, max_threads_per_block=1024, warp_size=32), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]], (3,): [['tt.divisibility', 16]], (4,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'autotune_hints': set(), 'kernel_name': 'triton_poi_fused__to_copy_add_cat_mean_mul_pow_rsqrt_slice_split_with_sizes_transpose_view_9', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 3, 'num_store': 1, 'num_reduction': 0, 'backend_hash': 'F7205DDDCE8E401A1728E5D602D369DE155D3FCCD3ACF038A9886E6E0DD93A54', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'max_autotune': True, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': False, 'are_deterministic_algorithms_enabled': False, 'coordinate_descent_tuning': True, 'coordinate_descent_search_radius': 1, 'coordinate_descent_check_all_directions': False, 'tiling_scores': {'x': 3456}},
    min_elem_per_thread=0
)
@triton.jit
def triton_poi_fused__to_copy_add_cat_mean_mul_pow_rsqrt_slice_split_with_sizes_transpose_view_9(in_ptr0, in_ptr1, in_ptr2, out_ptr0, xnumel, XBLOCK : tl.constexpr):
    xnumel = 768
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:]
    xmask = xindex < xnumel
    x0 = (xindex % 192)
    x1 = ((xindex // 192) % 2)
    x2 = xindex // 384
    x3 = xindex // 192
    tmp0 = tl.load(in_ptr0 + (8256 + x0 + 256*x1 + 9216*x2), xmask).to(tl.float32)
    tmp2 = tl.load(in_ptr1 + (x3), xmask, eviction_policy='evict_last')
    tmp9 = tl.load(in_ptr2 + (64 + x0), xmask, eviction_policy='evict_last').to(tl.float32)
    tmp1 = tmp0.to(tl.float32)
    tmp3 = tl.full([1], 256.0, tl.float32)
    tmp4 = (tmp2 / tmp3)
    tmp5 = tl.full([1], 1e-06, tl.float32)
    tmp6 = tmp4 + tmp5
    tmp7 = libdevice.rsqrt(tmp6)
    tmp8 = tmp1 * tmp7
    tmp10 = tmp9.to(tl.float32)
    tmp11 = tl.full([1], 1.0, tl.float32)
    tmp12 = tmp10 + tmp11
    tmp13 = tmp8 * tmp12
    tmp14 = tmp13.to(tl.float32)
    tl.store(out_ptr0 + (x0 + 256*x2 + 512*x1), tmp14, xmask)
''', device_str='cuda')


# kernel path: /tmp/infer-opt-models/q35moe-round-profile-20261109/inductor/es/ces4t443lvoqyhwh7nw2ftjz56l7npstaayo5w5syn76sztyfvbj.py
# Topologically Sorted Source Nodes: [arange_1, index, index_copy_], Original ATen: [aten.arange, aten.add, aten.index_copy]
# Source node to ATen node mapping:
#   arange_1 => iota_1
#   index => add_13
#   index_copy_ => index_put
# Graph fragment:
#   %copy_ : Tensor "i64[1][1]cuda:0" = PlaceHolder[target=copy_]
#   %cat_4 : Tensor "bf16[1, 2, 2, 256][1024, 512, 256, 1]cuda:0" = PlaceHolder[target=cat_4]
#   %index_put : Tensor "bf16[1, 2, 2048, 256][1048576, 524288, 256, 1]cuda:0" = PlaceHolder[target=index_put]
#   %iota_1 : Tensor "i64[2][1]cuda:0"[num_users=1] = call_function[target=torch.ops.prims.iota.default](args = (2,), kwargs = {start: 0, step: 1, dtype: torch.int64, device: cuda:0, requires_grad: False})
#   %add_13 : Tensor "i64[2][1]cuda:0"[num_users=2] = call_function[target=torch.ops.aten.add.Tensor](args = (%arg2_1, %iota_1), kwargs = {})
#   %index_put : Tensor "bf16[1, 2, 2048, 256][1048576, 524288, 256, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.index_put_.default](args = (%arg14_1, [None, None, %add_13], %cat_4), kwargs = {})
#   return %buf25
triton_poi_fused_add_arange_index_copy_10 = async_compile.triton('triton_poi_fused_add_arange_index_copy_10', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.pointwise(
    size_hints={'x': 1024}, 
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*i64', 'in_ptr1': '*bf16', 'out_ptr0': '*bf16', 'xnumel': 'i32', 'XBLOCK': 'constexpr'}, 'device': DeviceProperties(type='cuda', index=0, multi_processor_count=108, cc=80, major=8, regs_per_multiprocessor=65536, max_threads_per_multi_processor=2048, max_threads_per_block=1024, warp_size=32), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]], (3,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'autotune_hints': set(), 'kernel_name': 'triton_poi_fused_add_arange_index_copy_10', 'mutated_arg_names': ['out_ptr0'], 'optimize_mem': True, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 2, 'num_store': 1, 'num_reduction': 0, 'backend_hash': 'F7205DDDCE8E401A1728E5D602D369DE155D3FCCD3ACF038A9886E6E0DD93A54', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'max_autotune': True, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': False, 'are_deterministic_algorithms_enabled': False, 'coordinate_descent_tuning': True, 'coordinate_descent_search_radius': 1, 'coordinate_descent_check_all_directions': False, 'tiling_scores': {'x': 2048}},
    min_elem_per_thread=0
)
@triton.jit
def triton_poi_fused_add_arange_index_copy_10(in_ptr0, in_ptr1, out_ptr0, xnumel, XBLOCK : tl.constexpr):
    xnumel = 1024
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:]
    xmask = xindex < xnumel
    x1 = ((xindex // 256) % 2)
    x3 = xindex
    x0 = (xindex % 256)
    x2 = xindex // 512
    tmp0 = tl.load(in_ptr0 + (0))
    tmp1 = tl.broadcast_to(tmp0, [XBLOCK])
    tmp9 = tl.load(in_ptr1 + (x3), xmask).to(tl.float32)
    tmp2 = x1
    tmp3 = tmp1 + tmp2
    tmp4 = tl.full([XBLOCK], 2048, tl.int32)
    tmp5 = tmp3 + tmp4
    tmp6 = tmp3 < 0
    tmp7 = tl.where(tmp6, tmp5, tmp3)
    tl.device_assert(((0 <= tmp7) & (tmp7 < 2048)) | ~(xmask), "index out of bounds: 0 <= tmp7 < 2048")
    tl.store(out_ptr0 + (x0 + 256*tmp7 + 524288*x2), tmp9, xmask)
''', device_str='cuda')


# kernel path: /tmp/infer-opt-models/q35moe-round-profile-20261109/inductor/ko/ckohdpcb6ymdrizqascwmr5pxobpze7qs37v74nshbjz3rq3dz7c.py
# Topologically Sorted Source Nodes: [index_copy__1, arange_1, index], Original ATen: [aten.split_with_sizes, aten.arange, aten.add, aten.view, aten.transpose, aten.index_copy]
# Source node to ATen node mapping:
#   arange_1 => iota_1
#   index => add_13
#   index_copy__1 => index_put_1, permute_3, split_with_sizes_10, view_15
# Graph fragment:
#   %copy_ : Tensor "i64[1][1]cuda:0" = PlaceHolder[target=copy_]
#   %buf10 : Tensor  = PlaceHolder[target=buf10]
#   %index_put_1 : Tensor "bf16[1, 2, 2048, 256][1048576, 524288, 256, 1]cuda:0" = PlaceHolder[target=index_put_1]
#   %split_with_sizes_10 : [num_users=1] = call_function[target=torch.ops.aten.split_with_sizes.default](args = (%empty_1, [8192, 512, 512], -1), kwargs = {})
#   %iota_1 : Tensor "i64[2][1]cuda:0"[num_users=1] = call_function[target=torch.ops.prims.iota.default](args = (2,), kwargs = {start: 0, step: 1, dtype: torch.int64, device: cuda:0, requires_grad: False})
#   %add_13 : Tensor "i64[2][1]cuda:0"[num_users=2] = call_function[target=torch.ops.aten.add.Tensor](args = (%arg2_1, %iota_1), kwargs = {})
#   %view_15 : Tensor "bf16[1, 2, 2, 256][18432, 9216, 256, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%getitem_42, [1, 2, -1, 256]), kwargs = {})
#   %permute_3 : Tensor "bf16[1, 2, 2, 256][18432, 256, 9216, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.permute.default](args = (%view_15, [0, 2, 1, 3]), kwargs = {})
#   %index_put_1 : Tensor "bf16[1, 2, 2048, 256][1048576, 524288, 256, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.index_put_.default](args = (%arg15_1, [None, None, %add_13], %permute_3), kwargs = {})
#   return %buf26
triton_poi_fused_add_arange_index_copy_split_with_sizes_transpose_view_11 = async_compile.triton('triton_poi_fused_add_arange_index_copy_split_with_sizes_transpose_view_11', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.pointwise(
    size_hints={'x': 1024}, 
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*i64', 'in_ptr1': '*bf16', 'out_ptr0': '*bf16', 'xnumel': 'i32', 'XBLOCK': 'constexpr'}, 'device': DeviceProperties(type='cuda', index=0, multi_processor_count=108, cc=80, major=8, regs_per_multiprocessor=65536, max_threads_per_multi_processor=2048, max_threads_per_block=1024, warp_size=32), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]], (3,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'autotune_hints': set(), 'kernel_name': 'triton_poi_fused_add_arange_index_copy_split_with_sizes_transpose_view_11', 'mutated_arg_names': ['out_ptr0'], 'optimize_mem': True, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 2, 'num_store': 1, 'num_reduction': 0, 'backend_hash': 'F7205DDDCE8E401A1728E5D602D369DE155D3FCCD3ACF038A9886E6E0DD93A54', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'max_autotune': True, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': False, 'are_deterministic_algorithms_enabled': False, 'coordinate_descent_tuning': True, 'coordinate_descent_search_radius': 1, 'coordinate_descent_check_all_directions': False, 'tiling_scores': {'x': 0}},
    min_elem_per_thread=0
)
@triton.jit
def triton_poi_fused_add_arange_index_copy_split_with_sizes_transpose_view_11(in_ptr0, in_ptr1, out_ptr0, xnumel, XBLOCK : tl.constexpr):
    xnumel = 1024
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:]
    xmask = xindex < xnumel
    x2 = xindex // 512
    x3 = (xindex % 512)
    x0 = (xindex % 256)
    x1 = ((xindex // 256) % 2)
    tmp0 = tl.load(in_ptr0 + (0))
    tmp1 = tl.broadcast_to(tmp0, [XBLOCK])
    tmp9 = tl.load(in_ptr1 + (8704 + x3 + 9216*x2), xmask).to(tl.float32)
    tmp2 = x2
    tmp3 = tmp1 + tmp2
    tmp4 = tl.full([XBLOCK], 2048, tl.int32)
    tmp5 = tmp3 + tmp4
    tmp6 = tmp3 < 0
    tmp7 = tl.where(tmp6, tmp5, tmp3)
    tl.device_assert(((0 <= tmp7) & (tmp7 < 2048)) | ~(xmask), "index out of bounds: 0 <= tmp7 < 2048")
    tl.store(out_ptr0 + (x0 + 256*tmp7 + 524288*x1), tmp9, xmask)
''', device_str='cuda')


# Original path: /content/q35moe-round-profile-20261109/infer-opt/infer_opt/attention_kernels.py:30
_decode_attention_kernel_2 = async_compile.triton('_decode_attention_kernel', '''

import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties

@triton_heuristics.user_autotune(
    configs=[{'num_warps': 4, 'num_stages': 3}],
    inductor_meta={'grid_type': 'FixedGrid', 'fixed_grid': ['_grid_0', '_grid_1', '_grid_2'], 'extra_launcher_args': ['_grid_0', '_grid_1', '_grid_2'], 'kernel_name': '_decode_attention_kernel_2', 'backend_hash': 'F7205DDDCE8E401A1728E5D602D369DE155D3FCCD3ACF038A9886E6E0DD93A54', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'max_autotune': True, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': False, 'are_deterministic_algorithms_enabled': False, 'coordinate_descent_tuning': True, 'coordinate_descent_search_radius': 1, 'coordinate_descent_check_all_directions': False},
    triton_meta={'signature': {'q_ptr': '*bf16', 'k_ptr': '*bf16', 'v_ptr': '*bf16', 'pos_ptr': '*i64', 'm_ptr': '*fp32', 'l_ptr': '*fp32', 'o_ptr': '*fp32', 'L': 'i32', 'scale': 'fp64', 'G': 'constexpr', 'G_PAD': 'constexpr', 'T': 'constexpr', 'D': 'constexpr', 'CHUNK': 'constexpr'}, 'device': DeviceProperties(type='cuda', index=0, multi_processor_count=108, cc=80, major=8, regs_per_multiprocessor=65536, max_threads_per_multi_processor=2048, max_threads_per_block=1024, warp_size=32), 'constants': {'G': 16, 'G_PAD': 16, 'T': 2, 'D': 256, 'CHUNK': 64}, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]], (3,): [['tt.divisibility', 16]], (4,): [['tt.divisibility', 16]], (5,): [['tt.divisibility', 16]], (6,): [['tt.divisibility', 16]], (7,): [['tt.divisibility', 16]]}]},
    filename=__file__,
    custom_kernel=True,
)
@triton.jit
def _decode_attention_kernel(q_ptr, k_ptr, v_ptr, pos_ptr, m_ptr, l_ptr, o_ptr, L, scale,
                             G: tl.constexpr, G_PAD: tl.constexpr, T: tl.constexpr, D: tl.constexpr,
                             CHUNK: tl.constexpr):
    head = tl.program_id(0)  # batch * KV heads
    split = tl.program_id(1)
    n_split = tl.num_programs(1)
    g = tl.arange(0, G_PAD)
    d = tl.arange(0, D)
    keys = split * CHUNK + tl.arange(0, CHUNK)
    position = tl.load(pos_ptr)
    part = (head * n_split + split) * G + g  # row of this (head, split, query head) in the partial buffers
    g_ok = g < G
    if split * CHUNK > position + T - 1:  # nothing filled in this slice
        tl.store(m_ptr + part, tl.full((G_PAD,), float("-inf"), tl.float32), mask=g_ok)
        tl.store(l_ptr + part, tl.zeros((G_PAD,), tl.float32), mask=g_ok)
        tl.store(o_ptr + part[:, None] * D + d[None, :], tl.zeros((G_PAD, D), tl.float32), mask=g_ok[:, None])
        return
    q = tl.load(q_ptr + (head * G + g)[:, None] * D + d[None, :], mask=g_ok[:, None], other=0.0)
    kv_ok = (keys < L)[:, None]
    kv_off = (head.to(tl.int64) * L + keys)[:, None] * D + d[None, :]
    k = tl.load(k_ptr + kv_off, mask=kv_ok, other=0.0)
    scores = tl.dot(q, tl.trans(k)) * scale  # [G_PAD, CHUNK], fp32
    if T == 1:
        scores = tl.where((keys <= position)[None, :], scores, float("-inf"))
        m = tl.max(scores, axis=1)
        p = tl.exp(scores - m[:, None])
    else:
        scores = tl.where(keys[None, :] <= (position + g % T)[:, None], scores, float("-inf"))
        m = tl.max(scores, axis=1)
        p = tl.exp(scores - tl.where(m == float("-inf"), 0.0, m)[:, None])  # rows with no key here: p = 0
    v = tl.load(v_ptr + kv_off, mask=kv_ok, other=0.0)
    o = tl.dot(p.to(v.dtype), v)  # [G_PAD, D], fp32
    tl.store(m_ptr + part, m, mask=g_ok)
    tl.store(l_ptr + part, tl.sum(p, axis=1), mask=g_ok)
    tl.store(o_ptr + part[:, None] * D + d[None, :], o, mask=g_ok[:, None])
''', device_str='cuda')


# kernel path: /tmp/infer-opt-models/q35moe-round-profile-20261109/inductor/gf/cgftcyeffmn2ojt3iycv6eglwgtar7aj27pdhddplrmi3phwnety.py
# Topologically Sorted Source Nodes: [amax, sub, weight, mul_16, sum_2], Original ATen: [aten.amax, aten.sub, aten.exp, aten.mul, aten.sum]
# Source node to ATen node mapping:
#   amax => amax
#   mul_16 => mul_16
#   sub => sub
#   sum_2 => sum_3
#   weight => exp
# Graph fragment:
#   %buf30 : Tensor  = PlaceHolder[target=buf30]
#   %amax : Tensor "f32[1, 2, 1, 16][32, 16, 32, 1]cuda:0" = PlaceHolder[target=amax]
#   %buf31 : Tensor  = PlaceHolder[target=buf31]
#   %amax : Tensor "f32[1, 2, 1, 16][32, 16, 16, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.amax.default](args = (%empty_2, [2], True), kwargs = {})
#   %sub : Tensor "f32[1, 2, 32, 16][1024, 512, 16, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.sub.Tensor](args = (%empty_2, %amax), kwargs = {})
#   %exp : Tensor "f32[1, 2, 32, 16][1024, 512, 16, 1]cuda:0"[num_users=2] = call_function[target=torch.ops.aten.exp.default](args = (%sub,), kwargs = {})
#   %mul_16 : Tensor "f32[1, 2, 32, 16][1024, 512, 16, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%exp, %empty_3), kwargs = {})
#   %sum_3 : Tensor "f32[1, 2, 16][32, 16, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.sum.dim_IntList](args = (%mul_16, [2]), kwargs = {})
#   return %amax,%sum_3
triton_per_fused_amax_exp_mul_sub_sum_12 = async_compile.triton('triton_per_fused_amax_exp_mul_sub_sum_12', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.persistent_reduction(
    size_hints={'x': 32, 'r0_': 32},
    reduction_hint=ReductionHint.DEFAULT,
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*fp32', 'in_ptr1': '*fp32', 'out_ptr0': '*fp32', 'out_ptr1': '*fp32', 'xnumel': 'i32', 'r0_numel': 'i32', 'XBLOCK': 'constexpr'}, 'device': DeviceProperties(type='cuda', index=0, multi_processor_count=108, cc=80, major=8, regs_per_multiprocessor=65536, max_threads_per_multi_processor=2048, max_threads_per_block=1024, warp_size=32), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]], (3,): [['tt.divisibility', 16]], (4,): [['tt.divisibility', 16]], (5,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'autotune_hints': set(), 'kernel_name': 'triton_per_fused_amax_exp_mul_sub_sum_12', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': None, 'atomic_add_found': False, 'num_load': 2, 'num_store': 2, 'num_reduction': 2, 'backend_hash': 'F7205DDDCE8E401A1728E5D602D369DE155D3FCCD3ACF038A9886E6E0DD93A54', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'max_autotune': True, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': False, 'are_deterministic_algorithms_enabled': False, 'coordinate_descent_tuning': True, 'coordinate_descent_search_radius': 1, 'coordinate_descent_check_all_directions': False, 'tiling_scores': {'x': 512, 'r0_': 0}}
)
@triton.jit
def triton_per_fused_amax_exp_mul_sub_sum_12(in_ptr0, in_ptr1, out_ptr0, out_ptr1, xnumel, r0_numel, XBLOCK : tl.constexpr):
    xnumel = 32
    r0_numel = 32
    R0_BLOCK: tl.constexpr = 32
    rnumel = r0_numel
    RBLOCK: tl.constexpr = R0_BLOCK
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:, None]
    xmask = xindex < xnumel
    r0_index = tl.arange(0, R0_BLOCK)[None, :]
    r0_offset = 0
    r0_mask = tl.full([R0_BLOCK], True, tl.int1)[None, :]
    roffset = r0_offset
    rindex = r0_index
    r0_2 = r0_index
    x0 = (xindex % 16)
    x1 = xindex // 16
    x3 = xindex
    tmp0 = tl.load(in_ptr0 + (x0 + 16*r0_2 + 512*x1), xmask, other=0.0)
    tmp7 = tl.load(in_ptr1 + (x0 + 16*r0_2 + 512*x1), xmask, other=0.0)
    tmp1 = tl.broadcast_to(tmp0, [XBLOCK, R0_BLOCK])
    tmp3 = tl.where(xmask, tmp1, float("-inf"))
    tmp4 = triton_helpers.max2(tmp3, 1)[:, None].to(tl.float32)
    tmp5 = tmp0 - tmp4
    tmp6 = libdevice.exp(tmp5)
    tmp8 = tmp6 * tmp7
    tmp9 = tl.broadcast_to(tmp8, [XBLOCK, R0_BLOCK])
    tmp11 = tl.where(xmask, tmp9, 0)
    tmp12 = tl.sum(tmp11, 1)[:, None].to(tl.float32)
    tl.store(out_ptr0 + (x3), tmp4, xmask)
    tl.store(out_ptr1 + (x3), tmp12, xmask)
''', device_str='cuda')


# kernel path: /tmp/infer-opt-models/q35moe-round-profile-20261109/inductor/fo/cfoct6nvfa7hphkzuxab6es6rl6sityqdr6ykbvsys2wybtvij2k.py
# Topologically Sorted Source Nodes: [sub, weight, unsqueeze_2, mul_15, sum_1], Original ATen: [aten.sub, aten.exp, aten.unsqueeze, aten.mul, aten.sum]
# Source node to ATen node mapping:
#   mul_15 => mul_15
#   sub => sub
#   sum_1 => sum_2
#   unsqueeze_2 => unsqueeze_5
#   weight => exp
# Graph fragment:
#   %buf30 : Tensor  = PlaceHolder[target=buf30]
#   %amax : Tensor "f32[1, 2, 1, 16][32, 16, 32, 1]cuda:0" = PlaceHolder[target=amax]
#   %buf32 : Tensor  = PlaceHolder[target=buf32]
#   %sub : Tensor "f32[1, 2, 32, 16][1024, 512, 16, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.sub.Tensor](args = (%empty_2, %amax), kwargs = {})
#   %exp : Tensor "f32[1, 2, 32, 16][1024, 512, 16, 1]cuda:0"[num_users=2] = call_function[target=torch.ops.aten.exp.default](args = (%sub,), kwargs = {})
#   %unsqueeze_5 : Tensor "f32[1, 2, 32, 16, 1][1024, 512, 16, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%exp, -1), kwargs = {})
#   %mul_15 : Tensor "f32[1, 2, 32, 16, 256][262144, 131072, 4096, 256, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%unsqueeze_5, %empty_4), kwargs = {})
#   %sum_2 : Tensor "f32[1, 2, 16, 256][8192, 4096, 256, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.sum.dim_IntList](args = (%mul_15, [2]), kwargs = {})
#   return %sum_2
triton_per_fused_exp_mul_sub_sum_unsqueeze_13 = async_compile.triton('triton_per_fused_exp_mul_sub_sum_unsqueeze_13', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.persistent_reduction(
    size_hints={'x': 8192, 'r0_': 32},
    reduction_hint=ReductionHint.DEFAULT,
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*fp32', 'in_ptr1': '*fp32', 'in_ptr2': '*fp32', 'out_ptr0': '*fp32', 'xnumel': 'i32', 'r0_numel': 'i32', 'XBLOCK': 'constexpr'}, 'device': DeviceProperties(type='cuda', index=0, multi_processor_count=108, cc=80, major=8, regs_per_multiprocessor=65536, max_threads_per_multi_processor=2048, max_threads_per_block=1024, warp_size=32), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]], (3,): [['tt.divisibility', 16]], (4,): [['tt.divisibility', 16]], (5,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'autotune_hints': set(), 'kernel_name': 'triton_per_fused_exp_mul_sub_sum_unsqueeze_13', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': None, 'atomic_add_found': False, 'num_load': 3, 'num_store': 1, 'num_reduction': 1, 'backend_hash': 'F7205DDDCE8E401A1728E5D602D369DE155D3FCCD3ACF038A9886E6E0DD93A54', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'max_autotune': True, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': False, 'are_deterministic_algorithms_enabled': False, 'coordinate_descent_tuning': True, 'coordinate_descent_search_radius': 1, 'coordinate_descent_check_all_directions': False, 'tiling_scores': {'x': 65536, 'r0_': 0}}
)
@triton.jit
def triton_per_fused_exp_mul_sub_sum_unsqueeze_13(in_ptr0, in_ptr1, in_ptr2, out_ptr0, xnumel, r0_numel, XBLOCK : tl.constexpr):
    xnumel = 8192
    r0_numel = 32
    R0_BLOCK: tl.constexpr = 32
    rnumel = r0_numel
    RBLOCK: tl.constexpr = R0_BLOCK
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:, None]
    xmask = tl.full([XBLOCK], True, tl.int1)[:, None]
    r0_index = tl.arange(0, R0_BLOCK)[None, :]
    r0_offset = 0
    r0_mask = tl.full([R0_BLOCK], True, tl.int1)[None, :]
    roffset = r0_offset
    rindex = r0_index
    r0_3 = r0_index
    x1 = ((xindex // 256) % 16)
    x2 = xindex // 4096
    x4 = xindex // 256
    x5 = (xindex % 4096)
    x6 = xindex
    tmp0 = tl.load(in_ptr0 + (x1 + 16*r0_3 + 512*x2), None, eviction_policy='evict_last')
    tmp1 = tl.load(in_ptr1 + (x4), None, eviction_policy='evict_last')
    tmp4 = tl.load(in_ptr2 + (x5 + 4096*r0_3 + 131072*x2), None)
    tmp2 = tmp0 - tmp1
    tmp3 = libdevice.exp(tmp2)
    tmp5 = tmp3 * tmp4
    tmp6 = tl.broadcast_to(tmp5, [XBLOCK, R0_BLOCK])
    tmp8 = tl.sum(tmp6, 1)[:, None].to(tl.float32)
    tl.store(out_ptr0 + (x6), tmp8, None)
''', device_str='cuda')


# kernel path: /tmp/infer-opt-models/q35moe-round-profile-20261109/inductor/ix/cixd37f4vk5fotx7ilmlebxvkh2lkpmntucd6lxsiqnti6q3d2vb.py
# Topologically Sorted Source Nodes: [gate_1, unsqueeze_3, out, attn_output, attn_output_1, transpose_3, attn_output_2, reshape_2, sigmoid, attn_output_4, y_2], Original ATen: [aten.split_with_sizes, aten.view, aten.split, aten.unsqueeze, aten.div, aten._to_copy, aten.transpose, aten.clone, aten._unsafe_view, aten.sigmoid, aten.mul]
# Source node to ATen node mapping:
#   attn_output => convert_element_type_20
#   attn_output_1 => view_17
#   attn_output_2 => clone_5
#   attn_output_4 => mul_17
#   gate_1 => clone_4, split_1, split_with_sizes_3, view_5, view_6
#   out => div
#   reshape_2 => view_18
#   sigmoid => sigmoid
#   transpose_3 => permute_4
#   unsqueeze_3 => unsqueeze_6
#   y_2 => triton_kernel_wrapper_mutation_2
# Graph fragment:
#   %sum_2 : Tensor "f32[1, 2, 16, 256][8192, 4096, 256, 1]cuda:0" = PlaceHolder[target=sum_2]
#   %sum_3 : Tensor "f32[1, 2, 16][32, 16, 1]cuda:0" = PlaceHolder[target=sum_3]
#   %buf10 : Tensor  = PlaceHolder[target=buf10]
#   %split_with_sizes_3 : [num_users=1] = call_function[target=torch.ops.aten.split_with_sizes.default](args = (%empty_1, [8192, 512, 512], -1), kwargs = {})
#   %view_5 : Tensor "bf16[1, 2, 16, 512][18432, 9216, 512, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%getitem_13, [1, 2, -1, 512]), kwargs = {})
#   %split_1 : [num_users=1] = call_function[target=torch.ops.aten.split.Tensor](args = (%view_5, 256, -1), kwargs = {})
#   %unsqueeze_6 : Tensor "f32[1, 2, 16, 1][32, 16, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%sum_3, -1), kwargs = {})
#   %div : Tensor "f32[1, 2, 16, 256][8192, 4096, 256, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.div.Tensor](args = (%sum_2, %unsqueeze_6), kwargs = {})
#   %convert_element_type_20 : Tensor "bf16[1, 2, 16, 256][8192, 4096, 256, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%div, torch.bfloat16), kwargs = {})
#   %view_17 : Tensor "bf16[1, 16, 2, 256][8192, 512, 256, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%convert_element_type_20, [1, 16, 2, 256]), kwargs = {})
#   %permute_4 : Tensor "bf16[1, 2, 16, 256][8192, 256, 512, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.permute.default](args = (%view_17, [0, 2, 1, 3]), kwargs = {})
#   %clone_5 : Tensor "bf16[1, 2, 16, 256][8192, 4096, 256, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.clone.default](args = (%permute_4,), kwargs = {memory_format: torch.contiguous_format})
#   %view_18 : Tensor "bf16[1, 2, 4096][8192, 4096, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%clone_5, [1, 2, -1]), kwargs = {})
#   %clone_4 : Tensor "bf16[1, 2, 16, 256][8192, 4096, 256, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.clone.default](args = (%getitem_17,), kwargs = {memory_format: torch.contiguous_format})
#   %view_6 : Tensor "bf16[1, 2, 4096][8192, 4096, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%clone_4, [1, 2, 4096]), kwargs = {})
#   %sigmoid : Tensor "bf16[1, 2, 4096][8192, 4096, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.sigmoid.default](args = (%view_6,), kwargs = {})
#   %mul_17 : Tensor "bf16[1, 2, 4096][8192, 4096, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%view_18, %sigmoid), kwargs = {})
#   %triton_kernel_wrapper_mutation_2 : [num_users=0] = call_function[target=torch.ops.higher_order.triton_kernel_wrapper_mutation](args = (), kwargs = {kernel_idx: 1070, constant_args_idx: 1187, grid: [(32, 4, 1)], tma_descriptor_metadata: {}, kwargs: {x_ptr: %mul_17, q_ptr: %arg16_1, s_ptr: %arg17_1, y_ptr: %empty_5, M: 2, N: 2048, K: 4096, GROUP: 128, BLOCK_M: 16, BLOCK_N: 64, SPLIT: 4}})
#   return %buf37
triton_poi_fused__to_copy__unsafe_view_clone_div_mul_sigmoid_split_split_with_sizes_transpose_unsqueeze_view_14 = async_compile.triton('triton_poi_fused__to_copy__unsafe_view_clone_div_mul_sigmoid_split_split_with_sizes_transpose_unsqueeze_view_14', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.pointwise(
    size_hints={'x': 8192}, 
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*fp32', 'in_ptr1': '*fp32', 'in_ptr2': '*bf16', 'out_ptr0': '*bf16', 'xnumel': 'i32', 'XBLOCK': 'constexpr'}, 'device': DeviceProperties(type='cuda', index=0, multi_processor_count=108, cc=80, major=8, regs_per_multiprocessor=65536, max_threads_per_multi_processor=2048, max_threads_per_block=1024, warp_size=32), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]], (3,): [['tt.divisibility', 16]], (4,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'autotune_hints': set(), 'kernel_name': 'triton_poi_fused__to_copy__unsafe_view_clone_div_mul_sigmoid_split_split_with_sizes_transpose_unsqueeze_view_14', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 3, 'num_store': 1, 'num_reduction': 0, 'backend_hash': 'F7205DDDCE8E401A1728E5D602D369DE155D3FCCD3ACF038A9886E6E0DD93A54', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'max_autotune': True, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': False, 'are_deterministic_algorithms_enabled': False, 'coordinate_descent_tuning': True, 'coordinate_descent_search_radius': 1, 'coordinate_descent_check_all_directions': False, 'tiling_scores': {'x': 65536}},
    min_elem_per_thread=0
)
@triton.jit
def triton_poi_fused__to_copy__unsafe_view_clone_div_mul_sigmoid_split_split_with_sizes_transpose_unsqueeze_view_14(in_ptr0, in_ptr1, in_ptr2, out_ptr0, xnumel, XBLOCK : tl.constexpr):
    xnumel = 8192
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:]
    xmask = tl.full([XBLOCK], True, tl.int1)[:]
    x0 = (xindex % 4096)
    x1 = xindex // 4096
    x2 = xindex
    tmp0 = tl.load(in_ptr0 + (256*x1 + 256*(((x0 % 256)) // 256) + 512*(x0 // 256) + ((x0 % 256))), None)
    tmp1 = tl.load(in_ptr1 + (x1 + 2*(x0 // 256) + (((x0 % 256)) // 256)), None, eviction_policy='evict_last')
    tmp4 = tl.load(in_ptr2 + (256 + 512*(x0 // 256) + 9216*x1 + ((x0 % 256))), None).to(tl.float32)
    tmp2 = (tmp0 / tmp1)
    tmp3 = tmp2.to(tl.float32)
    tmp5 = tl.sigmoid(tmp4)
    tmp6 = tmp3 * tmp5
    tl.store(out_ptr0 + (x2), tmp6, None)
''', device_str='cuda')


# kernel path: /tmp/infer-opt-models/q35moe-round-profile-20261109/inductor/zz/czzr4jjralejnt7gskuibcgqhqg4wyc2ggy4c7fmvkxtixjis3bx.py
# Topologically Sorted Source Nodes: [y, y_2, hidden_states_1, float_12, pow_6, mean_5, add_15, rsqrt_5, output_10, float_13, add_16, output_11, hidden_states_2, x, linear_1], Original ATen: [aten.sum, aten._to_copy, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul, aten.view, aten.mm, aten.t]
# Source node to ATen node mapping:
#   add_15 => add_15
#   add_16 => add_16
#   float_12 => convert_element_type_22
#   float_13 => convert_element_type_23
#   hidden_states_1 => add_14
#   hidden_states_2 => convert_element_type_24
#   linear_1 => convert_element_type_33, convert_element_type_34, mul_21, permute_6, sum_9, unsqueeze_7, unsqueeze_8
#   mean_5 => mean_5
#   output_10 => mul_18
#   output_11 => mul_19
#   pow_6 => pow_6
#   rsqrt_5 => rsqrt_5
#   x => view_19
#   y => convert_element_type_10, sum_1
#   y_2 => convert_element_type_21, sum_4
# Graph fragment:
#   %buf6 : Tensor  = PlaceHolder[target=buf6]
#   %buf38 : Tensor  = PlaceHolder[target=buf38]
#   %add_14 : Tensor "bf16[1, 2, 2048][4096, 2048, 1]cuda:0" = PlaceHolder[target=add_14]
#   %buf40 : Tensor "f32[1, 2, 1][2, 1, 2]cuda:0" = PlaceHolder[target=buf40]
#   %arg18_1 : Tensor "bf16[2048][1]cuda:0" = PlaceHolder[target=arg18_1]
#   %convert_element_type_24 : Tensor "bf16[1, 2, 2048][4096, 2048, 1]cuda:0" = PlaceHolder[target=convert_element_type_24]
#   %arg28_1 : Tensor "bf16[1, 2048][2048, 1]cuda:0" = PlaceHolder[target=arg28_1]
#   %sum_1 : Tensor "f32[1, 2, 2048][4096, 2048, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.sum.dim_IntList](args = (%empty, [0]), kwargs = {})
#   %convert_element_type_10 : Tensor "bf16[1, 2, 2048][4096, 2048, 1]cuda:0"[num_users=2] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%sum_1, torch.bfloat16), kwargs = {})
#   %sum_4 : Tensor "f32[1, 2, 2048][4096, 2048, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.sum.dim_IntList](args = (%empty_5, [0]), kwargs = {})
#   %convert_element_type_21 : Tensor "bf16[1, 2, 2048][4096, 2048, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%sum_4, torch.bfloat16), kwargs = {})
#   %add_14 : Tensor "bf16[1, 2, 2048][4096, 2048, 1]cuda:0"[num_users=2] = call_function[target=torch.ops.aten.add.Tensor](args = (%convert_element_type_10, %convert_element_type_21), kwargs = {})
#   %convert_element_type_22 : Tensor "f32[1, 2, 2048][4096, 2048, 1]cuda:0"[num_users=2] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%add_14, torch.float32), kwargs = {})
#   %pow_6 : Tensor "f32[1, 2, 2048][4096, 2048, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.pow.Tensor_Scalar](args = (%convert_element_type_22, 2), kwargs = {})
#   %mean_5 : Tensor "f32[1, 2, 1][2, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mean.dim](args = (%pow_6, [-1], True), kwargs = {})
#   %add_15 : Tensor "f32[1, 2, 1][2, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%mean_5, 1e-06), kwargs = {})
#   %rsqrt_5 : Tensor "f32[1, 2, 1][2, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.rsqrt.default](args = (%add_15,), kwargs = {})
#   %mul_18 : Tensor "f32[1, 2, 2048][4096, 2048, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%convert_element_type_22, %rsqrt_5), kwargs = {})
#   %convert_element_type_23 : Tensor "f32[2048][1]cuda:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%arg18_1, torch.float32), kwargs = {})
#   %add_16 : Tensor "f32[2048][1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%convert_element_type_23, 1.0), kwargs = {})
#   %mul_19 : Tensor "f32[1, 2, 2048][4096, 2048, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%mul_18, %add_16), kwargs = {})
#   %convert_element_type_24 : Tensor "bf16[1, 2, 2048][4096, 2048, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%mul_19, torch.bfloat16), kwargs = {})
#   %view_19 : Tensor "bf16[2, 2048][2048, 1]cuda:0"[num_users=4] = call_function[target=torch.ops.aten.reshape.default](args = (%convert_element_type_24, [-1, 2048]), kwargs = {})
#   %convert_element_type_33 : Tensor "f32[2, 2048][2048, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%view_19, torch.float32), kwargs = {})
#   %unsqueeze_7 : Tensor "f32[2, 2048, 1][2048, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%convert_element_type_33, 2), kwargs = {})
#   %permute_6 : Tensor "bf16[2048, 1][1, 2048]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.permute.default](args = (%arg28_1, [1, 0]), kwargs = {})
#   %convert_element_type_34 : Tensor "f32[2048, 1][1, 2048]cuda:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%permute_6, torch.float32), kwargs = {})
#   %unsqueeze_8 : Tensor "f32[1, 2048, 1][2048, 1, 2048]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.unsqueeze.default](args = (%convert_element_type_34, 0), kwargs = {})
#   %mul_21 : Tensor "f32[2, 2048, 1][2048, 1, 2048]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%unsqueeze_7, %unsqueeze_8), kwargs = {})
#   %sum_9 : Tensor "f32[2, 1][1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.sum.dim_IntList](args = (%mul_21, [1]), kwargs = {})
#   return %add_14,%buf40,%convert_element_type_24,%sum_9
triton_per_fused__to_copy_add_mean_mm_mul_pow_rsqrt_sum_t_view_15 = async_compile.triton('triton_per_fused__to_copy_add_mean_mm_mul_pow_rsqrt_sum_t_view_15', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.persistent_reduction(
    size_hints={'x': 2, 'r0_': 2048},
    reduction_hint=ReductionHint.INNER,
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*fp32', 'in_ptr1': '*fp32', 'in_ptr2': '*bf16', 'in_ptr3': '*bf16', 'out_ptr0': '*bf16', 'out_ptr2': '*bf16', 'out_ptr3': '*fp32', 'xnumel': 'i32', 'r0_numel': 'i32', 'XBLOCK': 'constexpr'}, 'device': DeviceProperties(type='cuda', index=0, multi_processor_count=108, cc=80, major=8, regs_per_multiprocessor=65536, max_threads_per_multi_processor=2048, max_threads_per_block=1024, warp_size=32), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]], (3,): [['tt.divisibility', 16]], (4,): [['tt.divisibility', 16]], (5,): [['tt.divisibility', 16]], (6,): [['tt.divisibility', 16]], (8,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'autotune_hints': set(), 'kernel_name': 'triton_per_fused__to_copy_add_mean_mm_mul_pow_rsqrt_sum_t_view_15', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': None, 'atomic_add_found': False, 'num_load': 10, 'num_store': 3, 'num_reduction': 2, 'backend_hash': 'F7205DDDCE8E401A1728E5D602D369DE155D3FCCD3ACF038A9886E6E0DD93A54', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'max_autotune': True, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': False, 'are_deterministic_algorithms_enabled': False, 'coordinate_descent_tuning': True, 'coordinate_descent_search_radius': 1, 'coordinate_descent_check_all_directions': False, 'tiling_scores': {'x': 4, 'r0_': 40960}}
)
@triton.jit
def triton_per_fused__to_copy_add_mean_mm_mul_pow_rsqrt_sum_t_view_15(in_ptr0, in_ptr1, in_ptr2, in_ptr3, out_ptr0, out_ptr2, out_ptr3, xnumel, r0_numel, XBLOCK : tl.constexpr):
    xnumel = 2
    r0_numel = 2048
    R0_BLOCK: tl.constexpr = 2048
    rnumel = r0_numel
    RBLOCK: tl.constexpr = R0_BLOCK
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:, None]
    xmask = xindex < xnumel
    r0_index = tl.arange(0, R0_BLOCK)[None, :]
    r0_offset = 0
    r0_mask = tl.full([R0_BLOCK], True, tl.int1)[None, :]
    roffset = r0_offset
    rindex = r0_index
    r0_1 = r0_index
    x0 = xindex
    tmp0 = tl.load(in_ptr0 + (r0_1 + 2048*x0), xmask, other=0.0)
    tmp1 = tl.load(in_ptr0 + (4096 + r0_1 + 2048*x0), xmask, other=0.0)
    tmp3 = tl.load(in_ptr0 + (8192 + r0_1 + 2048*x0), xmask, other=0.0)
    tmp5 = tl.load(in_ptr0 + (12288 + r0_1 + 2048*x0), xmask, other=0.0)
    tmp8 = tl.load(in_ptr1 + (r0_1 + 2048*x0), xmask, other=0.0)
    tmp9 = tl.load(in_ptr1 + (4096 + r0_1 + 2048*x0), xmask, other=0.0)
    tmp11 = tl.load(in_ptr1 + (8192 + r0_1 + 2048*x0), xmask, other=0.0)
    tmp13 = tl.load(in_ptr1 + (12288 + r0_1 + 2048*x0), xmask, other=0.0)
    tmp29 = tl.load(in_ptr2 + (r0_1), None, eviction_policy='evict_last').to(tl.float32)
    tmp36 = tl.load(in_ptr3 + (r0_1), None, eviction_policy='evict_last').to(tl.float32)
    tmp2 = tmp0 + tmp1
    tmp4 = tmp2 + tmp3
    tmp6 = tmp4 + tmp5
    tmp7 = tmp6.to(tl.float32)
    tmp10 = tmp8 + tmp9
    tmp12 = tmp10 + tmp11
    tmp14 = tmp12 + tmp13
    tmp15 = tmp14.to(tl.float32)
    tmp16 = tmp7 + tmp15
    tmp17 = tmp16.to(tl.float32)
    tmp18 = tmp17 * tmp17
    tmp19 = tl.broadcast_to(tmp18, [XBLOCK, R0_BLOCK])
    tmp21 = tl.where(xmask, tmp19, 0)
    tmp22 = tl.sum(tmp21, 1)[:, None].to(tl.float32)
    tmp23 = tl.full([1, 1], 2048.0, tl.float32)
    tmp24 = (tmp22 / tmp23)
    tmp25 = tl.full([1, 1], 1e-06, tl.float32)
    tmp26 = tmp24 + tmp25
    tmp27 = libdevice.rsqrt(tmp26)
    tmp28 = tmp17 * tmp27
    tmp30 = tmp29.to(tl.float32)
    tmp31 = tl.full([1, 1], 1.0, tl.float32)
    tmp32 = tmp30 + tmp31
    tmp33 = tmp28 * tmp32
    tmp34 = tmp33.to(tl.float32)
    tmp35 = tmp34.to(tl.float32)
    tmp37 = tmp36.to(tl.float32)
    tmp38 = tmp35 * tmp37
    tmp39 = tl.broadcast_to(tmp38, [XBLOCK, R0_BLOCK])
    tmp41 = tl.where(xmask, tmp39, 0)
    tmp42 = tl.sum(tmp41, 1)[:, None].to(tl.float32)
    tl.store(out_ptr0 + (r0_1 + 2048*x0), tmp16, xmask)
    tl.store(out_ptr2 + (r0_1 + 2048*x0), tmp34, xmask)
    tl.store(out_ptr3 + (x0), tmp42, xmask)
''', device_str='cuda')


# kernel path: /tmp/infer-opt-models/q35moe-round-profile-20261109/inductor/hr/chrm4yq5uwbdqtyl2zxhkrsk6ysg7ge5y6i6xxkvg7jbpnvkfgp4.py
# Topologically Sorted Source Nodes: [float_12, pow_6, mean_5, add_15, rsqrt_5, output_10, float_13, add_16, output_11, hidden_states_2, x, logits], Original ATen: [aten._to_copy, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.view, aten.t, aten.mm]
# Source node to ATen node mapping:
#   add_15 => add_15
#   add_16 => add_16
#   float_12 => convert_element_type_22
#   float_13 => convert_element_type_23
#   hidden_states_2 => convert_element_type_24
#   logits => mm, permute_5
#   mean_5 => mean_5
#   output_10 => mul_18
#   output_11 => mul_19
#   pow_6 => pow_6
#   rsqrt_5 => rsqrt_5
#   x => view_19
# Graph fragment:
#   %convert_element_type_24 : Tensor "bf16[1, 2, 2048][4096, 2048, 1]cuda:0" = PlaceHolder[target=convert_element_type_24]
#   %arg19_1 : Tensor "bf16[256, 2048][2048, 1]cuda:0" = PlaceHolder[target=arg19_1]
#   %convert_element_type_22 : Tensor "f32[1, 2, 2048][4096, 2048, 1]cuda:0"[num_users=2] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%add_14, torch.float32), kwargs = {})
#   %pow_6 : Tensor "f32[1, 2, 2048][4096, 2048, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.pow.Tensor_Scalar](args = (%convert_element_type_22, 2), kwargs = {})
#   %mean_5 : Tensor "f32[1, 2, 1][2, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mean.dim](args = (%pow_6, [-1], True), kwargs = {})
#   %add_15 : Tensor "f32[1, 2, 1][2, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%mean_5, 1e-06), kwargs = {})
#   %rsqrt_5 : Tensor "f32[1, 2, 1][2, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.rsqrt.default](args = (%add_15,), kwargs = {})
#   %mul_18 : Tensor "f32[1, 2, 2048][4096, 2048, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%convert_element_type_22, %rsqrt_5), kwargs = {})
#   %convert_element_type_23 : Tensor "f32[2048][1]cuda:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%arg18_1, torch.float32), kwargs = {})
#   %add_16 : Tensor "f32[2048][1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%convert_element_type_23, 1.0), kwargs = {})
#   %mul_19 : Tensor "f32[1, 2, 2048][4096, 2048, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%mul_18, %add_16), kwargs = {})
#   %convert_element_type_24 : Tensor "bf16[1, 2, 2048][4096, 2048, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%mul_19, torch.bfloat16), kwargs = {})
#   %view_19 : Tensor "bf16[2, 2048][2048, 1]cuda:0"[num_users=4] = call_function[target=torch.ops.aten.reshape.default](args = (%convert_element_type_24, [-1, 2048]), kwargs = {})
#   %permute_5 : Tensor "bf16[2048, 256][1, 2048]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.permute.default](args = (%arg19_1, [1, 0]), kwargs = {})
#   %mm : Tensor "bf16[2, 256][256, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mm.default](args = (%view_19, %permute_5), kwargs = {})
#   return %mm
triton_tem_fused__to_copy_add_mean_mm_mul_pow_rsqrt_t_view_16 = async_compile.triton('triton_tem_fused__to_copy_add_mean_mm_mul_pow_rsqrt_t_view_16', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties

@triton_heuristics.template(

num_stages=5,
num_warps=4,
triton_meta={'signature': {'arg_A': '*bf16', 'arg_B': '*bf16', 'out_ptr0': '*bf16'}, 'device': DeviceProperties(type='cuda', index=0, multi_processor_count=108, cc=80, major=8, regs_per_multiprocessor=65536, max_threads_per_multi_processor=2048, max_threads_per_block=1024, warp_size=32), 'constants': {}, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]]}]},
inductor_meta={'kernel_name': 'triton_tem_fused__to_copy_add_mean_mm_mul_pow_rsqrt_t_view_16', 'backend_hash': 'F7205DDDCE8E401A1728E5D602D369DE155D3FCCD3ACF038A9886E6E0DD93A54', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'max_autotune': True, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': False, 'are_deterministic_algorithms_enabled': False, 'coordinate_descent_tuning': True, 'coordinate_descent_search_radius': 1, 'coordinate_descent_check_all_directions': False, 'grid_type': 'FixedGrid', 'fixed_grid': ['_grid_0', '_grid_1', '_grid_2'], 'extra_launcher_args': ['_grid_0', '_grid_1', '_grid_2'], 'config_args': {'EVEN_K': True, 'USE_FAST_ACCUM': False, 'ACC_TYPE': 'tl.float32', 'BLOCK_M': 16, 'BLOCK_N': 64, 'BLOCK_K': 128, 'GROUP_M': 8, 'ALLOW_TF32': False}},

)
@triton.jit
def triton_tem_fused__to_copy_add_mean_mm_mul_pow_rsqrt_t_view_16(arg_A, arg_B, out_ptr0):
    EVEN_K : tl.constexpr = True
    USE_FAST_ACCUM : tl.constexpr = False
    ACC_TYPE : tl.constexpr = tl.float32
    BLOCK_M : tl.constexpr = 16
    BLOCK_N : tl.constexpr = 64
    BLOCK_K : tl.constexpr = 128
    GROUP_M : tl.constexpr = 8
    ALLOW_TF32 : tl.constexpr = False
    INDEX_DTYPE : tl.constexpr = tl.int32
    A = arg_A
    B = arg_B

    M = 2
    N = 256
    K = 2048
    if M * N == 0:
        # early exit due to zero-size input(s)
        return
    stride_am = 2048
    stride_ak = 1
    stride_bk = 1
    stride_bn = 2048

    # based on triton.ops.matmul
    pid = tl.program_id(0).to(INDEX_DTYPE)
    grid_m = (M + BLOCK_M - 1) // BLOCK_M
    grid_n = (N + BLOCK_N - 1) // BLOCK_N

    # re-order program ID for better L2 performance
    width = GROUP_M * grid_n
    group_id = pid // width
    group_size = min(grid_m - group_id * GROUP_M, GROUP_M)
    pid_m = group_id * GROUP_M + (pid % group_size)
    pid_n = (pid % width) // (group_size)
    tl.assume(pid_m >= 0)
    tl.assume(pid_n >= 0)

    rm = pid_m * BLOCK_M + tl.arange(0, BLOCK_M)
    rn = pid_n * BLOCK_N + tl.arange(0, BLOCK_N)
    if ((stride_am == 1 and stride_ak == M) or (stride_am == K and stride_ak == 1)) and (M >= BLOCK_M and K > 1):
        offs_a_m = tl.max_contiguous(tl.multiple_of(rm % M, BLOCK_M), BLOCK_M)
    else:
        offs_a_m = rm % M
    if ((stride_bk == 1 and stride_bn == K) or (stride_bk == N and stride_bn == 1)) and (N >= BLOCK_N and K > 1):
        offs_b_n = tl.max_contiguous(tl.multiple_of(rn % N, BLOCK_N), BLOCK_N)
    else:
        offs_b_n = rn % N
    offs_k = tl.arange(0, BLOCK_K)
    acc = tl.zeros((BLOCK_M, BLOCK_N), dtype=ACC_TYPE)

    for k_idx in range(0, tl.cdiv(K, BLOCK_K)):

        a_k_idx_vals = offs_k[None, :] + (k_idx * BLOCK_K)
        b_k_idx_vals = offs_k[:, None] + (k_idx * BLOCK_K)

        idx_m = offs_a_m[:, None]
        idx_n = a_k_idx_vals
        xindex = idx_n + 2048*idx_m
        a = tl.load(A + (xindex))

        idx_m = b_k_idx_vals
        idx_n = offs_b_n[None, :]
        xindex = idx_n + 256*idx_m
        b = tl.load(B + ((tl.broadcast_to(idx_m + 2048*idx_n, [BLOCK_K, BLOCK_N])).broadcast_to(xindex.shape)))


        acc += tl.dot(a, b, allow_tf32=ALLOW_TF32, out_dtype=ACC_TYPE)


    # rematerialize rm and rn to save registers
    rm = pid_m * BLOCK_M + tl.arange(0, BLOCK_M)
    rn = pid_n * BLOCK_N + tl.arange(0, BLOCK_N)
    idx_m = rm[:, None]
    idx_n = rn[None, :]
    mask = (idx_m < M) & (idx_n < N)

    # inductor generates a suffix
    xindex = idx_n + 256*idx_m
    tl.store(out_ptr0 + (tl.broadcast_to(xindex, [BLOCK_M, BLOCK_N])), acc, mask)
''', device_str='cuda')


# kernel path: /tmp/infer-opt-models/q35moe-round-profile-20261109/inductor/nj/cnjfy3tnld54i6oa5g4vhaomvhhqeywuzrlixuqhosegesq6egv4.py
# Topologically Sorted Source Nodes: [probs], Original ATen: [aten._to_copy, prims.prepare_softmax_online, aten.sub, aten.exp, aten._softmax]
# Source node to ATen node mapping:
#   probs => convert_element_type_27, div_1
# Graph fragment:
#   %mm : Tensor "bf16[2, 256][256, 1]cuda:0" = PlaceHolder[target=mm]
#   %getitem_53 : Tensor "f32[2, 1][1, 2]cuda:0" = PlaceHolder[target=getitem_53]
#   %getitem_54 : Tensor "f32[2, 1][1, 2]cuda:0" = PlaceHolder[target=getitem_54]
#   %convert_element_type_27 : Tensor "f32[2, 256][256, 1]cuda:0"[num_users=2] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%mm, torch.float32), kwargs = {})
#   %prepare_softmax_online_default : [num_users=2] = call_function[target=torch.ops.prims.prepare_softmax_online.default](args = (%convert_element_type_27, -1), kwargs = {})
#   %sub_tensor : Tensor "f32[2, 256][256, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.sub.Tensor](args = (%convert_element_type_27, %getitem_53), kwargs = {})
#   %exp_default : Tensor "f32[2, 256][256, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.exp.default](args = (%sub_tensor,), kwargs = {})
#   %div_1 : Tensor "f32[2, 256][256, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.div.Tensor](args = (%exp_default, %getitem_54), kwargs = {})
#   return %getitem_53,%getitem_54,%div_1
triton_per_fused__softmax__to_copy_exp_prepare_softmax_online_sub_17 = async_compile.triton('triton_per_fused__softmax__to_copy_exp_prepare_softmax_online_sub_17', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.persistent_reduction(
    size_hints={'x': 2, 'r0_': 256},
    reduction_hint=ReductionHint.INNER,
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*bf16', 'out_ptr2': '*fp32', 'xnumel': 'i32', 'r0_numel': 'i32', 'XBLOCK': 'constexpr'}, 'device': DeviceProperties(type='cuda', index=0, multi_processor_count=108, cc=80, major=8, regs_per_multiprocessor=65536, max_threads_per_multi_processor=2048, max_threads_per_block=1024, warp_size=32), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (3,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'autotune_hints': set(), 'kernel_name': 'triton_per_fused__softmax__to_copy_exp_prepare_softmax_online_sub_17', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': None, 'atomic_add_found': False, 'num_load': 1, 'num_store': 1, 'num_reduction': 4, 'backend_hash': 'F7205DDDCE8E401A1728E5D602D369DE155D3FCCD3ACF038A9886E6E0DD93A54', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'max_autotune': True, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': False, 'are_deterministic_algorithms_enabled': False, 'coordinate_descent_tuning': True, 'coordinate_descent_search_radius': 1, 'coordinate_descent_check_all_directions': False, 'tiling_scores': {'x': 0, 'r0_': 5120}}
)
@triton.jit
def triton_per_fused__softmax__to_copy_exp_prepare_softmax_online_sub_17(in_ptr0, out_ptr2, xnumel, r0_numel, XBLOCK : tl.constexpr):
    xnumel = 2
    r0_numel = 256
    R0_BLOCK: tl.constexpr = 256
    rnumel = r0_numel
    RBLOCK: tl.constexpr = R0_BLOCK
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:, None]
    xmask = xindex < xnumel
    r0_index = tl.arange(0, R0_BLOCK)[None, :]
    r0_offset = 0
    r0_mask = tl.full([R0_BLOCK], True, tl.int1)[None, :]
    roffset = r0_offset
    rindex = r0_index
    r0_1 = r0_index
    x0 = xindex
    tmp0 = tl.load(in_ptr0 + (r0_1 + 256*x0), xmask, other=0.0).to(tl.float32)
    tmp1 = tmp0.to(tl.float32)
    tmp2 = tl.broadcast_to(tmp1, [XBLOCK, R0_BLOCK])
    tmp4 = tl.broadcast_to(tmp2, [XBLOCK, R0_BLOCK])
    tmp6 = tl.where(xmask, tmp4, float("-inf"))
    tmp7 = triton_helpers.max2(tmp6, 1)[:, None].to(tl.float32)
    tmp8 = tmp2 - tmp7
    tmp9 = libdevice.exp(tmp8)
    tmp10 = tl.broadcast_to(tmp9, [XBLOCK, R0_BLOCK])
    tmp12 = tl.where(xmask, tmp10, 0)
    tmp13 = tl.sum(tmp12, 1)[:, None].to(tl.float32)
    tmp14 = tmp1 - tmp7
    tmp15 = libdevice.exp(tmp14)
    tmp16 = (tmp15 / tmp13)
    tl.store(out_ptr2 + (r0_1 + 256*x0), tmp16, xmask)
''', device_str='cuda')


# Original path: /content/q35moe-round-profile-20261109/infer-opt/infer_opt/quant_kernels.py:176
_w8a16_group_gemv_rows_kernel_3 = async_compile.triton('_w8a16_group_gemv_rows_kernel', '''

import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties

@triton_heuristics.user_autotune(
    configs=[{'num_warps': 8, 'num_stages': 3}],
    inductor_meta={'grid_type': 'FixedGrid', 'fixed_grid': ['_grid_0', '_grid_1', '_grid_2'], 'extra_launcher_args': ['_grid_0', '_grid_1', '_grid_2'], 'kernel_name': '_w8a16_group_gemv_rows_kernel_3', 'backend_hash': 'F7205DDDCE8E401A1728E5D602D369DE155D3FCCD3ACF038A9886E6E0DD93A54', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'max_autotune': True, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': False, 'are_deterministic_algorithms_enabled': False, 'coordinate_descent_tuning': True, 'coordinate_descent_search_radius': 1, 'coordinate_descent_check_all_directions': False},
    triton_meta={'signature': {'x_ptr': '*bf16', 'q_ptr': '*i8', 's_ptr': '*bf16', 'y_ptr': '*fp32', 'M': 'i32', 'N': 'i32', 'K': 'i32', 'GROUP': 'constexpr', 'BLOCK_M': 'constexpr', 'BLOCK_N': 'constexpr', 'SPLIT': 'constexpr'}, 'device': DeviceProperties(type='cuda', index=0, multi_processor_count=108, cc=80, major=8, regs_per_multiprocessor=65536, max_threads_per_multi_processor=2048, max_threads_per_block=1024, warp_size=32), 'constants': {'GROUP': 128, 'BLOCK_M': 16, 'BLOCK_N': 64, 'SPLIT': 4}, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]], (3,): [['tt.divisibility', 16]], (5,): [['tt.divisibility', 16]], (6,): [['tt.divisibility', 16]]}]},
    filename=__file__,
    custom_kernel=True,
)
@triton.jit
def _w8a16_group_gemv_rows_kernel(x_ptr, q_ptr, s_ptr, y_ptr, M, N, K, GROUP: tl.constexpr, BLOCK_M: tl.constexpr,
                                  BLOCK_N: tl.constexpr, SPLIT: tl.constexpr):
    # one group of columns per step: [BLOCK_M, GROUP] x [GROUP, BLOCK_N] on the tensor cores, then the group's scale.
    # With SPLIT > 1 program (pid, s) takes the s-th of SPLIT equal runs of groups and writes fp32 partials [SPLIT, M, N].
    pid = tl.program_id(0)
    split = tl.program_id(1)
    rows = pid * BLOCK_N + tl.arange(0, BLOCK_N)
    row_ok = rows < N
    m = tl.arange(0, BLOCK_M)
    m_ok = m < M
    cols = tl.arange(0, GROUP)
    groups = K // GROUP
    x_ptrs = x_ptr + m[:, None] * K + cols[None, :]
    q_ptrs = q_ptr + rows[:, None].to(tl.int64) * K + cols[None, :]
    s_ptrs = s_ptr + rows * groups
    acc = tl.zeros((BLOCK_M, BLOCK_N), dtype=tl.float32)
    per_split = groups // SPLIT
    for g in range(split * per_split, (split + 1) * per_split):
        x = tl.load(x_ptrs + g * GROUP, mask=m_ok[:, None], other=0.0)
        q = tl.load(q_ptrs + g * GROUP, mask=row_ok[:, None], other=0, eviction_policy="evict_first")
        s = tl.load(s_ptrs + g, mask=row_ok, other=0.0).to(tl.float32)
        acc += tl.dot(x, tl.trans(q.to(x.dtype))) * s[None, :]  # int8 values are exact in fp16/bf16
    y_ptrs = y_ptr + split * M * N + m[:, None] * N + rows[None, :]
    tl.store(y_ptrs, acc.to(y_ptr.dtype.element_ty), mask=m_ok[:, None] & row_ok[None, :])
''', device_str='cuda')


# kernel path: /tmp/infer-opt-models/q35moe-round-profile-20261109/inductor/jm/cjmzqcofjr52c42njyynawbgaca3bijlxvkq4kqthafuvy7dmrba.py
# Topologically Sorted Source Nodes: [y_3, chunk_1, silu, mul_20, y_4], Original ATen: [aten.sum, aten._to_copy, aten.split, aten.silu, aten.mul]
# Source node to ATen node mapping:
#   chunk_1 => split_4
#   mul_20 => mul_20
#   silu => add_17, convert_element_type_30, convert_element_type_31, div_3, exp_2, neg_2
#   y_3 => convert_element_type_29, sum_7
#   y_4 => triton_kernel_wrapper_mutation
# Graph fragment:
#   %buf50 : Tensor  = PlaceHolder[target=buf50]
#   %sum_7 : Tensor "f32[2, 1024][1024, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.sum.dim_IntList](args = (%empty_6, [0]), kwargs = {})
#   %convert_element_type_29 : Tensor "bf16[2, 1024][1024, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%sum_7, torch.bfloat16), kwargs = {})
#   %split_4 : [num_users=2] = call_function[target=torch.ops.aten.split.Tensor](args = (%convert_element_type_29, 512, -1), kwargs = {})
#   %convert_element_type_30 : Tensor "f32[2, 512][512, 1]cuda:0"[num_users=2] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%getitem_50, torch.float32), kwargs = {})
#   %neg_2 : Tensor "f32[2, 512][512, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.neg.default](args = (%convert_element_type_30,), kwargs = {})
#   %exp_2 : Tensor "f32[2, 512][512, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.exp.default](args = (%neg_2,), kwargs = {})
#   %add_17 : Tensor "f32[2, 512][512, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%exp_2, 1), kwargs = {})
#   %div_3 : Tensor "f32[2, 512][512, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.div.Tensor](args = (%convert_element_type_30, %add_17), kwargs = {})
#   %convert_element_type_31 : Tensor "bf16[2, 512][512, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%div_3, torch.bfloat16), kwargs = {})
#   %mul_20 : Tensor "bf16[2, 512][512, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%convert_element_type_31, %getitem_51), kwargs = {})
#   %triton_kernel_wrapper_mutation : [num_users=0] = call_function[target=torch.ops.higher_order.triton_kernel_wrapper_mutation](args = (), kwargs = {kernel_idx: 1072, constant_args_idx: 1189, grid: [(32, 4, 1)], tma_descriptor_metadata: {}, kwargs: {x_ptr: %mul_20, q_ptr: %arg26_1, s_ptr: %arg27_1, y_ptr: %empty_7, M: 2, N: 2048, K: 512, GROUP: 128, BLOCK_M: 16, BLOCK_N: 64, SPLIT: 4}})
#   return %buf52
triton_poi_fused__to_copy_mul_silu_split_sum_18 = async_compile.triton('triton_poi_fused__to_copy_mul_silu_split_sum_18', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.pointwise(
    size_hints={'x': 1024}, 
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*fp32', 'out_ptr0': '*bf16', 'xnumel': 'i32', 'XBLOCK': 'constexpr'}, 'device': DeviceProperties(type='cuda', index=0, multi_processor_count=108, cc=80, major=8, regs_per_multiprocessor=65536, max_threads_per_multi_processor=2048, max_threads_per_block=1024, warp_size=32), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'autotune_hints': set(), 'kernel_name': 'triton_poi_fused__to_copy_mul_silu_split_sum_18', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 8, 'num_store': 1, 'num_reduction': 0, 'backend_hash': 'F7205DDDCE8E401A1728E5D602D369DE155D3FCCD3ACF038A9886E6E0DD93A54', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'max_autotune': True, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': False, 'are_deterministic_algorithms_enabled': False, 'coordinate_descent_tuning': True, 'coordinate_descent_search_radius': 1, 'coordinate_descent_check_all_directions': False, 'tiling_scores': {'x': 4096}},
    min_elem_per_thread=0
)
@triton.jit
def triton_poi_fused__to_copy_mul_silu_split_sum_18(in_ptr0, out_ptr0, xnumel, XBLOCK : tl.constexpr):
    xnumel = 1024
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:]
    xmask = xindex < xnumel
    x0 = (xindex % 512)
    x1 = xindex // 512
    x2 = xindex
    tmp0 = tl.load(in_ptr0 + (x0 + 1024*x1), xmask)
    tmp1 = tl.load(in_ptr0 + (2048 + x0 + 1024*x1), xmask)
    tmp3 = tl.load(in_ptr0 + (4096 + x0 + 1024*x1), xmask)
    tmp5 = tl.load(in_ptr0 + (6144 + x0 + 1024*x1), xmask)
    tmp15 = tl.load(in_ptr0 + (512 + x0 + 1024*x1), xmask)
    tmp16 = tl.load(in_ptr0 + (2560 + x0 + 1024*x1), xmask)
    tmp18 = tl.load(in_ptr0 + (4608 + x0 + 1024*x1), xmask)
    tmp20 = tl.load(in_ptr0 + (6656 + x0 + 1024*x1), xmask)
    tmp2 = tmp0 + tmp1
    tmp4 = tmp2 + tmp3
    tmp6 = tmp4 + tmp5
    tmp7 = tmp6.to(tl.float32)
    tmp8 = tmp7.to(tl.float32)
    tmp9 = -tmp8
    tmp10 = libdevice.exp(tmp9)
    tmp11 = tl.full([1], 1.0, tl.float32)
    tmp12 = tmp10 + tmp11
    tmp13 = (tmp8 / tmp12)
    tmp14 = tmp13.to(tl.float32)
    tmp17 = tmp15 + tmp16
    tmp19 = tmp17 + tmp18
    tmp21 = tmp19 + tmp20
    tmp22 = tmp21.to(tl.float32)
    tmp23 = tmp14 * tmp22
    tl.store(out_ptr0 + (x2), tmp23, xmask)
''', device_str='cuda')


# Original path: /content/q35moe-round-profile-20261109/infer-opt/infer_opt/quant_kernels.py:176
_w8a16_group_gemv_rows_kernel_4 = async_compile.triton('_w8a16_group_gemv_rows_kernel', '''

import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties

@triton_heuristics.user_autotune(
    configs=[{'num_warps': 8, 'num_stages': 3}],
    inductor_meta={'grid_type': 'FixedGrid', 'fixed_grid': ['_grid_0', '_grid_1', '_grid_2'], 'extra_launcher_args': ['_grid_0', '_grid_1', '_grid_2'], 'kernel_name': '_w8a16_group_gemv_rows_kernel_4', 'backend_hash': 'F7205DDDCE8E401A1728E5D602D369DE155D3FCCD3ACF038A9886E6E0DD93A54', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'max_autotune': True, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': False, 'are_deterministic_algorithms_enabled': False, 'coordinate_descent_tuning': True, 'coordinate_descent_search_radius': 1, 'coordinate_descent_check_all_directions': False},
    triton_meta={'signature': {'x_ptr': '*bf16', 'q_ptr': '*i8', 's_ptr': '*bf16', 'y_ptr': '*fp32', 'M': 'i32', 'N': 'i32', 'K': 'i32', 'GROUP': 'constexpr', 'BLOCK_M': 'constexpr', 'BLOCK_N': 'constexpr', 'SPLIT': 'constexpr'}, 'device': DeviceProperties(type='cuda', index=0, multi_processor_count=108, cc=80, major=8, regs_per_multiprocessor=65536, max_threads_per_multi_processor=2048, max_threads_per_block=1024, warp_size=32), 'constants': {'GROUP': 128, 'BLOCK_M': 16, 'BLOCK_N': 64, 'SPLIT': 4}, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]], (3,): [['tt.divisibility', 16]], (5,): [['tt.divisibility', 16]], (6,): [['tt.divisibility', 16]]}]},
    filename=__file__,
    custom_kernel=True,
)
@triton.jit
def _w8a16_group_gemv_rows_kernel(x_ptr, q_ptr, s_ptr, y_ptr, M, N, K, GROUP: tl.constexpr, BLOCK_M: tl.constexpr,
                                  BLOCK_N: tl.constexpr, SPLIT: tl.constexpr):
    # one group of columns per step: [BLOCK_M, GROUP] x [GROUP, BLOCK_N] on the tensor cores, then the group's scale.
    # With SPLIT > 1 program (pid, s) takes the s-th of SPLIT equal runs of groups and writes fp32 partials [SPLIT, M, N].
    pid = tl.program_id(0)
    split = tl.program_id(1)
    rows = pid * BLOCK_N + tl.arange(0, BLOCK_N)
    row_ok = rows < N
    m = tl.arange(0, BLOCK_M)
    m_ok = m < M
    cols = tl.arange(0, GROUP)
    groups = K // GROUP
    x_ptrs = x_ptr + m[:, None] * K + cols[None, :]
    q_ptrs = q_ptr + rows[:, None].to(tl.int64) * K + cols[None, :]
    s_ptrs = s_ptr + rows * groups
    acc = tl.zeros((BLOCK_M, BLOCK_N), dtype=tl.float32)
    per_split = groups // SPLIT
    for g in range(split * per_split, (split + 1) * per_split):
        x = tl.load(x_ptrs + g * GROUP, mask=m_ok[:, None], other=0.0)
        q = tl.load(q_ptrs + g * GROUP, mask=row_ok[:, None], other=0, eviction_policy="evict_first")
        s = tl.load(s_ptrs + g, mask=row_ok, other=0.0).to(tl.float32)
        acc += tl.dot(x, tl.trans(q.to(x.dtype))) * s[None, :]  # int8 values are exact in fp16/bf16
    y_ptrs = y_ptr + split * M * N + m[:, None] * N + rows[None, :]
    tl.store(y_ptrs, acc.to(y_ptr.dtype.element_ty), mask=m_ok[:, None] & row_ok[None, :])
''', device_str='cuda')


# kernel path: /tmp/infer-opt-models/q35moe-round-profile-20261109/inductor/ke/ckebkyuc6fnpzoq2e5jiwon6v4652zpwx56465qpoeohlusi3ann.py
# Topologically Sorted Source Nodes: [float_12, pow_6, mean_5, add_15, rsqrt_5, output_10, float_13, add_16, output_11, hidden_states_2, x, sum_3, truediv_1, weights_1, routed], Original ATen: [aten._to_copy, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.view, aten.sum, aten.div, infer_opt.selected_int8_experts]
# Source node to ATen node mapping:
#   add_15 => add_15
#   add_16 => add_16
#   float_12 => convert_element_type_22
#   float_13 => convert_element_type_23
#   hidden_states_2 => convert_element_type_24
#   mean_5 => mean_5
#   output_10 => mul_18
#   output_11 => mul_19
#   pow_6 => pow_6
#   routed => selected_int8_experts
#   rsqrt_5 => rsqrt_5
#   sum_3 => sum_6
#   truediv_1 => div_2
#   weights_1 => convert_element_type_28
#   x => view_19
# Graph fragment:
#   %getitem_47 : Tensor "f32[2, 8][8, 1]cuda:0" = PlaceHolder[target=getitem_47]
#   %sum_6 : Tensor "f32[2, 1][1, 2]cuda:0" = PlaceHolder[target=sum_6]
#   %convert_element_type_22 : Tensor "f32[1, 2, 2048][4096, 2048, 1]cuda:0"[num_users=2] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%add_14, torch.float32), kwargs = {})
#   %pow_6 : Tensor "f32[1, 2, 2048][4096, 2048, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.pow.Tensor_Scalar](args = (%convert_element_type_22, 2), kwargs = {})
#   %mean_5 : Tensor "f32[1, 2, 1][2, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mean.dim](args = (%pow_6, [-1], True), kwargs = {})
#   %add_15 : Tensor "f32[1, 2, 1][2, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%mean_5, 1e-06), kwargs = {})
#   %rsqrt_5 : Tensor "f32[1, 2, 1][2, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.rsqrt.default](args = (%add_15,), kwargs = {})
#   %mul_18 : Tensor "f32[1, 2, 2048][4096, 2048, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%convert_element_type_22, %rsqrt_5), kwargs = {})
#   %convert_element_type_23 : Tensor "f32[2048][1]cuda:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%arg18_1, torch.float32), kwargs = {})
#   %add_16 : Tensor "f32[2048][1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%convert_element_type_23, 1.0), kwargs = {})
#   %mul_19 : Tensor "f32[1, 2, 2048][4096, 2048, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%mul_18, %add_16), kwargs = {})
#   %convert_element_type_24 : Tensor "bf16[1, 2, 2048][4096, 2048, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%mul_19, torch.bfloat16), kwargs = {})
#   %view_19 : Tensor "bf16[2, 2048][2048, 1]cuda:0"[num_users=4] = call_function[target=torch.ops.aten.reshape.default](args = (%convert_element_type_24, [-1, 2048]), kwargs = {})
#   %sum_6 : Tensor "f32[2, 1][1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.sum.dim_IntList](args = (%getitem_47, [-1], True), kwargs = {})
#   %div_2 : Tensor "f32[2, 8][8, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.div.Tensor](args = (%getitem_47, %sum_6), kwargs = {})
#   %convert_element_type_28 : Tensor "bf16[2, 8][8, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%div_2, torch.bfloat16), kwargs = {})
#   %selected_int8_experts : Tensor "bf16[2, 2048][2048, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.infer_opt.selected_int8_experts.default](args = (%view_19, %getitem_48, %convert_element_type_28, %arg20_1, %arg21_1, %arg22_1, %arg23_1), kwargs = {})
#   return %sum_6,%buf55
triton_per_fused__to_copy_add_div_mean_mul_pow_rsqrt_selected_int8_experts_sum_view_19 = async_compile.triton('triton_per_fused__to_copy_add_div_mean_mul_pow_rsqrt_selected_int8_experts_sum_view_19', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.persistent_reduction(
    size_hints={'x': 2, 'r0_': 8},
    reduction_hint=ReductionHint.INNER,
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*fp32', 'out_ptr1': '*bf16', 'xnumel': 'i32', 'r0_numel': 'i32', 'XBLOCK': 'constexpr'}, 'device': DeviceProperties(type='cuda', index=0, multi_processor_count=108, cc=80, major=8, regs_per_multiprocessor=65536, max_threads_per_multi_processor=2048, max_threads_per_block=1024, warp_size=32), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'autotune_hints': set(), 'kernel_name': 'triton_per_fused__to_copy_add_div_mean_mul_pow_rsqrt_selected_int8_experts_sum_view_19', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': None, 'atomic_add_found': False, 'num_load': 1, 'num_store': 1, 'num_reduction': 1, 'backend_hash': 'F7205DDDCE8E401A1728E5D602D369DE155D3FCCD3ACF038A9886E6E0DD93A54', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'max_autotune': True, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': False, 'are_deterministic_algorithms_enabled': False, 'coordinate_descent_tuning': True, 'coordinate_descent_search_radius': 1, 'coordinate_descent_check_all_directions': False, 'tiling_scores': {'x': 0, 'r0_': 128}}
)
@triton.jit
def triton_per_fused__to_copy_add_div_mean_mul_pow_rsqrt_selected_int8_experts_sum_view_19(in_ptr0, out_ptr1, xnumel, r0_numel, XBLOCK : tl.constexpr):
    xnumel = 2
    r0_numel = 8
    R0_BLOCK: tl.constexpr = 8
    rnumel = r0_numel
    RBLOCK: tl.constexpr = R0_BLOCK
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:, None]
    xmask = xindex < xnumel
    r0_index = tl.arange(0, R0_BLOCK)[None, :]
    r0_offset = 0
    r0_mask = tl.full([R0_BLOCK], True, tl.int1)[None, :]
    roffset = r0_offset
    rindex = r0_index
    r0_1 = r0_index
    x0 = xindex
    tmp0 = tl.load(in_ptr0 + (r0_1 + 8*x0), xmask, other=0.0)
    tmp1 = tl.broadcast_to(tmp0, [XBLOCK, R0_BLOCK])
    tmp3 = tl.where(xmask, tmp1, 0)
    tmp4 = tl.sum(tmp3, 1)[:, None].to(tl.float32)
    tmp5 = (tmp0 / tmp4)
    tmp6 = tmp5.to(tl.float32)
    tl.store(out_ptr1 + (r0_1 + 8*x0), tmp6, xmask)
''', device_str='cuda')


# kernel path: /tmp/infer-opt-models/q35moe-round-profile-20261109/inductor/uw/cuwb36cjo7vtmnyis4mda2n5bcj3pf7kccqtg6egvyfaghzaug7e.py
# Topologically Sorted Source Nodes: [y_4, linear_1, sigmoid_1, shared, add_17, hidden_states_3, add_18, float_14, pow_7, mean_6], Original ATen: [aten.sum, aten._to_copy, aten.mm, aten.sigmoid, aten.mul, aten.add, aten.view, aten.pow, aten.mean]
# Source node to ATen node mapping:
#   add_17 => add_18
#   add_18 => add_19
#   float_14 => convert_element_type_36
#   hidden_states_3 => view_20
#   linear_1 => convert_element_type_35
#   mean_6 => mean_6
#   pow_7 => pow_7
#   shared => mul_22
#   sigmoid_1 => sigmoid_1
#   y_4 => convert_element_type_32, sum_8
# Graph fragment:
#   %add_14 : Tensor "bf16[1, 2, 2048][4096, 2048, 1]cuda:0" = PlaceHolder[target=add_14]
#   %selected_int8_experts : Tensor "bf16[2, 2048][2048, 1]cuda:0" = PlaceHolder[target=selected_int8_experts]
#   %buf53 : Tensor  = PlaceHolder[target=buf53]
#   %sum_9 : Tensor "f32[2, 1][1, 2]cuda:0" = PlaceHolder[target=sum_9]
#   %convert_element_type_36 : Tensor "f32[1, 2, 2048][4096, 2048, 1]cuda:0" = PlaceHolder[target=convert_element_type_36]
#   %sum_8 : Tensor "f32[2, 2048][2048, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.sum.dim_IntList](args = (%empty_7, [0]), kwargs = {})
#   %convert_element_type_32 : Tensor "bf16[2, 2048][2048, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%sum_8, torch.bfloat16), kwargs = {})
#   %convert_element_type_35 : Tensor "bf16[2, 1][1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%sum_9, torch.bfloat16), kwargs = {})
#   %sigmoid_1 : Tensor "bf16[2, 1][1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.sigmoid.default](args = (%convert_element_type_35,), kwargs = {})
#   %mul_22 : Tensor "bf16[2, 2048][2048, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%convert_element_type_32, %sigmoid_1), kwargs = {})
#   %add_18 : Tensor "bf16[2, 2048][2048, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%selected_int8_experts, %mul_22), kwargs = {})
#   %view_20 : Tensor "bf16[1, 2, 2048][4096, 2048, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.reshape.default](args = (%add_18, [1, 2, 2048]), kwargs = {})
#   %add_19 : Tensor "bf16[1, 2, 2048][4096, 2048, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%add_14, %view_20), kwargs = {})
#   %convert_element_type_36 : Tensor "f32[1, 2, 2048][4096, 2048, 1]cuda:0"[num_users=2] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%add_19, torch.float32), kwargs = {})
#   %pow_7 : Tensor "f32[1, 2, 2048][4096, 2048, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.pow.Tensor_Scalar](args = (%convert_element_type_36, 2), kwargs = {})
#   %mean_6 : Tensor "f32[1, 2, 1][2, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mean.dim](args = (%pow_7, [-1], True), kwargs = {})
#   return %convert_element_type_36,%buf60
triton_per_fused__to_copy_add_mean_mm_mul_pow_sigmoid_sum_view_20 = async_compile.triton('triton_per_fused__to_copy_add_mean_mm_mul_pow_sigmoid_sum_view_20', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.persistent_reduction(
    size_hints={'x': 2, 'r0_': 2048},
    reduction_hint=ReductionHint.INNER,
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*bf16', 'in_ptr1': '*bf16', 'in_ptr2': '*fp32', 'in_ptr3': '*fp32', 'out_ptr0': '*fp32', 'out_ptr1': '*fp32', 'xnumel': 'i32', 'r0_numel': 'i32', 'XBLOCK': 'constexpr'}, 'device': DeviceProperties(type='cuda', index=0, multi_processor_count=108, cc=80, major=8, regs_per_multiprocessor=65536, max_threads_per_multi_processor=2048, max_threads_per_block=1024, warp_size=32), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]], (3,): [['tt.divisibility', 16]], (4,): [['tt.divisibility', 16]], (5,): [['tt.divisibility', 16]], (7,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'autotune_hints': set(), 'kernel_name': 'triton_per_fused__to_copy_add_mean_mm_mul_pow_sigmoid_sum_view_20', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': None, 'atomic_add_found': False, 'num_load': 7, 'num_store': 2, 'num_reduction': 1, 'backend_hash': 'F7205DDDCE8E401A1728E5D602D369DE155D3FCCD3ACF038A9886E6E0DD93A54', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'max_autotune': True, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': False, 'are_deterministic_algorithms_enabled': False, 'coordinate_descent_tuning': True, 'coordinate_descent_search_radius': 1, 'coordinate_descent_check_all_directions': False, 'tiling_scores': {'x': 6, 'r0_': 49152}}
)
@triton.jit
def triton_per_fused__to_copy_add_mean_mm_mul_pow_sigmoid_sum_view_20(in_ptr0, in_ptr1, in_ptr2, in_ptr3, out_ptr0, out_ptr1, xnumel, r0_numel, XBLOCK : tl.constexpr):
    xnumel = 2
    r0_numel = 2048
    R0_BLOCK: tl.constexpr = 2048
    rnumel = r0_numel
    RBLOCK: tl.constexpr = R0_BLOCK
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:, None]
    xmask = xindex < xnumel
    r0_index = tl.arange(0, R0_BLOCK)[None, :]
    r0_offset = 0
    r0_mask = tl.full([R0_BLOCK], True, tl.int1)[None, :]
    roffset = r0_offset
    rindex = r0_index
    r0_1 = r0_index
    x0 = xindex
    tmp0 = tl.load(in_ptr0 + (r0_1 + 2048*x0), xmask, other=0.0).to(tl.float32)
    tmp1 = tl.load(in_ptr1 + (r0_1 + 2048*x0), xmask, other=0.0).to(tl.float32)
    tmp2 = tl.load(in_ptr2 + (r0_1 + 2048*x0), xmask, other=0.0)
    tmp3 = tl.load(in_ptr2 + (4096 + r0_1 + 2048*x0), xmask, other=0.0)
    tmp5 = tl.load(in_ptr2 + (8192 + r0_1 + 2048*x0), xmask, other=0.0)
    tmp7 = tl.load(in_ptr2 + (12288 + r0_1 + 2048*x0), xmask, other=0.0)
    tmp10 = tl.load(in_ptr3 + (x0), xmask, eviction_policy='evict_last')
    tmp4 = tmp2 + tmp3
    tmp6 = tmp4 + tmp5
    tmp8 = tmp6 + tmp7
    tmp9 = tmp8.to(tl.float32)
    tmp11 = tmp10.to(tl.float32)
    tmp12 = tl.sigmoid(tmp11)
    tmp13 = tmp9 * tmp12
    tmp14 = tmp1 + tmp13
    tmp15 = tmp0 + tmp14
    tmp16 = tmp15.to(tl.float32)
    tmp17 = tmp16 * tmp16
    tmp18 = tl.broadcast_to(tmp17, [XBLOCK, R0_BLOCK])
    tmp20 = tl.where(xmask, tmp18, 0)
    tmp21 = tl.sum(tmp20, 1)[:, None].to(tl.float32)
    tl.store(out_ptr0 + (r0_1 + 2048*x0), tmp16, xmask)
    tl.store(out_ptr1 + (x0), tmp21, xmask)
''', device_str='cuda')


# kernel path: /tmp/infer-opt-models/q35moe-round-profile-20261109/inductor/rj/crj3ejzxwsqkagakrt7dhvax4scgfks2cwnwr2cnlo7cqomvlosq.py
# Topologically Sorted Source Nodes: [last], Original ATen: [aten.sub]
# Source node to ATen node mapping:
#   last => sub_2
# Graph fragment:
#   %arg30_1 : Tensor "i64[1][1]cuda:0" = PlaceHolder[target=arg30_1]
#   %sub_2 : Tensor "i64[1][1]cuda:0"[num_users=2] = call_function[target=torch.ops.aten.sub.Tensor](args = (%arg30_1, 1), kwargs = {})
#   return %sub_2
triton_poi_fused_sub_21 = async_compile.triton('triton_poi_fused_sub_21', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.pointwise(
    size_hints={'x': 1}, 
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*i64', 'out_ptr0': '*i64', 'xnumel': 'constexpr', 'XBLOCK': 'constexpr'}, 'device': DeviceProperties(type='cuda', index=0, multi_processor_count=108, cc=80, major=8, regs_per_multiprocessor=65536, max_threads_per_multi_processor=2048, max_threads_per_block=1024, warp_size=32), 'constants': {'xnumel': 1}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'autotune_hints': set(), 'kernel_name': 'triton_poi_fused_sub_21', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 1, 'num_store': 1, 'num_reduction': 0, 'backend_hash': 'F7205DDDCE8E401A1728E5D602D369DE155D3FCCD3ACF038A9886E6E0DD93A54', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'max_autotune': True, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': False, 'are_deterministic_algorithms_enabled': False, 'coordinate_descent_tuning': True, 'coordinate_descent_search_radius': 1, 'coordinate_descent_check_all_directions': False},
    min_elem_per_thread=0
)
@triton.jit
def triton_poi_fused_sub_21(in_ptr0, out_ptr0, xnumel, XBLOCK : tl.constexpr):
    xnumel = 1
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:]
    xmask = tl.full([XBLOCK], True, tl.int1)[:]
    tmp0 = tl.load(in_ptr0 + (0))
    tmp1 = tl.broadcast_to(tmp0, [XBLOCK])
    tmp2 = tl.full([1], 1, tl.int64)
    tmp3 = tmp1 - tmp2
    tl.store(out_ptr0 + (tl.full([XBLOCK], 0, tl.int32).broadcast_to(XBLOCK)), tmp3, None)
''', device_str='cuda')


# kernel path: /tmp/infer-opt-models/q35moe-round-profile-20261109/inductor/sv/csvyp3pdib7tv7pgaceglbp6ukgcueo6mp7ukdy75aahryf7rpxf.py
# Topologically Sorted Source Nodes: [pow_7, mean_6, add_19, rsqrt_6, output_12, float_15, add_20, output_13, out_1, index_select], Original ATen: [aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten._to_copy, aten.index_select]
# Source node to ATen node mapping:
#   add_19 => add_20
#   add_20 => add_21
#   float_15 => convert_element_type_37
#   index_select => index
#   mean_6 => mean_6
#   out_1 => convert_element_type_38
#   output_12 => mul_23
#   output_13 => mul_24
#   pow_7 => pow_7
#   rsqrt_6 => rsqrt_6
# Graph fragment:
#   %sub_2 : Tensor "i64[1][1]cuda:0" = PlaceHolder[target=sub_2]
#   %convert_element_type_36 : Tensor "f32[1, 2, 2048][4096, 2048, 1]cuda:0" = PlaceHolder[target=convert_element_type_36]
#   %buf60 : Tensor "f32[1, 2, 1][2, 1, 2]cuda:0" = PlaceHolder[target=buf60]
#   %arg29_1 : Tensor "bf16[2048][1]cuda:0" = PlaceHolder[target=arg29_1]
#   %pow_7 : Tensor "f32[1, 2, 2048][4096, 2048, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.pow.Tensor_Scalar](args = (%convert_element_type_36, 2), kwargs = {})
#   %mean_6 : Tensor "f32[1, 2, 1][2, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mean.dim](args = (%pow_7, [-1], True), kwargs = {})
#   %add_20 : Tensor "f32[1, 2, 1][2, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%mean_6, 1e-06), kwargs = {})
#   %rsqrt_6 : Tensor "f32[1, 2, 1][2, 1, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.rsqrt.default](args = (%add_20,), kwargs = {})
#   %mul_23 : Tensor "f32[1, 2, 2048][4096, 2048, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%convert_element_type_36, %rsqrt_6), kwargs = {})
#   %convert_element_type_37 : Tensor "f32[2048][1]cuda:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%arg29_1, torch.float32), kwargs = {})
#   %add_21 : Tensor "f32[2048][1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%convert_element_type_37, 1.0), kwargs = {})
#   %mul_24 : Tensor "f32[1, 2, 2048][4096, 2048, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.mul.Tensor](args = (%mul_23, %add_21), kwargs = {})
#   %convert_element_type_38 : Tensor "bf16[1, 2, 2048][4096, 2048, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%mul_24, torch.bfloat16), kwargs = {})
#   %index : Tensor "bf16[1, 1, 2048][2048, 2048, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.index.Tensor](args = (%convert_element_type_38, [None, %sub_2]), kwargs = {})
#   return %index
triton_poi_fused__to_copy_add_index_select_mean_mul_pow_rsqrt_22 = async_compile.triton('triton_poi_fused__to_copy_add_index_select_mean_mul_pow_rsqrt_22', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.pointwise(
    size_hints={'x': 2048}, 
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*i64', 'in_ptr1': '*fp32', 'in_ptr2': '*fp32', 'in_ptr3': '*bf16', 'out_ptr0': '*bf16', 'xnumel': 'i32', 'XBLOCK': 'constexpr'}, 'device': DeviceProperties(type='cuda', index=0, multi_processor_count=108, cc=80, major=8, regs_per_multiprocessor=65536, max_threads_per_multi_processor=2048, max_threads_per_block=1024, warp_size=32), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]], (3,): [['tt.divisibility', 16]], (4,): [['tt.divisibility', 16]], (5,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'autotune_hints': set(), 'kernel_name': 'triton_poi_fused__to_copy_add_index_select_mean_mul_pow_rsqrt_22', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 2, 'num_store': 1, 'num_reduction': 0, 'backend_hash': 'F7205DDDCE8E401A1728E5D602D369DE155D3FCCD3ACF038A9886E6E0DD93A54', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'max_autotune': True, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': False, 'are_deterministic_algorithms_enabled': False, 'coordinate_descent_tuning': True, 'coordinate_descent_search_radius': 1, 'coordinate_descent_check_all_directions': False, 'tiling_scores': {'x': 12288}},
    min_elem_per_thread=0
)
@triton.jit
def triton_poi_fused__to_copy_add_index_select_mean_mul_pow_rsqrt_22(in_ptr0, in_ptr1, in_ptr2, in_ptr3, out_ptr0, xnumel, XBLOCK : tl.constexpr):
    xnumel = 2048
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:]
    xmask = xindex < xnumel
    x0 = xindex
    tmp0 = tl.load(in_ptr0 + (0))
    tmp1 = tl.broadcast_to(tmp0, [XBLOCK])
    tmp15 = tl.load(in_ptr3 + (x0), xmask).to(tl.float32)
    tmp2 = tl.full([XBLOCK], 2, tl.int32)
    tmp3 = tmp1 + tmp2
    tmp4 = tmp1 < 0
    tmp5 = tl.where(tmp4, tmp3, tmp1)
    tl.device_assert((0 <= tmp5) & (tmp5 < 2), "index out of bounds: 0 <= tmp5 < 2")
    tmp7 = tl.load(in_ptr1 + (x0 + 2048*tmp5), xmask)
    tmp8 = tl.load(in_ptr2 + (tmp5), None, eviction_policy='evict_last')
    tmp9 = tl.full([1], 2048.0, tl.float32)
    tmp10 = (tmp8 / tmp9)
    tmp11 = tl.full([1], 1e-06, tl.float32)
    tmp12 = tmp10 + tmp11
    tmp13 = libdevice.rsqrt(tmp12)
    tmp14 = tmp7 * tmp13
    tmp16 = tmp15.to(tl.float32)
    tmp17 = tl.full([1], 1.0, tl.float32)
    tmp18 = tmp16 + tmp17
    tmp19 = tmp14 * tmp18
    tmp20 = tmp19.to(tl.float32)
    tl.store(out_ptr0 + (x0), tmp20, xmask)
''', device_str='cuda')


# kernel path: /tmp/infer-opt-models/q35moe-round-profile-20261109/inductor/uq/cuqig655hjqhq7rlitbda5tyzkyj5qo7xn3yd6zfx2k2zl2tzbrb.py
# Topologically Sorted Source Nodes: [add_], Original ATen: [aten.add, aten.copy_]
# Source node to ATen node mapping:
#   add_ => add_22
# Graph fragment:
#   %copy_ : Tensor "i64[1][1]cuda:0" = PlaceHolder[target=copy_]
#   %arg30_1 : Tensor "i64[1][1]cuda:0" = PlaceHolder[target=arg30_1]
#   %add_22 : Tensor "i64[1][1]cuda:0" = PlaceHolder[target=add_22]
#   %slice_scatter_default_2 : Tensor "f32[1, 2, 32][64, 32, 1]cuda:0" = PlaceHolder[target=slice_scatter_default_2]
#   %mul_11 : Tensor "bf16[1, 16, 2, 64][2048, 64, 1024, 1]cuda:0" = PlaceHolder[target=mul_11]
#   %slice_scatter_default_3 : Tensor "f32[1, 2, 32][64, 32, 1]cuda:0" = PlaceHolder[target=slice_scatter_default_3]
#   %add_11 : Tensor "bf16[1, 16, 2, 64][8192, 512, 256, 1]cuda:0" = PlaceHolder[target=add_11]
#   %mul_13 : Tensor "bf16[1, 2, 2, 64][256, 64, 128, 1]cuda:0" = PlaceHolder[target=mul_13]
#   %add_12 : Tensor "bf16[1, 2, 2, 64][1024, 512, 256, 1]cuda:0" = PlaceHolder[target=add_12]
#   %buf25 : Tensor "bf16[1, 2, 2048, 256][1048576, 524288, 256, 1]cuda:0" = PlaceHolder[target=buf25]
#   %buf26 : Tensor "bf16[1, 2, 2048, 256][1048576, 524288, 256, 1]cuda:0" = PlaceHolder[target=buf26]
#   %buf30 : Tensor  = PlaceHolder[target=buf30]
#   %buf31 : Tensor  = PlaceHolder[target=buf31]
#   %buf32 : Tensor  = PlaceHolder[target=buf32]
#   %add_22 : Tensor "i64[1][1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%arg2_1, %arg30_1), kwargs = {})
#   %copy_ : Tensor "i64[1][1]cuda:0"[num_users=0] = call_function[target=torch.ops.aten.copy_.default](args = (%arg2_1, %add_22), kwargs = {})
#   return %add_22,%buf82
triton_poi_fused_add_copy__23 = async_compile.triton('triton_poi_fused_add_copy__23', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.pointwise(
    size_hints={'x': 1}, 
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*i64', 'in_ptr1': '*i64', 'out_ptr1': '*i64', 'xnumel': 'constexpr', 'XBLOCK': 'constexpr'}, 'device': DeviceProperties(type='cuda', index=0, multi_processor_count=108, cc=80, major=8, regs_per_multiprocessor=65536, max_threads_per_multi_processor=2048, max_threads_per_block=1024, warp_size=32), 'constants': {'xnumel': 1}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'autotune_hints': set(), 'kernel_name': 'triton_poi_fused_add_copy__23', 'mutated_arg_names': ['in_ptr0', 'out_ptr1'], 'optimize_mem': True, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 2, 'num_store': 1, 'num_reduction': 0, 'backend_hash': 'F7205DDDCE8E401A1728E5D602D369DE155D3FCCD3ACF038A9886E6E0DD93A54', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'max_autotune': True, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': False, 'are_deterministic_algorithms_enabled': False, 'coordinate_descent_tuning': True, 'coordinate_descent_search_radius': 1, 'coordinate_descent_check_all_directions': False},
    min_elem_per_thread=0
)
@triton.jit
def triton_poi_fused_add_copy__23(in_ptr0, in_ptr1, out_ptr1, xnumel, XBLOCK : tl.constexpr):
    xnumel = 1
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:]
    xmask = tl.full([XBLOCK], True, tl.int1)[:]
    tmp0 = tl.load(in_ptr0 + (0))
    tmp1 = tl.broadcast_to(tmp0, [XBLOCK])
    tmp2 = tl.load(in_ptr1 + (0))
    tmp3 = tl.broadcast_to(tmp2, [XBLOCK])
    tmp4 = tmp1 + tmp3
    tl.store(out_ptr1 + (tl.full([XBLOCK], 0, tl.int32).broadcast_to(XBLOCK)), tmp4, None)
''', device_str='cuda')


async_compile.wait(globals())
del async_compile

class Runner:
    def __init__(self, partitions):
        self.partitions = partitions

    def recursively_apply_fns(self, fns):
        new_callables = []
        for fn, c in zip(fns, self.partitions):
            new_callables.append(fn(c))
        self.partitions = new_callables

    def call(self, args):
        arg0_1, arg1_1, arg2_1, arg3_1, arg4_1, arg5_1, arg6_1, arg7_1, arg8_1, arg9_1, arg10_1, arg11_1, arg12_1, arg13_1, arg14_1, arg15_1, arg16_1, arg17_1, arg18_1, arg19_1, arg20_1, arg21_1, arg22_1, arg23_1, arg24_1, arg25_1, arg26_1, arg27_1, arg28_1, arg29_1, arg30_1 = args
        args.clear()
        assert_size_stride(arg0_1, (248320, 2048), (2048, 1))
        assert_size_stride(arg1_1, (1, 2), (2, 1))
        assert_size_stride(arg2_1, (1, ), (1, ))
        assert_size_stride(arg3_1, (32, ), (1, ))
        assert_size_stride(arg4_1, (2048, ), (1, ))
        assert_size_stride(arg5_1, (1, 2, 2048), (4096, 2048, 1))
        assert_size_stride(arg6_1, (2048, ), (1, ))
        assert_size_stride(arg7_1, (2048, 4096), (4096, 1))
        assert_size_stride(arg8_1, (2048, 32), (32, 1))
        assert_size_stride(arg9_1, (2048, ), (1, ))
        assert_size_stride(arg10_1, (9216, 2048), (2048, 1))
        assert_size_stride(arg11_1, (9216, 16), (16, 1))
        assert_size_stride(arg12_1, (256, ), (1, ))
        assert_size_stride(arg13_1, (256, ), (1, ))
        assert_size_stride(arg14_1, (1, 2, 2048, 256), (1048576, 524288, 256, 1))
        assert_size_stride(arg15_1, (1, 2, 2048, 256), (1048576, 524288, 256, 1))
        assert_size_stride(arg16_1, (2048, 4096), (4096, 1))
        assert_size_stride(arg17_1, (2048, 32), (32, 1))
        assert_size_stride(arg18_1, (2048, ), (1, ))
        assert_size_stride(arg19_1, (256, 2048), (2048, 1))
        assert_size_stride(arg20_1, (256, 1024, 2048), (2097152, 2048, 1))
        assert_size_stride(arg21_1, (256, 1024, 16), (16384, 16, 1))
        assert_size_stride(arg22_1, (256, 2048, 512), (1048576, 512, 1))
        assert_size_stride(arg23_1, (256, 2048, 4), (8192, 4, 1))
        assert_size_stride(arg24_1, (1024, 2048), (2048, 1))
        assert_size_stride(arg25_1, (1024, 16), (16, 1))
        assert_size_stride(arg26_1, (2048, 512), (512, 1))
        assert_size_stride(arg27_1, (2048, 4), (4, 1))
        assert_size_stride(arg28_1, (1, 2048), (2048, 1))
        assert_size_stride(arg29_1, (2048, ), (1, ))
        assert_size_stride(arg30_1, (1, ), (1, ))
        with torch.cuda._DeviceGuard(0):
            torch.cuda.set_device(0)
            buf4 = empty_strided_cuda((1, 2, 4096), (8192, 4096, 1), torch.bfloat16)
            buf2 = reinterpret_tensor(buf4, (1, 2, 2048), (8192, 4096, 1), 0)  # alias
            # Topologically Sorted Source Nodes: [embeds, float_2, pow_1, mean, add_1, rsqrt, output, float_3, add_2, output_1, type_as], Original ATen: [aten.embedding, aten._to_copy, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul]
            stream0 = get_raw_stream(0)
            triton_red_fused__to_copy_add_embedding_mean_mul_pow_rsqrt_0.run(arg1_1, arg0_1, arg4_1, buf2, 2, 2048, stream=stream0)
            del arg0_1
            del arg1_1
            del arg4_1
            buf3 = reinterpret_tensor(buf4, (1, 2, 2048), (8192, 4096, 1), 2048)  # alias
            # Topologically Sorted Source Nodes: [float_4, pow_2, mean_1, add_3, rsqrt_1, output_2, float_5, add_4, output_3, type_as_1], Original ATen: [aten._to_copy, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul]
            stream0 = get_raw_stream(0)
            triton_per_fused__to_copy_add_mean_mul_pow_rsqrt_1.run(arg5_1, arg6_1, buf3, 2, 2048, stream=stream0)
            del arg5_1
            del arg6_1
            buf5 = empty_strided_cuda((4, 1, 2, 2048), (4096, 4096, 2048, 1), torch.float32)
            del buf2
            del buf3
            # Topologically Sorted Source Nodes: [y], Original ATen: []
            stream0 = get_raw_stream(0)
            _w8a16_group_gemv_rows_kernel_0.run(buf4, arg7_1, arg8_1, buf5, 2, 2048, 4096, 32, 4, 1, stream=stream0)
            del arg7_1
            del arg8_1
            buf9 = empty_strided_cuda((1, 2, 2048), (4096, 2048, 1), torch.bfloat16)
            # Topologically Sorted Source Nodes: [y, float_6, pow_3, mean_2, add_5, rsqrt_2, output_4, float_7, add_6, output_5, hidden_states, y_1], Original ATen: [aten.sum, aten._to_copy, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul]
            stream0 = get_raw_stream(0)
            triton_per_fused__to_copy_add_mean_mul_pow_rsqrt_sum_2.run(buf5, arg9_1, buf9, 2, 2048, stream=stream0)
            del arg9_1
            buf8 = empty_strided_cuda((1, 2, 9216), (18432, 9216, 1), torch.bfloat16)
            # Topologically Sorted Source Nodes: [y, float_6, pow_3, mean_2, add_5, rsqrt_2, output_4, float_7, add_6, output_5, hidden_states, y_1], Original ATen: [aten.sum, aten._to_copy, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul]
            stream0 = get_raw_stream(0)
            _w8a16_group_gemv_rows_kernel_1.run(buf9, arg10_1, arg11_1, buf8, 2, 9216, 2048, 288, 1, 1, stream=stream0)
            del arg10_1
            del arg11_1
            del buf9
            buf11 = empty_strided_cuda((1, 2, 16, 1), (32, 16, 1, 32), torch.float32)
            # Topologically Sorted Source Nodes: [float_8, pow_4, mean_3], Original ATen: [aten.split_with_sizes, aten.view, aten.split, aten._to_copy, aten.pow, aten.mean]
            stream0 = get_raw_stream(0)
            triton_per_fused__to_copy_mean_pow_split_split_with_sizes_view_3.run(buf8, buf11, 32, 256, stream=stream0)
            buf12 = empty_strided_cuda((1, 2, 32), (64, 32, 1), torch.float32)
            buf15 = empty_strided_cuda((1, 2, 32), (64, 32, 1), torch.float32)
            # Topologically Sorted Source Nodes: [arange, positions, view, expand, position_ids, getitem, float_1, to, freqs, cos, getitem_2, sin, getitem_5, setitem_1, setitem_3], Original ATen: [aten.arange, aten.add, aten.view, aten.expand, aten.unsqueeze, aten._to_copy, aten.mul, aten.cos, aten.select, aten.slice, aten.sin]
            stream0 = get_raw_stream(0)
            triton_poi_fused__to_copy_add_arange_cos_expand_mul_select_sin_slice_unsqueeze_view_4.run(arg2_1, arg3_1, buf12, buf15, 64, stream=stream0)
            buf18 = reinterpret_tensor(buf4, (1, 16, 2, 256), (8192, 512, 256, 1), 0); del buf4  # reuse
            buf16 = reinterpret_tensor(buf18, (1, 16, 2, 64), (8192, 512, 256, 1), 0)  # alias
            # Topologically Sorted Source Nodes: [arange, positions, view, expand, position_ids, getitem, float_1, to, freqs, cos, getitem_2, sin, getitem_5, float_8, pow_4, mean_3, add_7, rsqrt_3, output_6, float_9, add_8, output_7, type_as_3, query_states_1, q_rot, cos_1, cos_2, cos_3, mul_11, x2, neg, x1, cat_3, sin_1, sin_2, sin_3, mul_12, q_embed], Original ATen: [aten.arange, aten.add, aten.view, aten.expand, aten.unsqueeze, aten._to_copy, aten.mul, aten.cos, aten.select, aten.slice, aten.sin, aten.split_with_sizes, aten.split, aten.pow, aten.mean, aten.rsqrt, aten.transpose, aten.cat, aten.neg]
            stream0 = get_raw_stream(0)
            triton_poi_fused__to_copy_add_arange_cat_cos_expand_mean_mul_neg_pow_rsqrt_select_sin_slice_split_split_with_sizes_transpose_unsqueeze_view_5.run(buf8, buf11, arg12_1, buf12, arg2_1, arg3_1, buf15, buf16, 32, 64, stream=stream0)
            buf17 = reinterpret_tensor(buf18, (1, 16, 2, 192), (8192, 512, 256, 1), 64)  # alias
            # Topologically Sorted Source Nodes: [float_8, pow_4, mean_3, add_7, rsqrt_3, output_6, float_9, add_8, output_7, type_as_3, query_states_1, q_pass, query_states_2], Original ATen: [aten.split_with_sizes, aten.view, aten.split, aten._to_copy, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.transpose, aten.slice, aten.cat]
            stream0 = get_raw_stream(0)
            triton_poi_fused__to_copy_add_cat_mean_mul_pow_rsqrt_slice_split_split_with_sizes_transpose_view_6.run(buf8, buf11, arg12_1, buf17, 32, 192, stream=stream0)
            del arg12_1
            buf19 = empty_strided_cuda((1, 2, 2, 1), (4, 2, 1, 4), torch.float32)
            # Topologically Sorted Source Nodes: [float_10, pow_5, mean_4], Original ATen: [aten.split_with_sizes, aten.view, aten._to_copy, aten.pow, aten.mean]
            stream0 = get_raw_stream(0)
            triton_per_fused__to_copy_mean_pow_split_with_sizes_view_7.run(buf8, buf19, 4, 256, stream=stream0)
            del buf16
            del buf17
            buf24 = empty_strided_cuda((1, 2, 2, 256), (1024, 512, 256, 1), torch.bfloat16)
            buf22 = reinterpret_tensor(buf24, (1, 2, 2, 64), (1024, 512, 256, 1), 0)  # alias
            # Topologically Sorted Source Nodes: [arange, positions, view, expand, position_ids, getitem, float_1, to, freqs, cos, getitem_2, sin, getitem_5, float_10, cos_1, cos_2, cos_3, sin_1, sin_2, sin_3, pow_5, mean_4, add_9, rsqrt_4, output_8, float_11, add_10, output_9, type_as_4, key_states, k_rot, mul_13, x2_1, neg_1, x1_1, cat_4, mul_14, k_embed], Original ATen: [aten.arange, aten.add, aten.view, aten.expand, aten.unsqueeze, aten._to_copy, aten.mul, aten.cos, aten.select, aten.slice, aten.sin, aten.split_with_sizes, aten.cat, aten.pow, aten.mean, aten.rsqrt, aten.transpose, aten.neg]
            stream0 = get_raw_stream(0)
            triton_poi_fused__to_copy_add_arange_cat_cos_expand_mean_mul_neg_pow_rsqrt_select_sin_slice_split_with_sizes_transpose_unsqueeze_view_8.run(buf8, buf19, arg13_1, buf12, arg2_1, arg3_1, buf15, buf22, 256, stream=stream0)
            del arg3_1
            del buf12
            del buf15
            buf23 = reinterpret_tensor(buf24, (1, 2, 2, 192), (1024, 512, 256, 1), 64)  # alias
            # Topologically Sorted Source Nodes: [float_10, pow_5, mean_4, add_9, rsqrt_4, output_8, float_11, add_10, output_9, type_as_4, key_states, k_pass, key_states_1], Original ATen: [aten.split_with_sizes, aten.view, aten._to_copy, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.transpose, aten.slice, aten.cat]
            stream0 = get_raw_stream(0)
            triton_poi_fused__to_copy_add_cat_mean_mul_pow_rsqrt_slice_split_with_sizes_transpose_view_9.run(buf8, buf19, arg13_1, buf23, 768, stream=stream0)
            del arg13_1
            del buf19
            # Topologically Sorted Source Nodes: [arange_1, index, index_copy_], Original ATen: [aten.arange, aten.add, aten.index_copy]
            stream0 = get_raw_stream(0)
            triton_poi_fused_add_arange_index_copy_10.run(arg2_1, buf24, arg14_1, 1024, stream=stream0)
            del buf22
            del buf23
            del buf24
            # Topologically Sorted Source Nodes: [index_copy__1, arange_1, index], Original ATen: [aten.split_with_sizes, aten.arange, aten.add, aten.view, aten.transpose, aten.index_copy]
            stream0 = get_raw_stream(0)
            triton_poi_fused_add_arange_index_copy_split_with_sizes_transpose_view_11.run(arg2_1, buf8, arg15_1, 1024, stream=stream0)
            buf27 = empty_strided_cuda((1, 2, 32, 16), (1024, 512, 16, 1), torch.float32)
            buf28 = empty_strided_cuda((1, 2, 32, 16), (1024, 512, 16, 1), torch.float32)
            buf29 = empty_strided_cuda((1, 2, 32, 16, 256), (262144, 131072, 4096, 256, 1), torch.float32)
            # Topologically Sorted Source Nodes: [query, decode_attention_partials_default], Original ATen: [aten.view]
            stream0 = get_raw_stream(0)
            _decode_attention_kernel_2.run(reinterpret_tensor(buf18, (1, 2, 16, 256), (8192, 4096, 256, 1), 0), arg14_1, arg15_1, arg2_1, buf27, buf28, buf29, 2048, 0.0625, 2, 32, 1, stream=stream0)
            del arg14_1
            del arg15_1
            del buf18
            buf33 = reinterpret_tensor(buf11, (1, 2, 1, 16), (32, 16, 32, 1), 0); del buf11  # reuse
            buf35 = empty_strided_cuda((1, 2, 16), (32, 16, 1), torch.float32)
            # Topologically Sorted Source Nodes: [amax, sub, weight, mul_16, sum_2], Original ATen: [aten.amax, aten.sub, aten.exp, aten.mul, aten.sum]
            stream0 = get_raw_stream(0)
            triton_per_fused_amax_exp_mul_sub_sum_12.run(buf27, buf28, buf33, buf35, 32, 32, stream=stream0)
            del buf28
            buf34 = empty_strided_cuda((1, 2, 16, 256), (8192, 4096, 256, 1), torch.float32)
            # Topologically Sorted Source Nodes: [sub, weight, unsqueeze_2, mul_15, sum_1], Original ATen: [aten.sub, aten.exp, aten.unsqueeze, aten.mul, aten.sum]
            stream0 = get_raw_stream(0)
            triton_per_fused_exp_mul_sub_sum_unsqueeze_13.run(buf27, buf33, buf29, buf34, 8192, 32, stream=stream0)
            del buf27
            del buf29
            del buf33
            buf36 = empty_strided_cuda((4, 1, 2, 2048), (4096, 4096, 2048, 1), torch.float32)
            buf37 = empty_strided_cuda((1, 2, 4096), (8192, 4096, 1), torch.bfloat16)
            # Topologically Sorted Source Nodes: [gate_1, unsqueeze_3, out, attn_output, attn_output_1, transpose_3, attn_output_2, reshape_2, sigmoid, attn_output_4, y_2], Original ATen: [aten.split_with_sizes, aten.view, aten.split, aten.unsqueeze, aten.div, aten._to_copy, aten.transpose, aten.clone, aten._unsafe_view, aten.sigmoid, aten.mul]
            stream0 = get_raw_stream(0)
            triton_poi_fused__to_copy__unsafe_view_clone_div_mul_sigmoid_split_split_with_sizes_transpose_unsqueeze_view_14.run(buf34, buf35, buf8, buf37, 8192, stream=stream0)
            del buf35
            del buf8
            # Topologically Sorted Source Nodes: [gate_1, unsqueeze_3, out, attn_output, attn_output_1, transpose_3, attn_output_2, reshape_2, sigmoid, attn_output_4, y_2], Original ATen: [aten.split_with_sizes, aten.view, aten.split, aten.unsqueeze, aten.div, aten._to_copy, aten.transpose, aten.clone, aten._unsafe_view, aten.sigmoid, aten.mul]
            stream0 = get_raw_stream(0)
            _w8a16_group_gemv_rows_kernel_0.run(buf37, arg16_1, arg17_1, buf36, 2, 2048, 4096, 32, 4, 1, stream=stream0)
            del arg16_1
            del arg17_1
            del buf37
            buf39 = empty_strided_cuda((1, 2, 2048), (4096, 2048, 1), torch.bfloat16)
            buf41 = empty_strided_cuda((1, 2, 2048), (4096, 2048, 1), torch.bfloat16)
            buf58 = empty_strided_cuda((2, 1), (1, 2), torch.float32)
            # Topologically Sorted Source Nodes: [y, y_2, hidden_states_1, float_12, pow_6, mean_5, add_15, rsqrt_5, output_10, float_13, add_16, output_11, hidden_states_2, x, linear_1], Original ATen: [aten.sum, aten._to_copy, aten.add, aten.pow, aten.mean, aten.rsqrt, aten.mul, aten.view, aten.mm, aten.t]
            stream0 = get_raw_stream(0)
            triton_per_fused__to_copy_add_mean_mm_mul_pow_rsqrt_sum_t_view_15.run(buf5, buf36, arg18_1, arg28_1, buf39, buf41, buf58, 2, 2048, stream=stream0)
            del arg18_1
            del arg28_1
            del buf36
            buf42 = empty_strided_cuda((2, 256), (256, 1), torch.bfloat16)
            # Topologically Sorted Source Nodes: [float_12, pow_6, mean_5, add_15, rsqrt_5, output_10, float_13, add_16, output_11, hidden_states_2, x, logits], Original ATen: [aten._to_copy, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.view, aten.t, aten.mm]
            stream0 = get_raw_stream(0)
            triton_tem_fused__to_copy_add_mean_mm_mul_pow_rsqrt_t_view_16.run(buf41, arg19_1, buf42, 4, 1, 1, stream=stream0)
            del arg19_1
            buf45 = empty_strided_cuda((2, 256), (256, 1), torch.float32)
            # Topologically Sorted Source Nodes: [probs], Original ATen: [aten._to_copy, prims.prepare_softmax_online, aten.sub, aten.exp, aten._softmax]
            stream0 = get_raw_stream(0)
            triton_per_fused__softmax__to_copy_exp_prepare_softmax_online_sub_17.run(buf42, buf45, 2, 256, stream=stream0)
            del buf42
            # Topologically Sorted Source Nodes: [probs, topk], Original ATen: [aten._to_copy, aten.sub, aten.exp, aten._softmax, aten.topk]
            buf46 = torch.ops.aten.topk.default(buf45, 8)
            del buf45
            buf47 = buf46[0]
            assert_size_stride(buf47, (2, 8), (8, 1), 'torch.ops.aten.topk.default')
            assert_alignment(buf47, 16, 'torch.ops.aten.topk.default')
            buf48 = buf46[1]
            assert_size_stride(buf48, (2, 8), (8, 1), 'torch.ops.aten.topk.default')
            assert_alignment(buf48, 16, 'torch.ops.aten.topk.default')
            del buf46
            buf49 = reinterpret_tensor(buf34, (4, 2, 1024), (2048, 1024, 1), 0); del buf34  # reuse
            # Topologically Sorted Source Nodes: [float_12, pow_6, mean_5, add_15, rsqrt_5, output_10, float_13, add_16, output_11, hidden_states_2, x, y_3], Original ATen: [aten._to_copy, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.view]
            stream0 = get_raw_stream(0)
            _w8a16_group_gemv_rows_kernel_3.run(reinterpret_tensor(buf41, (2, 2048), (2048, 1), 0), arg24_1, arg25_1, buf49, 2, 1024, 2048, 16, 4, 1, stream=stream0)
            del arg24_1
            del arg25_1
            buf51 = reinterpret_tensor(buf5, (4, 2, 2048), (4096, 2048, 1), 0); del buf5  # reuse
            buf52 = empty_strided_cuda((2, 512), (512, 1), torch.bfloat16)
            # Topologically Sorted Source Nodes: [y_3, chunk_1, silu, mul_20, y_4], Original ATen: [aten.sum, aten._to_copy, aten.split, aten.silu, aten.mul]
            stream0 = get_raw_stream(0)
            triton_poi_fused__to_copy_mul_silu_split_sum_18.run(buf49, buf52, 1024, stream=stream0)
            del buf49
            # Topologically Sorted Source Nodes: [y_3, chunk_1, silu, mul_20, y_4], Original ATen: [aten.sum, aten._to_copy, aten.split, aten.silu, aten.mul]
            stream0 = get_raw_stream(0)
            _w8a16_group_gemv_rows_kernel_4.run(buf52, arg26_1, arg27_1, buf51, 2, 2048, 512, 32, 4, 1, stream=stream0)
            del arg26_1
            del arg27_1
            del buf52
            buf55 = empty_strided_cuda((2, 8), (8, 1), torch.bfloat16)
            # Topologically Sorted Source Nodes: [float_12, pow_6, mean_5, add_15, rsqrt_5, output_10, float_13, add_16, output_11, hidden_states_2, x, sum_3, truediv_1, weights_1, routed], Original ATen: [aten._to_copy, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.view, aten.sum, aten.div, infer_opt.selected_int8_experts]
            stream0 = get_raw_stream(0)
            triton_per_fused__to_copy_add_div_mean_mul_pow_rsqrt_selected_int8_experts_sum_view_19.run(buf47, buf55, 2, 8, stream=stream0)
            del buf47
            # Topologically Sorted Source Nodes: [float_12, pow_6, mean_5, add_15, rsqrt_5, output_10, float_13, add_16, output_11, hidden_states_2, x, truediv_1, weights_1, routed], Original ATen: [aten._to_copy, aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten.view, aten.div, infer_opt.selected_int8_experts]
            buf56 = torch.ops.infer_opt.selected_int8_experts.default(reinterpret_tensor(buf41, (2, 2048), (2048, 1), 0), buf48, buf55, arg20_1, arg21_1, arg22_1, arg23_1)
            del arg20_1
            del arg21_1
            del arg22_1
            del arg23_1
            del buf41
            del buf48
            del buf55
            buf57 = buf56
            assert_size_stride(buf57, (2, 2048), (2048, 1), 'torch.ops.infer_opt.selected_int8_experts.default')
            assert_alignment(buf57, 16, 'torch.ops.infer_opt.selected_int8_experts.default')
            del buf56
            buf59 = empty_strided_cuda((1, 2, 2048), (4096, 2048, 1), torch.float32)
            buf60 = empty_strided_cuda((1, 2, 1), (2, 1, 2), torch.float32)
            # Topologically Sorted Source Nodes: [y_4, linear_1, sigmoid_1, shared, add_17, hidden_states_3, add_18, float_14, pow_7, mean_6], Original ATen: [aten.sum, aten._to_copy, aten.mm, aten.sigmoid, aten.mul, aten.add, aten.view, aten.pow, aten.mean]
            stream0 = get_raw_stream(0)
            triton_per_fused__to_copy_add_mean_mm_mul_pow_sigmoid_sum_view_20.run(buf39, buf57, buf51, buf58, buf59, buf60, 2, 2048, stream=stream0)
            del buf39
            del buf51
            del buf57
            del buf58
            buf61 = empty_strided_cuda((1, ), (1, ), torch.int64)
            # Topologically Sorted Source Nodes: [last], Original ATen: [aten.sub]
            stream0 = get_raw_stream(0)
            triton_poi_fused_sub_21.run(arg30_1, buf61, 1, stream=stream0)
            buf62 = empty_strided_cuda((1, 1, 2048), (2048, 2048, 1), torch.bfloat16)
            # Topologically Sorted Source Nodes: [pow_7, mean_6, add_19, rsqrt_6, output_12, float_15, add_20, output_13, out_1, index_select], Original ATen: [aten.pow, aten.mean, aten.add, aten.rsqrt, aten.mul, aten._to_copy, aten.index_select]
            stream0 = get_raw_stream(0)
            triton_poi_fused__to_copy_add_index_select_mean_mul_pow_rsqrt_22.run(buf61, buf59, buf60, arg29_1, buf62, 2048, stream=stream0)
            del arg29_1
            del buf59
            del buf60
            # Topologically Sorted Source Nodes: [add_], Original ATen: [aten.add, aten.copy_]
            stream0 = get_raw_stream(0)
            triton_poi_fused_add_copy__23.run(arg2_1, arg30_1, arg2_1, 1, stream=stream0)
            del arg2_1
            del arg30_1
        return (buf62, buf61, )

runner = Runner(partitions=[])
call = runner.call
recursively_apply_fns = runner.recursively_apply_fns


def get_args():
    from torch._dynamo.testing import rand_strided
    arg0_1 = rand_strided((248320, 2048), (2048, 1), device='cuda:0', dtype=torch.bfloat16)
    arg1_1 = rand_strided((1, 2), (2, 1), device='cuda:0', dtype=torch.int64)
    arg2_1 = rand_strided((1, ), (1, ), device='cuda:0', dtype=torch.int64)
    arg3_1 = rand_strided((32, ), (1, ), device='cuda:0', dtype=torch.bfloat16)
    arg4_1 = rand_strided((2048, ), (1, ), device='cuda:0', dtype=torch.bfloat16)
    arg5_1 = rand_strided((1, 2, 2048), (4096, 2048, 1), device='cuda:0', dtype=torch.bfloat16)
    arg6_1 = rand_strided((2048, ), (1, ), device='cuda:0', dtype=torch.bfloat16)
    arg7_1 = rand_strided((2048, 4096), (4096, 1), device='cuda:0', dtype=torch.int8)
    arg8_1 = rand_strided((2048, 32), (32, 1), device='cuda:0', dtype=torch.bfloat16)
    arg9_1 = rand_strided((2048, ), (1, ), device='cuda:0', dtype=torch.bfloat16)
    arg10_1 = rand_strided((9216, 2048), (2048, 1), device='cuda:0', dtype=torch.int8)
    arg11_1 = rand_strided((9216, 16), (16, 1), device='cuda:0', dtype=torch.bfloat16)
    arg12_1 = rand_strided((256, ), (1, ), device='cuda:0', dtype=torch.bfloat16)
    arg13_1 = rand_strided((256, ), (1, ), device='cuda:0', dtype=torch.bfloat16)
    arg14_1 = rand_strided((1, 2, 2048, 256), (1048576, 524288, 256, 1), device='cuda:0', dtype=torch.bfloat16)
    arg15_1 = rand_strided((1, 2, 2048, 256), (1048576, 524288, 256, 1), device='cuda:0', dtype=torch.bfloat16)
    arg16_1 = rand_strided((2048, 4096), (4096, 1), device='cuda:0', dtype=torch.int8)
    arg17_1 = rand_strided((2048, 32), (32, 1), device='cuda:0', dtype=torch.bfloat16)
    arg18_1 = rand_strided((2048, ), (1, ), device='cuda:0', dtype=torch.bfloat16)
    arg19_1 = rand_strided((256, 2048), (2048, 1), device='cuda:0', dtype=torch.bfloat16)
    arg20_1 = rand_strided((256, 1024, 2048), (2097152, 2048, 1), device='cuda:0', dtype=torch.int8)
    arg21_1 = rand_strided((256, 1024, 16), (16384, 16, 1), device='cuda:0', dtype=torch.bfloat16)
    arg22_1 = rand_strided((256, 2048, 512), (1048576, 512, 1), device='cuda:0', dtype=torch.int8)
    arg23_1 = rand_strided((256, 2048, 4), (8192, 4, 1), device='cuda:0', dtype=torch.bfloat16)
    arg24_1 = rand_strided((1024, 2048), (2048, 1), device='cuda:0', dtype=torch.int8)
    arg25_1 = rand_strided((1024, 16), (16, 1), device='cuda:0', dtype=torch.bfloat16)
    arg26_1 = rand_strided((2048, 512), (512, 1), device='cuda:0', dtype=torch.int8)
    arg27_1 = rand_strided((2048, 4), (4, 1), device='cuda:0', dtype=torch.bfloat16)
    arg28_1 = rand_strided((1, 2048), (2048, 1), device='cuda:0', dtype=torch.bfloat16)
    arg29_1 = rand_strided((2048, ), (1, ), device='cuda:0', dtype=torch.bfloat16)
    arg30_1 = rand_strided((1, ), (1, ), device='cuda:0', dtype=torch.int64)
    return [arg0_1, arg1_1, arg2_1, arg3_1, arg4_1, arg5_1, arg6_1, arg7_1, arg8_1, arg9_1, arg10_1, arg11_1, arg12_1, arg13_1, arg14_1, arg15_1, arg16_1, arg17_1, arg18_1, arg19_1, arg20_1, arg21_1, arg22_1, arg23_1, arg24_1, arg25_1, arg26_1, arg27_1, arg28_1, arg29_1, arg30_1]


def benchmark_compiled_module(args, times=10, repeat=10):
    from torch._inductor.utils import print_performance
    fn = lambda: call(list(args))
    return print_performance(fn, times=times, repeat=repeat)


if __name__ == "__main__":
    from torch._inductor.wrapper_benchmark import compiled_module_main
    args = get_args()
    compiled_module_main('None', lambda times, repeat: benchmark_compiled_module(args, times=times, repeat=repeat))
