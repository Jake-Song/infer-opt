

import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties

@triton_heuristics.user_autotune(
    configs=[{'num_warps': 8, 'num_stages': 3}],
    inductor_meta={'grid_type': 'FixedGrid', 'fixed_grid': ['_grid_0', '_grid_1', '_grid_2'], 'extra_launcher_args': ['_grid_0', '_grid_1', '_grid_2'], 'kernel_name': '_w8a16_group_gemv_rows_kernel_2', 'backend_hash': 'F7205DDDCE8E401A1728E5D602D369DE155D3FCCD3ACF038A9886E6E0DD93A54', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'max_autotune': True, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': False, 'are_deterministic_algorithms_enabled': False, 'coordinate_descent_tuning': True, 'coordinate_descent_search_radius': 1, 'coordinate_descent_check_all_directions': False},
    triton_meta={'signature': {'x_ptr': '*bf16', 'q_ptr': '*i8', 's_ptr': '*bf16', 'y_ptr': '*fp32', 'M': 'i32', 'N': 'i32', 'K': 'i32', 'GROUP': 'constexpr', 'BLOCK_M': 'constexpr', 'BLOCK_N': 'constexpr', 'SPLIT': 'constexpr'}, 'device': DeviceProperties(type='cuda', index=0, multi_processor_count=108, cc=80, major=8, regs_per_multiprocessor=65536, max_threads_per_multi_processor=2048, max_threads_per_block=1024, warp_size=32), 'constants': {'GROUP': 128, 'BLOCK_M': 16, 'BLOCK_N': 64, 'SPLIT': 4}, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]], (3,): [['tt.divisibility', 16]], (5,): [['tt.divisibility', 16]], (6,): [['tt.divisibility', 16]]}]},
    filename=__file__,
    custom_kernel=True,
)
@triton.jit
def _w8a16_group_gemv_rows_kernel(x_ptr, q_ptr, s_ptr, y_ptr, M, N, K, GROUP: tl.constexpr, BLOCK_M: tl.constexpr,
                                  BLOCK_N: tl.constexpr, SPLIT: tl.constexpr):
    # one group of columns per step: [BLOCK_M, GROUP] x [GROUP, BLOCK_N] on the tensor cores, then the group's scale.
    # With SPLIT > 1 program (pid, s) takes the s-th of SPLIT equal runs of groups and writes fp32 partials [SPLIT, M, N].
    pid = tl.program_id(0)
    split = tl.program_id(1)
    rows = pid * BLOCK_N + tl.arange(0, BLOCK_N)
    row_ok = rows < N
    m = tl.arange(0, BLOCK_M)
    m_ok = m < M
    cols = tl.arange(0, GROUP)
    groups = K // GROUP
    x_ptrs = x_ptr + m[:, None] * K + cols[None, :]
    q_ptrs = q_ptr + rows[:, None].to(tl.int64) * K + cols[None, :]
    s_ptrs = s_ptr + rows * groups
    acc = tl.zeros((BLOCK_M, BLOCK_N), dtype=tl.float32)
    per_split = groups // SPLIT
    for g in range(split * per_split, (split + 1) * per_split):
        x = tl.load(x_ptrs + g * GROUP, mask=m_ok[:, None], other=0.0)
        q = tl.load(q_ptrs + g * GROUP, mask=row_ok[:, None], other=0, eviction_policy="evict_first")
        s = tl.load(s_ptrs + g, mask=row_ok, other=0.0).to(tl.float32)
        acc += tl.dot(x, tl.trans(q.to(x.dtype))) * s[None, :]  # int8 values are exact in fp16/bf16
    y_ptrs = y_ptr + split * M * N + m[:, None] * N + rows[None, :]
    tl.store(y_ptrs, acc.to(y_ptr.dtype.element_ty), mask=m_ok[:, None] & row_ok[None, :])
