# AOT ID: ['1_inference']
from ctypes import c_void_p, c_long, c_int
import torch
import math
import random
import os
import tempfile
from math import inf, nan
from cmath import nanj
from torch._inductor.hooks import run_intermediate_hooks
from torch._inductor.utils import maybe_profile
from torch._inductor.codegen.memory_planning import _align as align
from torch import device, empty_strided
from torch._inductor.async_compile import AsyncCompile
from torch._inductor.select_algorithm import extern_kernels
import triton
import triton.language as tl
from torch._inductor.runtime.triton_heuristics import start_graph, end_graph
from torch._C import _cuda_getCurrentRawStream as get_raw_stream

aten = torch.ops.aten
inductor_ops = torch.ops.inductor
_quantized = torch.ops._quantized
assert_size_stride = torch._C._dynamo.guards.assert_size_stride
assert_alignment = torch._C._dynamo.guards.assert_alignment
empty_strided_cpu = torch._C._dynamo.guards._empty_strided_cpu
empty_strided_cpu_pinned = torch._C._dynamo.guards._empty_strided_cpu_pinned
empty_strided_cuda = torch._C._dynamo.guards._empty_strided_cuda
empty_strided_xpu = torch._C._dynamo.guards._empty_strided_xpu
empty_strided_mtia = torch._C._dynamo.guards._empty_strided_mtia
reinterpret_tensor = torch._C._dynamo.guards._reinterpret_tensor
alloc_from_pool = torch.ops.inductor._alloc_from_pool
async_compile = AsyncCompile()
empty_strided_p2p = torch._C._distributed_c10d._SymmetricMemory.empty_strided_p2p
from torch._C import _cuda_getCurrentRawStream as get_raw_stream



# kernel path: /tmp/infer-opt-models/q35moe-round-profile-20261109/inductor/zc/czcx5ok4pxy5dm7kqdq3mq2m6tg6xpbae735vsiqvnb5g7x4gwyw.py
# Topologically Sorted Source Nodes: [], Original ATen: []
# Source node to ATen node mapping:
# Graph fragment:
#   %bmm : Tensor "f32[16, 2, 32][64, 32, 1]cuda:0" = PlaceHolder[target=bmm]
#   %sum_1 : Tensor "f32[2, 32][32, 1]cuda:0" = PlaceHolder[target=sum_1]
#   %sum_1 : Tensor "f32[2, 32][32, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.sum.dim_IntList](args = (%bmm, [0]), kwargs = {})
#   %convert_element_type_2 : Tensor "bf16[2, 32][32, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%sum_1, torch.bfloat16), kwargs = {})
#   return %sum_1,%convert_element_type_2
triton_per_fused_0 = async_compile.triton('triton_per_fused_0', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.persistent_reduction(
    size_hints={'x': 64, 'r0_': 16},
    reduction_hint=ReductionHint.DEFAULT,
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*fp32', 'out_ptr1': '*bf16', 'xnumel': 'i32', 'r0_numel': 'i32', 'XBLOCK': 'constexpr'}, 'device': DeviceProperties(type='cuda', index=0, multi_processor_count=108, cc=80, major=8, regs_per_multiprocessor=65536, max_threads_per_multi_processor=2048, max_threads_per_block=1024, warp_size=32), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]], (3,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'autotune_hints': set(), 'kernel_name': 'triton_per_fused_0', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': None, 'atomic_add_found': False, 'num_load': 1, 'num_store': 1, 'num_reduction': 1, 'backend_hash': 'F7205DDDCE8E401A1728E5D602D369DE155D3FCCD3ACF038A9886E6E0DD93A54', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'max_autotune': False, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': False, 'are_deterministic_algorithms_enabled': False, 'coordinate_descent_tuning': True, 'coordinate_descent_search_radius': 1, 'coordinate_descent_check_all_directions': False, 'tiling_scores': {'x': 4352, 'r0_': 0}}
)
@triton.jit
def triton_per_fused_0(in_ptr0, out_ptr1, xnumel, r0_numel, XBLOCK : tl.constexpr):
    xnumel = 64
    r0_numel = 16
    R0_BLOCK: tl.constexpr = 16
    rnumel = r0_numel
    RBLOCK: tl.constexpr = R0_BLOCK
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:, None]
    xmask = xindex < xnumel
    r0_index = tl.arange(0, R0_BLOCK)[None, :]
    r0_offset = 0
    r0_mask = tl.full([R0_BLOCK], True, tl.int1)[None, :]
    roffset = r0_offset
    rindex = r0_index
    r0_1 = r0_index
    x0 = xindex
    tmp0 = tl.load(in_ptr0 + (x0 + 64*r0_1), xmask, other=0.0)
    tmp1 = tl.broadcast_to(tmp0, [XBLOCK, R0_BLOCK])
    tmp3 = tl.where(xmask, tmp1, 0)
    tmp4 = tl.sum(tmp3, 1)[:, None].to(tl.float32)
    tmp5 = tmp4.to(tl.float32)
    tl.store(out_ptr1 + (x0), tmp5, xmask)
''', device_str='cuda')

def partition_0(args):
    benchmark_decompose_k_mm_16_split_3_arg0_1, benchmark_decompose_k_mm_16_split_3_arg1_1 = args
    args.clear()
    assert_size_stride(benchmark_decompose_k_mm_16_split_3_arg0_1, (2, 2048), (2048, 1))
    assert_size_stride(benchmark_decompose_k_mm_16_split_3_arg1_1, (2048, 32), (1, 2048))
    with torch.cuda._DeviceGuard(0):
        torch.cuda.set_device(0)
        benchmark_decompose_k_mm_16_split_3_buf0 = empty_strided_cuda((16, 2, 32), (64, 32, 1), torch.float32)
        # Topologically Sorted Source Nodes: [], Original ATen: []
        extern_kernels.bmm_dtype(reinterpret_tensor(benchmark_decompose_k_mm_16_split_3_arg0_1, (16, 2, 128), (128, 2048, 1), 0), reinterpret_tensor(benchmark_decompose_k_mm_16_split_3_arg1_1, (16, 128, 32), (128, 1, 2048), 0), out_dtype=torch.float32, out=benchmark_decompose_k_mm_16_split_3_buf0)
        del benchmark_decompose_k_mm_16_split_3_arg0_1
        del benchmark_decompose_k_mm_16_split_3_arg1_1
        benchmark_decompose_k_mm_16_split_3_buf2 = empty_strided_cuda((2, 32), (32, 1), torch.bfloat16)
        # Topologically Sorted Source Nodes: [], Original ATen: []
        stream0 = get_raw_stream(0)
        triton_per_fused_0.run(benchmark_decompose_k_mm_16_split_3_buf0, benchmark_decompose_k_mm_16_split_3_buf2, 64, 16, stream=stream0)
        del benchmark_decompose_k_mm_16_split_3_buf0
    return (benchmark_decompose_k_mm_16_split_3_buf2, )


async_compile.wait(globals())
del async_compile

class Runner:
    def __init__(self, partitions):
        self.partitions = partitions

    def recursively_apply_fns(self, fns):
        new_callables = []
        for fn, c in zip(fns, self.partitions):
            new_callables.append(fn(c))
        self.partitions = new_callables

    def call(self, args):
        benchmark_decompose_k_mm_16_split_3_arg0_1, benchmark_decompose_k_mm_16_split_3_arg1_1 = args
        args.clear()
        partition0_args = [benchmark_decompose_k_mm_16_split_3_arg0_1, benchmark_decompose_k_mm_16_split_3_arg1_1]
        del benchmark_decompose_k_mm_16_split_3_arg0_1, benchmark_decompose_k_mm_16_split_3_arg1_1
        (benchmark_decompose_k_mm_16_split_3_buf2,) = self.partitions[0](partition0_args)
        del partition0_args
        return (benchmark_decompose_k_mm_16_split_3_buf2, )

runner = Runner(partitions=[partition_0,])
call = runner.call
recursively_apply_fns = runner.recursively_apply_fns


def get_args():
    from torch._dynamo.testing import rand_strided
    benchmark_decompose_k_mm_16_split_3_arg0_1 = rand_strided((2, 2048), (2048, 1), device='cuda:0', dtype=torch.bfloat16)
    benchmark_decompose_k_mm_16_split_3_arg1_1 = rand_strided((2048, 32), (1, 2048), device='cuda:0', dtype=torch.bfloat16)
    return [benchmark_decompose_k_mm_16_split_3_arg0_1, benchmark_decompose_k_mm_16_split_3_arg1_1]


def benchmark_compiled_module(args, times=10, repeat=10):
    from torch._inductor.utils import print_performance
    fn = lambda: call(list(args))
    return print_performance(fn, times=times, repeat=repeat)


if __name__ == "__main__":
    from torch._inductor.wrapper_benchmark import compiled_module_main
    args = get_args()
    compiled_module_main('None', lambda times, repeat: benchmark_compiled_module(args, times=times, repeat=repeat))
