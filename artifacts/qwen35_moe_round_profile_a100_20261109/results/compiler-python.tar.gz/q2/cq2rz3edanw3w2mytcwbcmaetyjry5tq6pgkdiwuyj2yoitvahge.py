
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.pointwise(
    size_hints={'x': 8192}, 
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*bf16', 'in_ptr1': '*bf16', 'in_ptr2': '*bf16', 'out_ptr0': '*fp32', 'xnumel': 'i32', 'XBLOCK': 'constexpr'}, 'device': DeviceProperties(type='cuda', index=0, multi_processor_count=108, cc=80, major=8, regs_per_multiprocessor=65536, max_threads_per_multi_processor=2048, max_threads_per_block=1024, warp_size=32), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]], (3,): [['tt.divisibility', 16]], (4,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'autotune_hints': set(), 'kernel_name': 'triton_poi_fused__to_copy_cat_mul_split_with_sizes_squeeze_sum_transpose_3', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 12, 'num_store': 1, 'num_reduction': 0, 'backend_hash': 'F7205DDDCE8E401A1728E5D602D369DE155D3FCCD3ACF038A9886E6E0DD93A54', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'max_autotune': True, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': False, 'are_deterministic_algorithms_enabled': False, 'coordinate_descent_tuning': True, 'coordinate_descent_search_radius': 1, 'coordinate_descent_check_all_directions': False, 'tiling_scores': {'x': 65536}},
    min_elem_per_thread=0
)
@triton.jit
def triton_poi_fused__to_copy_cat_mul_split_with_sizes_squeeze_sum_transpose_3(in_ptr0, in_ptr1, in_ptr2, out_ptr0, xnumel, XBLOCK : tl.constexpr):
    xnumel = 8192
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:]
    xmask = tl.full([XBLOCK], True, tl.int1)[:]
    x0 = xindex
    tmp11 = tl.load(in_ptr2 + (4*x0), None, eviction_policy='evict_last').to(tl.float32)
    tmp23 = tl.load(in_ptr2 + (1 + 4*x0), None, eviction_policy='evict_last').to(tl.float32)
    tmp36 = tl.load(in_ptr2 + (2 + 4*x0), None, eviction_policy='evict_last').to(tl.float32)
    tmp48 = tl.load(in_ptr2 + (3 + 4*x0), None, eviction_policy='evict_last').to(tl.float32)
    tmp0 = tl.full([1], 0, tl.int64)
    tmp1 = tmp0 >= tmp0
    tmp2 = tl.full([1], 3, tl.int64)
    tmp3 = tmp0 < tmp2
    tmp4 = tl.load(in_ptr0 + (3*x0 + (0)), tmp3, eviction_policy='evict_last', other=0.0).to(tl.float32)
    tmp5 = tmp0 >= tmp2
    tmp6 = tl.full([1], 4, tl.int64)
    tmp7 = tmp0 < tmp6
    tmp8 = tl.load(in_ptr1 + (x0), tmp5, other=0.0).to(tl.float32)
    tmp9 = tl.where(tmp3, tmp4, tmp8)
    tmp10 = tmp9.to(tl.float32)
    tmp12 = tmp11.to(tl.float32)
    tmp13 = tmp10 * tmp12
    tmp14 = tl.full([1], 1, tl.int64)
    tmp15 = tmp14 >= tmp0
    tmp16 = tmp14 < tmp2
    tmp17 = tl.load(in_ptr0 + (3*x0 + (1)), tmp16, eviction_policy='evict_last', other=0.0).to(tl.float32)
    tmp18 = tmp14 >= tmp2
    tmp19 = tmp14 < tmp6
    tmp20 = tl.load(in_ptr1 + (x0), tmp18, other=0.0).to(tl.float32)
    tmp21 = tl.where(tmp16, tmp17, tmp20)
    tmp22 = tmp21.to(tl.float32)
    tmp24 = tmp23.to(tl.float32)
    tmp25 = tmp22 * tmp24
    tmp26 = tmp13 + tmp25
    tmp27 = tl.full([1], 2, tl.int64)
    tmp28 = tmp27 >= tmp0
    tmp29 = tmp27 < tmp2
    tmp30 = tl.load(in_ptr0 + (3*x0 + (2)), tmp29, eviction_policy='evict_last', other=0.0).to(tl.float32)
    tmp31 = tmp27 >= tmp2
    tmp32 = tmp27 < tmp6
    tmp33 = tl.load(in_ptr1 + (x0), tmp31, other=0.0).to(tl.float32)
    tmp34 = tl.where(tmp29, tmp30, tmp33)
    tmp35 = tmp34.to(tl.float32)
    tmp37 = tmp36.to(tl.float32)
    tmp38 = tmp35 * tmp37
    tmp39 = tmp26 + tmp38
    tmp40 = tmp2 >= tmp0
    tmp41 = tmp2 < tmp2
    tmp42 = tl.load(in_ptr0 + (3*x0 + (3)), tmp41, eviction_policy='evict_last', other=0.0).to(tl.float32)
    tmp43 = tmp2 >= tmp2
    tmp44 = tmp2 < tmp6
    tmp45 = tl.load(in_ptr1 + (x0), tmp43, other=0.0).to(tl.float32)
    tmp46 = tl.where(tmp41, tmp42, tmp45)
    tmp47 = tmp46.to(tl.float32)
    tmp49 = tmp48.to(tl.float32)
    tmp50 = tmp47 * tmp49
    tmp51 = tmp39 + tmp50
    tl.store(out_ptr0 + (x0), tmp51, None)
