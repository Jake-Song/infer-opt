# AOT ID: ['10_inference']
from ctypes import c_void_p, c_long, c_int
import torch
import math
import random
import os
import tempfile
from math import inf, nan
from cmath import nanj
from torch._inductor.hooks import run_intermediate_hooks
from torch._inductor.utils import maybe_profile
from torch._inductor.codegen.memory_planning import _align as align
from torch import device, empty_strided
from torch._inductor.async_compile import AsyncCompile
from torch._inductor.select_algorithm import extern_kernels
import triton
import triton.language as tl
from torch._inductor.runtime.triton_heuristics import start_graph, end_graph
from torch._C import _cuda_getCurrentRawStream as get_raw_stream

aten = torch.ops.aten
inductor_ops = torch.ops.inductor
_quantized = torch.ops._quantized
assert_size_stride = torch._C._dynamo.guards.assert_size_stride
assert_alignment = torch._C._dynamo.guards.assert_alignment
empty_strided_cpu = torch._C._dynamo.guards._empty_strided_cpu
empty_strided_cpu_pinned = torch._C._dynamo.guards._empty_strided_cpu_pinned
empty_strided_cuda = torch._C._dynamo.guards._empty_strided_cuda
empty_strided_xpu = torch._C._dynamo.guards._empty_strided_xpu
empty_strided_mtia = torch._C._dynamo.guards._empty_strided_mtia
reinterpret_tensor = torch._C._dynamo.guards._reinterpret_tensor
alloc_from_pool = torch.ops.inductor._alloc_from_pool
async_compile = AsyncCompile()
empty_strided_p2p = torch._C._distributed_c10d._SymmetricMemory.empty_strided_p2p


# kernel path: /tmp/infer-opt-models/q35moe-round-profile-20261109/inductor/ak/cakthtccih3gx5ypzlkw4a3pnmdtrmtoi6yggzyuegdkgibo6wip.py
# Topologically Sorted Source Nodes: [getitem, getitem_1, eq, long, cumprod], Original ATen: [aten.slice, aten.eq, aten._to_copy, aten.cumprod]
# Source node to ATen node mapping:
#   cumprod => cumprod
#   eq => eq
#   getitem => slice_1
#   getitem_1 => slice_2
#   long => convert_element_type
# Graph fragment:
#   %arg0_1 : Tensor "i64[1, 4][4, 1]cuda:0" = PlaceHolder[target=arg0_1]
#   %arg1_1 : Tensor "i64[1, 4][4, 1]cuda:0" = PlaceHolder[target=arg1_1]
#   %slice_1 : Tensor "i64[1, 3][4, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.slice.Tensor](args = (%arg0_1, 1, 1, 9223372036854775807), kwargs = {})
#   %slice_2 : Tensor "i64[1, 3][4, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.slice.Tensor](args = (%arg1_1, 1, 0, -1), kwargs = {})
#   %eq : Tensor "b8[1, 3][3, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.eq.Tensor](args = (%slice_1, %slice_2), kwargs = {})
#   %convert_element_type : Tensor "i64[1, 3][3, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.prims.convert_element_type.default](args = (%eq, torch.int64), kwargs = {})
#   %cumprod : Tensor "i64[1, 3][3, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.cumprod.default](args = (%convert_element_type, -1), kwargs = {})
#   return %cumprod
triton_per_fused__to_copy_cumprod_eq_slice_0 = async_compile.triton('triton_per_fused__to_copy_cumprod_eq_slice_0', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton.jit
def _triton_helper_fn_mul0(arg0_0, arg1_0):
    tmp0 = arg0_0 * arg1_0
    return tmp0

@triton_heuristics.persistent_reduction(
    size_hints={'x': 1, 'r0_': 4},
    reduction_hint=ReductionHint.INNER,
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*i64', 'in_ptr1': '*i64', 'out_ptr0': '*i64', 'xnumel': 'constexpr', 'r0_numel': 'i32', 'XBLOCK': 'constexpr'}, 'device': DeviceProperties(type='cuda', index=0, multi_processor_count=108, cc=80, major=8, regs_per_multiprocessor=65536, max_threads_per_multi_processor=2048, max_threads_per_block=1024, warp_size=32), 'constants': {'xnumel': 1}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'autotune_hints': set(), 'kernel_name': 'triton_per_fused__to_copy_cumprod_eq_slice_0', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': None, 'atomic_add_found': False, 'num_load': 2, 'num_store': 1, 'num_reduction': 0, 'backend_hash': 'F7205DDDCE8E401A1728E5D602D369DE155D3FCCD3ACF038A9886E6E0DD93A54', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'max_autotune': True, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': False, 'are_deterministic_algorithms_enabled': False, 'coordinate_descent_tuning': True, 'coordinate_descent_search_radius': 1, 'coordinate_descent_check_all_directions': False, 'tiling_scores': {'r0_': 36}}
)
@triton.jit
def triton_per_fused__to_copy_cumprod_eq_slice_0(in_ptr0, in_ptr1, out_ptr0, xnumel, r0_numel, XBLOCK : tl.constexpr):
    xnumel = 1
    r0_numel = 3
    R0_BLOCK: tl.constexpr = 4
    rnumel = r0_numel
    RBLOCK: tl.constexpr = R0_BLOCK
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:, None]
    xmask = tl.full([XBLOCK], True, tl.int1)[:, None]
    r0_index = tl.arange(0, R0_BLOCK)[None, :]
    r0_offset = 0
    r0_mask = r0_index < r0_numel
    roffset = r0_offset
    rindex = r0_index
    r0_0 = r0_index
    tmp0 = tl.load(in_ptr0 + (1 + r0_0), r0_mask, other=0.0)
    tmp1 = tl.load(in_ptr1 + (r0_0), r0_mask, other=0.0)
    tmp2 = tmp0 == tmp1
    tmp3 = tmp2.to(tl.int64)
    tmp4 = tmp3.to(tl.int64)
    tmp5 = tl.broadcast_to(tmp4, [XBLOCK, R0_BLOCK])
    tmp6, = tl.associative_scan((tmp5,), 1, _triton_helper_fn_mul0)
    tl.store(out_ptr0 + (tl.broadcast_to(r0_0, [XBLOCK, R0_BLOCK])), tmp6, r0_mask)
''', device_str='cuda')


# kernel path: /tmp/infer-opt-models/q35moe-round-profile-20261109/inductor/hw/chwitv27ipenvokqswb2w67evegqhm7sdmlnipczgo2sph6ifjyn.py
# Topologically Sorted Source Nodes: [sum_1, accepted, add_], Original ATen: [aten.sum, aten.add, aten.copy_]
# Source node to ATen node mapping:
#   accepted => add
#   add_ => add_31
#   sum_1 => sum_1
# Graph fragment:
#   %cumprod : Tensor "i64[1, 3][3, 1]cuda:0" = PlaceHolder[target=cumprod]
#   %copy__60 : Tensor "i64[1][1]cuda:0" = PlaceHolder[target=copy__60]
#   %add : Tensor "i64[1][1]cuda:0" = PlaceHolder[target=add]
#   %add_31 : Tensor "i64[1][1]cuda:0" = PlaceHolder[target=add_31]
#   %sum_1 : Tensor "i64[1][1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.sum.dim_IntList](args = (%cumprod, [-1]), kwargs = {})
#   %add : Tensor "i64[1][1]cuda:0"[num_users=62] = call_function[target=torch.ops.aten.add.Tensor](args = (%sum_1, 1), kwargs = {})
#   %add_31 : Tensor "i64[1][1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%arg122_1, %add), kwargs = {})
#   %copy__60 : Tensor "i64[1][1]cuda:0"[num_users=0] = call_function[target=torch.ops.aten.copy_.default](args = (%arg122_1, %add_31), kwargs = {})
#   return %add,%add_31,%buf63
triton_poi_fused_add_copy__sum_1 = async_compile.triton('triton_poi_fused_add_copy__sum_1', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.pointwise(
    size_hints={'x': 1}, 
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*i64', 'in_ptr1': '*i64', 'out_ptr0': '*i64', 'out_ptr2': '*i64', 'xnumel': 'constexpr', 'XBLOCK': 'constexpr'}, 'device': DeviceProperties(type='cuda', index=0, multi_processor_count=108, cc=80, major=8, regs_per_multiprocessor=65536, max_threads_per_multi_processor=2048, max_threads_per_block=1024, warp_size=32), 'constants': {'xnumel': 1}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]], (3,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'autotune_hints': set(), 'kernel_name': 'triton_poi_fused_add_copy__sum_1', 'mutated_arg_names': ['in_ptr1', 'out_ptr2'], 'optimize_mem': True, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 4, 'num_store': 2, 'num_reduction': 0, 'backend_hash': 'F7205DDDCE8E401A1728E5D602D369DE155D3FCCD3ACF038A9886E6E0DD93A54', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'max_autotune': True, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': False, 'are_deterministic_algorithms_enabled': False, 'coordinate_descent_tuning': True, 'coordinate_descent_search_radius': 1, 'coordinate_descent_check_all_directions': False},
    min_elem_per_thread=0
)
@triton.jit
def triton_poi_fused_add_copy__sum_1(in_ptr0, in_ptr1, out_ptr0, out_ptr2, xnumel, XBLOCK : tl.constexpr):
    xnumel = 1
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:]
    xmask = tl.full([XBLOCK], True, tl.int1)[:]
    tmp0 = tl.load(in_ptr0 + (0))
    tmp1 = tl.broadcast_to(tmp0, [XBLOCK])
    tmp2 = tl.load(in_ptr0 + (1))
    tmp3 = tl.broadcast_to(tmp2, [XBLOCK])
    tmp5 = tl.load(in_ptr0 + (2))
    tmp6 = tl.broadcast_to(tmp5, [XBLOCK])
    tmp10 = tl.load(in_ptr1 + (0))
    tmp11 = tl.broadcast_to(tmp10, [XBLOCK])
    tmp4 = tmp1 + tmp3
    tmp7 = tmp4 + tmp6
    tmp8 = tl.full([1], 1, tl.int64)
    tmp9 = tmp7 + tmp8
    tmp12 = tmp11 + tmp9
    tl.store(out_ptr0 + (tl.full([XBLOCK], 0, tl.int32).broadcast_to(XBLOCK)), tmp9, None)
    tl.store(out_ptr2 + (tl.full([XBLOCK], 0, tl.int32).broadcast_to(XBLOCK)), tmp12, None)
''', device_str='cuda')


# kernel path: /tmp/infer-opt-models/q35moe-round-profile-20261109/inductor/g5/cg5ry6qutjmqscbig23l34ucdl5nmkh4i2ujg76nbhcqxncu3yz7.py
# Topologically Sorted Source Nodes: [arange, window, index_select], Original ATen: [aten.arange, aten.add, aten.index_select, aten.copy_]
# Source node to ATen node mapping:
#   arange => iota
#   index_select => index
#   window => add_1
# Graph fragment:
#   %add : Tensor "i64[1][1]cuda:0" = PlaceHolder[target=add]
#   %arg2_1 : Tensor "bf16[1, 8192, 7][57344, 7, 1]cuda:0" = PlaceHolder[target=arg2_1]
#   %copy_ : Tensor "bf16[1, 8192, 3][24576, 3, 1]cuda:0" = PlaceHolder[target=copy_]
#   %iota : Tensor "i64[3][1]cuda:0"[num_users=1] = call_function[target=torch.ops.prims.iota.default](args = (3,), kwargs = {start: 0, step: 1, dtype: torch.int64, device: cuda:0, requires_grad: False})
#   %add_1 : Tensor "i64[3][1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.add.Tensor](args = (%add, %iota), kwargs = {})
#   %index : Tensor "bf16[1, 8192, 3][24576, 3, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.index.Tensor](args = (%arg2_1, [None, None, %add_1]), kwargs = {})
#   %copy_ : Tensor "bf16[1, 8192, 3][24576, 3, 1]cuda:0"[num_users=0] = call_function[target=torch.ops.aten.copy_.default](args = (%arg3_1, %index), kwargs = {})
#   return %buf2
triton_poi_fused_add_arange_copy__index_select_2 = async_compile.triton('triton_poi_fused_add_arange_copy__index_select_2', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.pointwise(
    size_hints={'x': 32768}, 
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*i64', 'in_ptr1': '*bf16', 'out_ptr0': '*bf16', 'xnumel': 'i32', 'XBLOCK': 'constexpr'}, 'device': DeviceProperties(type='cuda', index=0, multi_processor_count=108, cc=80, major=8, regs_per_multiprocessor=65536, max_threads_per_multi_processor=2048, max_threads_per_block=1024, warp_size=32), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]], (3,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'autotune_hints': set(), 'kernel_name': 'triton_poi_fused_add_arange_copy__index_select_2', 'mutated_arg_names': ['out_ptr0'], 'optimize_mem': True, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 1, 'num_store': 1, 'num_reduction': 0, 'backend_hash': 'F7205DDDCE8E401A1728E5D602D369DE155D3FCCD3ACF038A9886E6E0DD93A54', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'max_autotune': True, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': False, 'are_deterministic_algorithms_enabled': False, 'coordinate_descent_tuning': True, 'coordinate_descent_search_radius': 1, 'coordinate_descent_check_all_directions': False, 'tiling_scores': {'x': 98304}},
    min_elem_per_thread=0
)
@triton.jit
def triton_poi_fused_add_arange_copy__index_select_2(in_ptr0, in_ptr1, out_ptr0, xnumel, XBLOCK : tl.constexpr):
    xnumel = 24576
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:]
    xmask = tl.full([XBLOCK], True, tl.int1)[:]
    x0 = (xindex % 3)
    x1 = xindex // 3
    x2 = xindex
    tmp0 = tl.load(in_ptr0 + (0))
    tmp1 = tl.broadcast_to(tmp0, [XBLOCK])
    tmp2 = x0
    tmp3 = tmp1 + tmp2
    tmp4 = tl.full([XBLOCK], 7, tl.int32)
    tmp5 = tmp3 + tmp4
    tmp6 = tmp3 < 0
    tmp7 = tl.where(tmp6, tmp5, tmp3)
    tl.device_assert((0 <= tmp7) & (tmp7 < 7), "index out of bounds: 0 <= tmp7 < 7")
    tmp9 = tl.load(in_ptr1 + (tmp7 + 7*x1), None, eviction_policy='evict_last').to(tl.float32)
    tl.store(out_ptr0 + (x2), tmp9, None)
''', device_str='cuda')


# kernel path: /tmp/infer-opt-models/q35moe-round-profile-20261109/inductor/ym/cymxa4dezz3mrgcguoz24anp2wdixpzxc2e65a42t7mu2e4iyyhv.py
# Topologically Sorted Source Nodes: [sub, index_select_1, squeeze], Original ATen: [aten.sub, aten.index_select, aten.squeeze, aten.copy_]
# Source node to ATen node mapping:
#   index_select_1 => index_1
#   squeeze => squeeze
#   sub => sub
# Graph fragment:
#   %add : Tensor "i64[1][1]cuda:0" = PlaceHolder[target=add]
#   %arg5_1 : Tensor "f32[4, 1, 32, 128, 128][524288, 524288, 16384, 128, 1]cuda:0" = PlaceHolder[target=arg5_1]
#   %copy__1 : Tensor "f32[1, 32, 128, 128][524288, 16384, 128, 1]cuda:0" = PlaceHolder[target=copy__1]
#   %sub : Tensor "i64[1][1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.sub.Tensor](args = (%add, 1), kwargs = {})
#   %index_1 : Tensor "f32[1, 1, 32, 128, 128][524288, 524288, 16384, 128, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.index.Tensor](args = (%arg5_1, [%sub]), kwargs = {})
#   %squeeze : Tensor "f32[1, 32, 128, 128][524288, 16384, 128, 1]cuda:0"[num_users=1] = call_function[target=torch.ops.aten.squeeze.dim](args = (%index_1, 0), kwargs = {})
#   %copy__1 : Tensor "f32[1, 32, 128, 128][524288, 16384, 128, 1]cuda:0"[num_users=0] = call_function[target=torch.ops.aten.copy_.default](args = (%arg4_1, %squeeze), kwargs = {})
#   return %buf3
triton_poi_fused_copy__index_select_squeeze_sub_3 = async_compile.triton('triton_poi_fused_copy__index_select_squeeze_sub_3', '''
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.pointwise(
    size_hints={'x': 524288}, 
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*i64', 'in_ptr1': '*fp32', 'out_ptr0': '*fp32', 'xnumel': 'i32', 'XBLOCK': 'constexpr'}, 'device': DeviceProperties(type='cuda', index=0, multi_processor_count=108, cc=80, major=8, regs_per_multiprocessor=65536, max_threads_per_multi_processor=2048, max_threads_per_block=1024, warp_size=32), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]], (3,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'autotune_hints': set(), 'kernel_name': 'triton_poi_fused_copy__index_select_squeeze_sub_3', 'mutated_arg_names': ['out_ptr0'], 'optimize_mem': True, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 1, 'num_store': 1, 'num_reduction': 0, 'backend_hash': 'F7205DDDCE8E401A1728E5D602D369DE155D3FCCD3ACF038A9886E6E0DD93A54', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'max_autotune': True, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': False, 'are_deterministic_algorithms_enabled': False, 'coordinate_descent_tuning': True, 'coordinate_descent_search_radius': 1, 'coordinate_descent_check_all_directions': False, 'tiling_scores': {'x': 4194304}},
    min_elem_per_thread=0
)
@triton.jit
def triton_poi_fused_copy__index_select_squeeze_sub_3(in_ptr0, in_ptr1, out_ptr0, xnumel, XBLOCK : tl.constexpr):
    xnumel = 524288
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:]
    xmask = tl.full([XBLOCK], True, tl.int1)[:]
    x0 = xindex
    tmp0 = tl.load(in_ptr0 + (0))
    tmp1 = tl.broadcast_to(tmp0, [XBLOCK])
    tmp2 = tl.full([1], 1, tl.int64)
    tmp3 = tmp1 - tmp2
    tmp4 = tl.full([XBLOCK], 4, tl.int32)
    tmp5 = tmp3 + tmp4
    tmp6 = tmp3 < 0
    tmp7 = tl.where(tmp6, tmp5, tmp3)
    tl.device_assert((0 <= tmp7) & (tmp7 < 4), "index out of bounds: 0 <= tmp7 < 4")
    tmp9 = tl.load(in_ptr1 + (x0 + 524288*tmp7), None)
    tl.store(out_ptr0 + (x0), tmp9, None)
''', device_str='cuda')


async_compile.wait(globals())
del async_compile

class Runner:
    def __init__(self, partitions):
        self.partitions = partitions

    def recursively_apply_fns(self, fns):
        new_callables = []
        for fn, c in zip(fns, self.partitions):
            new_callables.append(fn(c))
        self.partitions = new_callables

    def call(self, args):
        arg0_1, arg1_1, arg2_1, arg3_1, arg4_1, arg5_1, arg6_1, arg7_1, arg8_1, arg9_1, arg10_1, arg11_1, arg12_1, arg13_1, arg14_1, arg15_1, arg16_1, arg17_1, arg18_1, arg19_1, arg20_1, arg21_1, arg22_1, arg23_1, arg24_1, arg25_1, arg26_1, arg27_1, arg28_1, arg29_1, arg30_1, arg31_1, arg32_1, arg33_1, arg34_1, arg35_1, arg36_1, arg37_1, arg38_1, arg39_1, arg40_1, arg41_1, arg42_1, arg43_1, arg44_1, arg45_1, arg46_1, arg47_1, arg48_1, arg49_1, arg50_1, arg51_1, arg52_1, arg53_1, arg54_1, arg55_1, arg56_1, arg57_1, arg58_1, arg59_1, arg60_1, arg61_1, arg62_1, arg63_1, arg64_1, arg65_1, arg66_1, arg67_1, arg68_1, arg69_1, arg70_1, arg71_1, arg72_1, arg73_1, arg74_1, arg75_1, arg76_1, arg77_1, arg78_1, arg79_1, arg80_1, arg81_1, arg82_1, arg83_1, arg84_1, arg85_1, arg86_1, arg87_1, arg88_1, arg89_1, arg90_1, arg91_1, arg92_1, arg93_1, arg94_1, arg95_1, arg96_1, arg97_1, arg98_1, arg99_1, arg100_1, arg101_1, arg102_1, arg103_1, arg104_1, arg105_1, arg106_1, arg107_1, arg108_1, arg109_1, arg110_1, arg111_1, arg112_1, arg113_1, arg114_1, arg115_1, arg116_1, arg117_1, arg118_1, arg119_1, arg120_1, arg121_1, arg122_1 = args
        args.clear()
        assert_size_stride(arg0_1, (1, 4), (4, 1))
        assert_size_stride(arg1_1, (1, 4), (4, 1))
        assert_size_stride(arg2_1, (1, 8192, 7), (57344, 7, 1))
        assert_size_stride(arg3_1, (1, 8192, 3), (24576, 3, 1))
        assert_size_stride(arg4_1, (1, 32, 128, 128), (524288, 16384, 128, 1))
        assert_size_stride(arg5_1, (4, 1, 32, 128, 128), (524288, 524288, 16384, 128, 1))
        assert_size_stride(arg6_1, (1, 8192, 7), (57344, 7, 1))
        assert_size_stride(arg7_1, (1, 8192, 3), (24576, 3, 1))
        assert_size_stride(arg8_1, (1, 32, 128, 128), (524288, 16384, 128, 1))
        assert_size_stride(arg9_1, (4, 1, 32, 128, 128), (524288, 524288, 16384, 128, 1))
        assert_size_stride(arg10_1, (1, 8192, 7), (57344, 7, 1))
        assert_size_stride(arg11_1, (1, 8192, 3), (24576, 3, 1))
        assert_size_stride(arg12_1, (1, 32, 128, 128), (524288, 16384, 128, 1))
        assert_size_stride(arg13_1, (4, 1, 32, 128, 128), (524288, 524288, 16384, 128, 1))
        assert_size_stride(arg14_1, (1, 8192, 7), (57344, 7, 1))
        assert_size_stride(arg15_1, (1, 8192, 3), (24576, 3, 1))
        assert_size_stride(arg16_1, (1, 32, 128, 128), (524288, 16384, 128, 1))
        assert_size_stride(arg17_1, (4, 1, 32, 128, 128), (524288, 524288, 16384, 128, 1))
        assert_size_stride(arg18_1, (1, 8192, 7), (57344, 7, 1))
        assert_size_stride(arg19_1, (1, 8192, 3), (24576, 3, 1))
        assert_size_stride(arg20_1, (1, 32, 128, 128), (524288, 16384, 128, 1))
        assert_size_stride(arg21_1, (4, 1, 32, 128, 128), (524288, 524288, 16384, 128, 1))
        assert_size_stride(arg22_1, (1, 8192, 7), (57344, 7, 1))
        assert_size_stride(arg23_1, (1, 8192, 3), (24576, 3, 1))
        assert_size_stride(arg24_1, (1, 32, 128, 128), (524288, 16384, 128, 1))
        assert_size_stride(arg25_1, (4, 1, 32, 128, 128), (524288, 524288, 16384, 128, 1))
        assert_size_stride(arg26_1, (1, 8192, 7), (57344, 7, 1))
        assert_size_stride(arg27_1, (1, 8192, 3), (24576, 3, 1))
        assert_size_stride(arg28_1, (1, 32, 128, 128), (524288, 16384, 128, 1))
        assert_size_stride(arg29_1, (4, 1, 32, 128, 128), (524288, 524288, 16384, 128, 1))
        assert_size_stride(arg30_1, (1, 8192, 7), (57344, 7, 1))
        assert_size_stride(arg31_1, (1, 8192, 3), (24576, 3, 1))
        assert_size_stride(arg32_1, (1, 32, 128, 128), (524288, 16384, 128, 1))
        assert_size_stride(arg33_1, (4, 1, 32, 128, 128), (524288, 524288, 16384, 128, 1))
        assert_size_stride(arg34_1, (1, 8192, 7), (57344, 7, 1))
        assert_size_stride(arg35_1, (1, 8192, 3), (24576, 3, 1))
        assert_size_stride(arg36_1, (1, 32, 128, 128), (524288, 16384, 128, 1))
        assert_size_stride(arg37_1, (4, 1, 32, 128, 128), (524288, 524288, 16384, 128, 1))
        assert_size_stride(arg38_1, (1, 8192, 7), (57344, 7, 1))
        assert_size_stride(arg39_1, (1, 8192, 3), (24576, 3, 1))
        assert_size_stride(arg40_1, (1, 32, 128, 128), (524288, 16384, 128, 1))
        assert_size_stride(arg41_1, (4, 1, 32, 128, 128), (524288, 524288, 16384, 128, 1))
        assert_size_stride(arg42_1, (1, 8192, 7), (57344, 7, 1))
        assert_size_stride(arg43_1, (1, 8192, 3), (24576, 3, 1))
        assert_size_stride(arg44_1, (1, 32, 128, 128), (524288, 16384, 128, 1))
        assert_size_stride(arg45_1, (4, 1, 32, 128, 128), (524288, 524288, 16384, 128, 1))
        assert_size_stride(arg46_1, (1, 8192, 7), (57344, 7, 1))
        assert_size_stride(arg47_1, (1, 8192, 3), (24576, 3, 1))
        assert_size_stride(arg48_1, (1, 32, 128, 128), (524288, 16384, 128, 1))
        assert_size_stride(arg49_1, (4, 1, 32, 128, 128), (524288, 524288, 16384, 128, 1))
        assert_size_stride(arg50_1, (1, 8192, 7), (57344, 7, 1))
        assert_size_stride(arg51_1, (1, 8192, 3), (24576, 3, 1))
        assert_size_stride(arg52_1, (1, 32, 128, 128), (524288, 16384, 128, 1))
        assert_size_stride(arg53_1, (4, 1, 32, 128, 128), (524288, 524288, 16384, 128, 1))
        assert_size_stride(arg54_1, (1, 8192, 7), (57344, 7, 1))
        assert_size_stride(arg55_1, (1, 8192, 3), (24576, 3, 1))
        assert_size_stride(arg56_1, (1, 32, 128, 128), (524288, 16384, 128, 1))
        assert_size_stride(arg57_1, (4, 1, 32, 128, 128), (524288, 524288, 16384, 128, 1))
        assert_size_stride(arg58_1, (1, 8192, 7), (57344, 7, 1))
        assert_size_stride(arg59_1, (1, 8192, 3), (24576, 3, 1))
        assert_size_stride(arg60_1, (1, 32, 128, 128), (524288, 16384, 128, 1))
        assert_size_stride(arg61_1, (4, 1, 32, 128, 128), (524288, 524288, 16384, 128, 1))
        assert_size_stride(arg62_1, (1, 8192, 7), (57344, 7, 1))
        assert_size_stride(arg63_1, (1, 8192, 3), (24576, 3, 1))
        assert_size_stride(arg64_1, (1, 32, 128, 128), (524288, 16384, 128, 1))
        assert_size_stride(arg65_1, (4, 1, 32, 128, 128), (524288, 524288, 16384, 128, 1))
        assert_size_stride(arg66_1, (1, 8192, 7), (57344, 7, 1))
        assert_size_stride(arg67_1, (1, 8192, 3), (24576, 3, 1))
        assert_size_stride(arg68_1, (1, 32, 128, 128), (524288, 16384, 128, 1))
        assert_size_stride(arg69_1, (4, 1, 32, 128, 128), (524288, 524288, 16384, 128, 1))
        assert_size_stride(arg70_1, (1, 8192, 7), (57344, 7, 1))
        assert_size_stride(arg71_1, (1, 8192, 3), (24576, 3, 1))
        assert_size_stride(arg72_1, (1, 32, 128, 128), (524288, 16384, 128, 1))
        assert_size_stride(arg73_1, (4, 1, 32, 128, 128), (524288, 524288, 16384, 128, 1))
        assert_size_stride(arg74_1, (1, 8192, 7), (57344, 7, 1))
        assert_size_stride(arg75_1, (1, 8192, 3), (24576, 3, 1))
        assert_size_stride(arg76_1, (1, 32, 128, 128), (524288, 16384, 128, 1))
        assert_size_stride(arg77_1, (4, 1, 32, 128, 128), (524288, 524288, 16384, 128, 1))
        assert_size_stride(arg78_1, (1, 8192, 7), (57344, 7, 1))
        assert_size_stride(arg79_1, (1, 8192, 3), (24576, 3, 1))
        assert_size_stride(arg80_1, (1, 32, 128, 128), (524288, 16384, 128, 1))
        assert_size_stride(arg81_1, (4, 1, 32, 128, 128), (524288, 524288, 16384, 128, 1))
        assert_size_stride(arg82_1, (1, 8192, 7), (57344, 7, 1))
        assert_size_stride(arg83_1, (1, 8192, 3), (24576, 3, 1))
        assert_size_stride(arg84_1, (1, 32, 128, 128), (524288, 16384, 128, 1))
        assert_size_stride(arg85_1, (4, 1, 32, 128, 128), (524288, 524288, 16384, 128, 1))
        assert_size_stride(arg86_1, (1, 8192, 7), (57344, 7, 1))
        assert_size_stride(arg87_1, (1, 8192, 3), (24576, 3, 1))
        assert_size_stride(arg88_1, (1, 32, 128, 128), (524288, 16384, 128, 1))
        assert_size_stride(arg89_1, (4, 1, 32, 128, 128), (524288, 524288, 16384, 128, 1))
        assert_size_stride(arg90_1, (1, 8192, 7), (57344, 7, 1))
        assert_size_stride(arg91_1, (1, 8192, 3), (24576, 3, 1))
        assert_size_stride(arg92_1, (1, 32, 128, 128), (524288, 16384, 128, 1))
        assert_size_stride(arg93_1, (4, 1, 32, 128, 128), (524288, 524288, 16384, 128, 1))
        assert_size_stride(arg94_1, (1, 8192, 7), (57344, 7, 1))
        assert_size_stride(arg95_1, (1, 8192, 3), (24576, 3, 1))
        assert_size_stride(arg96_1, (1, 32, 128, 128), (524288, 16384, 128, 1))
        assert_size_stride(arg97_1, (4, 1, 32, 128, 128), (524288, 524288, 16384, 128, 1))
        assert_size_stride(arg98_1, (1, 8192, 7), (57344, 7, 1))
        assert_size_stride(arg99_1, (1, 8192, 3), (24576, 3, 1))
        assert_size_stride(arg100_1, (1, 32, 128, 128), (524288, 16384, 128, 1))
        assert_size_stride(arg101_1, (4, 1, 32, 128, 128), (524288, 524288, 16384, 128, 1))
        assert_size_stride(arg102_1, (1, 8192, 7), (57344, 7, 1))
        assert_size_stride(arg103_1, (1, 8192, 3), (24576, 3, 1))
        assert_size_stride(arg104_1, (1, 32, 128, 128), (524288, 16384, 128, 1))
        assert_size_stride(arg105_1, (4, 1, 32, 128, 128), (524288, 524288, 16384, 128, 1))
        assert_size_stride(arg106_1, (1, 8192, 7), (57344, 7, 1))
        assert_size_stride(arg107_1, (1, 8192, 3), (24576, 3, 1))
        assert_size_stride(arg108_1, (1, 32, 128, 128), (524288, 16384, 128, 1))
        assert_size_stride(arg109_1, (4, 1, 32, 128, 128), (524288, 524288, 16384, 128, 1))
        assert_size_stride(arg110_1, (1, 8192, 7), (57344, 7, 1))
        assert_size_stride(arg111_1, (1, 8192, 3), (24576, 3, 1))
        assert_size_stride(arg112_1, (1, 32, 128, 128), (524288, 16384, 128, 1))
        assert_size_stride(arg113_1, (4, 1, 32, 128, 128), (524288, 524288, 16384, 128, 1))
        assert_size_stride(arg114_1, (1, 8192, 7), (57344, 7, 1))
        assert_size_stride(arg115_1, (1, 8192, 3), (24576, 3, 1))
        assert_size_stride(arg116_1, (1, 32, 128, 128), (524288, 16384, 128, 1))
        assert_size_stride(arg117_1, (4, 1, 32, 128, 128), (524288, 524288, 16384, 128, 1))
        assert_size_stride(arg118_1, (1, 8192, 7), (57344, 7, 1))
        assert_size_stride(arg119_1, (1, 8192, 3), (24576, 3, 1))
        assert_size_stride(arg120_1, (1, 32, 128, 128), (524288, 16384, 128, 1))
        assert_size_stride(arg121_1, (4, 1, 32, 128, 128), (524288, 524288, 16384, 128, 1))
        assert_size_stride(arg122_1, (1, ), (1, ))
        with torch.cuda._DeviceGuard(0):
            torch.cuda.set_device(0)
            buf0 = empty_strided_cuda((1, 3), (3, 1), torch.int64)
            # Topologically Sorted Source Nodes: [getitem, getitem_1, eq, long, cumprod], Original ATen: [aten.slice, aten.eq, aten._to_copy, aten.cumprod]
            stream0 = get_raw_stream(0)
            triton_per_fused__to_copy_cumprod_eq_slice_0.run(arg0_1, arg1_1, buf0, 1, 3, stream=stream0)
            del arg0_1
            del arg1_1
            buf1 = empty_strided_cuda((1, ), (1, ), torch.int64)
            # Topologically Sorted Source Nodes: [sum_1, accepted, add_], Original ATen: [aten.sum, aten.add, aten.copy_]
            stream0 = get_raw_stream(0)
            triton_poi_fused_add_copy__sum_1.run(buf0, arg122_1, buf1, arg122_1, 1, stream=stream0)
            del arg122_1
            del buf0
            # Topologically Sorted Source Nodes: [arange, window, index_select], Original ATen: [aten.arange, aten.add, aten.index_select, aten.copy_]
            stream0 = get_raw_stream(0)
            triton_poi_fused_add_arange_copy__index_select_2.run(buf1, arg2_1, arg3_1, 24576, stream=stream0)
            del arg2_1
            del arg3_1
            # Topologically Sorted Source Nodes: [sub, index_select_1, squeeze], Original ATen: [aten.sub, aten.index_select, aten.squeeze, aten.copy_]
            stream0 = get_raw_stream(0)
            triton_poi_fused_copy__index_select_squeeze_sub_3.run(buf1, arg5_1, arg4_1, 524288, stream=stream0)
            del arg4_1
            del arg5_1
            # Topologically Sorted Source Nodes: [arange_1, window_1, index_select_2], Original ATen: [aten.arange, aten.add, aten.index_select, aten.copy_]
            stream0 = get_raw_stream(0)
            triton_poi_fused_add_arange_copy__index_select_2.run(buf1, arg6_1, arg7_1, 24576, stream=stream0)
            del arg6_1
            del arg7_1
            # Topologically Sorted Source Nodes: [sub_1, index_select_3, squeeze_1], Original ATen: [aten.sub, aten.index_select, aten.squeeze, aten.copy_]
            stream0 = get_raw_stream(0)
            triton_poi_fused_copy__index_select_squeeze_sub_3.run(buf1, arg9_1, arg8_1, 524288, stream=stream0)
            del arg8_1
            del arg9_1
            # Topologically Sorted Source Nodes: [arange_2, window_2, index_select_4], Original ATen: [aten.arange, aten.add, aten.index_select, aten.copy_]
            stream0 = get_raw_stream(0)
            triton_poi_fused_add_arange_copy__index_select_2.run(buf1, arg10_1, arg11_1, 24576, stream=stream0)
            del arg10_1
            del arg11_1
            # Topologically Sorted Source Nodes: [sub_2, index_select_5, squeeze_2], Original ATen: [aten.sub, aten.index_select, aten.squeeze, aten.copy_]
            stream0 = get_raw_stream(0)
            triton_poi_fused_copy__index_select_squeeze_sub_3.run(buf1, arg13_1, arg12_1, 524288, stream=stream0)
            del arg12_1
            del arg13_1
            # Topologically Sorted Source Nodes: [arange_3, window_3, index_select_6], Original ATen: [aten.arange, aten.add, aten.index_select, aten.copy_]
            stream0 = get_raw_stream(0)
            triton_poi_fused_add_arange_copy__index_select_2.run(buf1, arg14_1, arg15_1, 24576, stream=stream0)
            del arg14_1
            del arg15_1
            # Topologically Sorted Source Nodes: [sub_3, index_select_7, squeeze_3], Original ATen: [aten.sub, aten.index_select, aten.squeeze, aten.copy_]
            stream0 = get_raw_stream(0)
            triton_poi_fused_copy__index_select_squeeze_sub_3.run(buf1, arg17_1, arg16_1, 524288, stream=stream0)
            del arg16_1
            del arg17_1
            # Topologically Sorted Source Nodes: [arange_4, window_4, index_select_8], Original ATen: [aten.arange, aten.add, aten.index_select, aten.copy_]
            stream0 = get_raw_stream(0)
            triton_poi_fused_add_arange_copy__index_select_2.run(buf1, arg18_1, arg19_1, 24576, stream=stream0)
            del arg18_1
            del arg19_1
            # Topologically Sorted Source Nodes: [sub_4, index_select_9, squeeze_4], Original ATen: [aten.sub, aten.index_select, aten.squeeze, aten.copy_]
            stream0 = get_raw_stream(0)
            triton_poi_fused_copy__index_select_squeeze_sub_3.run(buf1, arg21_1, arg20_1, 524288, stream=stream0)
            del arg20_1
            del arg21_1
            # Topologically Sorted Source Nodes: [arange_5, window_5, index_select_10], Original ATen: [aten.arange, aten.add, aten.index_select, aten.copy_]
            stream0 = get_raw_stream(0)
            triton_poi_fused_add_arange_copy__index_select_2.run(buf1, arg22_1, arg23_1, 24576, stream=stream0)
            del arg22_1
            del arg23_1
            # Topologically Sorted Source Nodes: [sub_5, index_select_11, squeeze_5], Original ATen: [aten.sub, aten.index_select, aten.squeeze, aten.copy_]
            stream0 = get_raw_stream(0)
            triton_poi_fused_copy__index_select_squeeze_sub_3.run(buf1, arg25_1, arg24_1, 524288, stream=stream0)
            del arg24_1
            del arg25_1
            # Topologically Sorted Source Nodes: [arange_6, window_6, index_select_12], Original ATen: [aten.arange, aten.add, aten.index_select, aten.copy_]
            stream0 = get_raw_stream(0)
            triton_poi_fused_add_arange_copy__index_select_2.run(buf1, arg26_1, arg27_1, 24576, stream=stream0)
            del arg26_1
            del arg27_1
            # Topologically Sorted Source Nodes: [sub_6, index_select_13, squeeze_6], Original ATen: [aten.sub, aten.index_select, aten.squeeze, aten.copy_]
            stream0 = get_raw_stream(0)
            triton_poi_fused_copy__index_select_squeeze_sub_3.run(buf1, arg29_1, arg28_1, 524288, stream=stream0)
            del arg28_1
            del arg29_1
            # Topologically Sorted Source Nodes: [arange_7, window_7, index_select_14], Original ATen: [aten.arange, aten.add, aten.index_select, aten.copy_]
            stream0 = get_raw_stream(0)
            triton_poi_fused_add_arange_copy__index_select_2.run(buf1, arg30_1, arg31_1, 24576, stream=stream0)
            del arg30_1
            del arg31_1
            # Topologically Sorted Source Nodes: [sub_7, index_select_15, squeeze_7], Original ATen: [aten.sub, aten.index_select, aten.squeeze, aten.copy_]
            stream0 = get_raw_stream(0)
            triton_poi_fused_copy__index_select_squeeze_sub_3.run(buf1, arg33_1, arg32_1, 524288, stream=stream0)
            del arg32_1
            del arg33_1
            # Topologically Sorted Source Nodes: [arange_8, window_8, index_select_16], Original ATen: [aten.arange, aten.add, aten.index_select, aten.copy_]
            stream0 = get_raw_stream(0)
            triton_poi_fused_add_arange_copy__index_select_2.run(buf1, arg34_1, arg35_1, 24576, stream=stream0)
            del arg34_1
            del arg35_1
            # Topologically Sorted Source Nodes: [sub_8, index_select_17, squeeze_8], Original ATen: [aten.sub, aten.index_select, aten.squeeze, aten.copy_]
            stream0 = get_raw_stream(0)
            triton_poi_fused_copy__index_select_squeeze_sub_3.run(buf1, arg37_1, arg36_1, 524288, stream=stream0)
            del arg36_1
            del arg37_1
            # Topologically Sorted Source Nodes: [arange_9, window_9, index_select_18], Original ATen: [aten.arange, aten.add, aten.index_select, aten.copy_]
            stream0 = get_raw_stream(0)
            triton_poi_fused_add_arange_copy__index_select_2.run(buf1, arg38_1, arg39_1, 24576, stream=stream0)
            del arg38_1
            del arg39_1
            # Topologically Sorted Source Nodes: [sub_9, index_select_19, squeeze_9], Original ATen: [aten.sub, aten.index_select, aten.squeeze, aten.copy_]
            stream0 = get_raw_stream(0)
            triton_poi_fused_copy__index_select_squeeze_sub_3.run(buf1, arg41_1, arg40_1, 524288, stream=stream0)
            del arg40_1
            del arg41_1
            # Topologically Sorted Source Nodes: [arange_10, window_10, index_select_20], Original ATen: [aten.arange, aten.add, aten.index_select, aten.copy_]
            stream0 = get_raw_stream(0)
            triton_poi_fused_add_arange_copy__index_select_2.run(buf1, arg42_1, arg43_1, 24576, stream=stream0)
            del arg42_1
            del arg43_1
            # Topologically Sorted Source Nodes: [sub_10, index_select_21, squeeze_10], Original ATen: [aten.sub, aten.index_select, aten.squeeze, aten.copy_]
            stream0 = get_raw_stream(0)
            triton_poi_fused_copy__index_select_squeeze_sub_3.run(buf1, arg45_1, arg44_1, 524288, stream=stream0)
            del arg44_1
            del arg45_1
            # Topologically Sorted Source Nodes: [arange_11, window_11, index_select_22], Original ATen: [aten.arange, aten.add, aten.index_select, aten.copy_]
            stream0 = get_raw_stream(0)
            triton_poi_fused_add_arange_copy__index_select_2.run(buf1, arg46_1, arg47_1, 24576, stream=stream0)
            del arg46_1
            del arg47_1
            # Topologically Sorted Source Nodes: [sub_11, index_select_23, squeeze_11], Original ATen: [aten.sub, aten.index_select, aten.squeeze, aten.copy_]
            stream0 = get_raw_stream(0)
            triton_poi_fused_copy__index_select_squeeze_sub_3.run(buf1, arg49_1, arg48_1, 524288, stream=stream0)
            del arg48_1
            del arg49_1
            # Topologically Sorted Source Nodes: [arange_12, window_12, index_select_24], Original ATen: [aten.arange, aten.add, aten.index_select, aten.copy_]
            stream0 = get_raw_stream(0)
            triton_poi_fused_add_arange_copy__index_select_2.run(buf1, arg50_1, arg51_1, 24576, stream=stream0)
            del arg50_1
            del arg51_1
            # Topologically Sorted Source Nodes: [sub_12, index_select_25, squeeze_12], Original ATen: [aten.sub, aten.index_select, aten.squeeze, aten.copy_]
            stream0 = get_raw_stream(0)
            triton_poi_fused_copy__index_select_squeeze_sub_3.run(buf1, arg53_1, arg52_1, 524288, stream=stream0)
            del arg52_1
            del arg53_1
            # Topologically Sorted Source Nodes: [arange_13, window_13, index_select_26], Original ATen: [aten.arange, aten.add, aten.index_select, aten.copy_]
            stream0 = get_raw_stream(0)
            triton_poi_fused_add_arange_copy__index_select_2.run(buf1, arg54_1, arg55_1, 24576, stream=stream0)
            del arg54_1
            del arg55_1
            # Topologically Sorted Source Nodes: [sub_13, index_select_27, squeeze_13], Original ATen: [aten.sub, aten.index_select, aten.squeeze, aten.copy_]
            stream0 = get_raw_stream(0)
            triton_poi_fused_copy__index_select_squeeze_sub_3.run(buf1, arg57_1, arg56_1, 524288, stream=stream0)
            del arg56_1
            del arg57_1
            # Topologically Sorted Source Nodes: [arange_14, window_14, index_select_28], Original ATen: [aten.arange, aten.add, aten.index_select, aten.copy_]
            stream0 = get_raw_stream(0)
            triton_poi_fused_add_arange_copy__index_select_2.run(buf1, arg58_1, arg59_1, 24576, stream=stream0)
            del arg58_1
            del arg59_1
            # Topologically Sorted Source Nodes: [sub_14, index_select_29, squeeze_14], Original ATen: [aten.sub, aten.index_select, aten.squeeze, aten.copy_]
            stream0 = get_raw_stream(0)
            triton_poi_fused_copy__index_select_squeeze_sub_3.run(buf1, arg61_1, arg60_1, 524288, stream=stream0)
            del arg60_1
            del arg61_1
            # Topologically Sorted Source Nodes: [arange_15, window_15, index_select_30], Original ATen: [aten.arange, aten.add, aten.index_select, aten.copy_]
            stream0 = get_raw_stream(0)
            triton_poi_fused_add_arange_copy__index_select_2.run(buf1, arg62_1, arg63_1, 24576, stream=stream0)
            del arg62_1
            del arg63_1
            # Topologically Sorted Source Nodes: [sub_15, index_select_31, squeeze_15], Original ATen: [aten.sub, aten.index_select, aten.squeeze, aten.copy_]
            stream0 = get_raw_stream(0)
            triton_poi_fused_copy__index_select_squeeze_sub_3.run(buf1, arg65_1, arg64_1, 524288, stream=stream0)
            del arg64_1
            del arg65_1
            # Topologically Sorted Source Nodes: [arange_16, window_16, index_select_32], Original ATen: [aten.arange, aten.add, aten.index_select, aten.copy_]
            stream0 = get_raw_stream(0)
            triton_poi_fused_add_arange_copy__index_select_2.run(buf1, arg66_1, arg67_1, 24576, stream=stream0)
            del arg66_1
            del arg67_1
            # Topologically Sorted Source Nodes: [sub_16, index_select_33, squeeze_16], Original ATen: [aten.sub, aten.index_select, aten.squeeze, aten.copy_]
            stream0 = get_raw_stream(0)
            triton_poi_fused_copy__index_select_squeeze_sub_3.run(buf1, arg69_1, arg68_1, 524288, stream=stream0)
            del arg68_1
            del arg69_1
            # Topologically Sorted Source Nodes: [arange_17, window_17, index_select_34], Original ATen: [aten.arange, aten.add, aten.index_select, aten.copy_]
            stream0 = get_raw_stream(0)
            triton_poi_fused_add_arange_copy__index_select_2.run(buf1, arg70_1, arg71_1, 24576, stream=stream0)
            del arg70_1
            del arg71_1
            # Topologically Sorted Source Nodes: [sub_17, index_select_35, squeeze_17], Original ATen: [aten.sub, aten.index_select, aten.squeeze, aten.copy_]
            stream0 = get_raw_stream(0)
            triton_poi_fused_copy__index_select_squeeze_sub_3.run(buf1, arg73_1, arg72_1, 524288, stream=stream0)
            del arg72_1
            del arg73_1
            # Topologically Sorted Source Nodes: [arange_18, window_18, index_select_36], Original ATen: [aten.arange, aten.add, aten.index_select, aten.copy_]
            stream0 = get_raw_stream(0)
            triton_poi_fused_add_arange_copy__index_select_2.run(buf1, arg74_1, arg75_1, 24576, stream=stream0)
            del arg74_1
            del arg75_1
            # Topologically Sorted Source Nodes: [sub_18, index_select_37, squeeze_18], Original ATen: [aten.sub, aten.index_select, aten.squeeze, aten.copy_]
            stream0 = get_raw_stream(0)
            triton_poi_fused_copy__index_select_squeeze_sub_3.run(buf1, arg77_1, arg76_1, 524288, stream=stream0)
            del arg76_1
            del arg77_1
            # Topologically Sorted Source Nodes: [arange_19, window_19, index_select_38], Original ATen: [aten.arange, aten.add, aten.index_select, aten.copy_]
            stream0 = get_raw_stream(0)
            triton_poi_fused_add_arange_copy__index_select_2.run(buf1, arg78_1, arg79_1, 24576, stream=stream0)
            del arg78_1
            del arg79_1
            # Topologically Sorted Source Nodes: [sub_19, index_select_39, squeeze_19], Original ATen: [aten.sub, aten.index_select, aten.squeeze, aten.copy_]
            stream0 = get_raw_stream(0)
            triton_poi_fused_copy__index_select_squeeze_sub_3.run(buf1, arg81_1, arg80_1, 524288, stream=stream0)
            del arg80_1
            del arg81_1
            # Topologically Sorted Source Nodes: [arange_20, window_20, index_select_40], Original ATen: [aten.arange, aten.add, aten.index_select, aten.copy_]
            stream0 = get_raw_stream(0)
            triton_poi_fused_add_arange_copy__index_select_2.run(buf1, arg82_1, arg83_1, 24576, stream=stream0)
            del arg82_1
            del arg83_1
            # Topologically Sorted Source Nodes: [sub_20, index_select_41, squeeze_20], Original ATen: [aten.sub, aten.index_select, aten.squeeze, aten.copy_]
            stream0 = get_raw_stream(0)
            triton_poi_fused_copy__index_select_squeeze_sub_3.run(buf1, arg85_1, arg84_1, 524288, stream=stream0)
            del arg84_1
            del arg85_1
            # Topologically Sorted Source Nodes: [arange_21, window_21, index_select_42], Original ATen: [aten.arange, aten.add, aten.index_select, aten.copy_]
            stream0 = get_raw_stream(0)
            triton_poi_fused_add_arange_copy__index_select_2.run(buf1, arg86_1, arg87_1, 24576, stream=stream0)
            del arg86_1
            del arg87_1
            # Topologically Sorted Source Nodes: [sub_21, index_select_43, squeeze_21], Original ATen: [aten.sub, aten.index_select, aten.squeeze, aten.copy_]
            stream0 = get_raw_stream(0)
            triton_poi_fused_copy__index_select_squeeze_sub_3.run(buf1, arg89_1, arg88_1, 524288, stream=stream0)
            del arg88_1
            del arg89_1
            # Topologically Sorted Source Nodes: [arange_22, window_22, index_select_44], Original ATen: [aten.arange, aten.add, aten.index_select, aten.copy_]
            stream0 = get_raw_stream(0)
            triton_poi_fused_add_arange_copy__index_select_2.run(buf1, arg90_1, arg91_1, 24576, stream=stream0)
            del arg90_1
            del arg91_1
            # Topologically Sorted Source Nodes: [sub_22, index_select_45, squeeze_22], Original ATen: [aten.sub, aten.index_select, aten.squeeze, aten.copy_]
            stream0 = get_raw_stream(0)
            triton_poi_fused_copy__index_select_squeeze_sub_3.run(buf1, arg93_1, arg92_1, 524288, stream=stream0)
            del arg92_1
            del arg93_1
            # Topologically Sorted Source Nodes: [arange_23, window_23, index_select_46], Original ATen: [aten.arange, aten.add, aten.index_select, aten.copy_]
            stream0 = get_raw_stream(0)
            triton_poi_fused_add_arange_copy__index_select_2.run(buf1, arg94_1, arg95_1, 24576, stream=stream0)
            del arg94_1
            del arg95_1
            # Topologically Sorted Source Nodes: [sub_23, index_select_47, squeeze_23], Original ATen: [aten.sub, aten.index_select, aten.squeeze, aten.copy_]
            stream0 = get_raw_stream(0)
            triton_poi_fused_copy__index_select_squeeze_sub_3.run(buf1, arg97_1, arg96_1, 524288, stream=stream0)
            del arg96_1
            del arg97_1
            # Topologically Sorted Source Nodes: [arange_24, window_24, index_select_48], Original ATen: [aten.arange, aten.add, aten.index_select, aten.copy_]
            stream0 = get_raw_stream(0)
            triton_poi_fused_add_arange_copy__index_select_2.run(buf1, arg98_1, arg99_1, 24576, stream=stream0)
            del arg98_1
            del arg99_1
            # Topologically Sorted Source Nodes: [sub_24, index_select_49, squeeze_24], Original ATen: [aten.sub, aten.index_select, aten.squeeze, aten.copy_]
            stream0 = get_raw_stream(0)
            triton_poi_fused_copy__index_select_squeeze_sub_3.run(buf1, arg101_1, arg100_1, 524288, stream=stream0)
            del arg100_1
            del arg101_1
            # Topologically Sorted Source Nodes: [arange_25, window_25, index_select_50], Original ATen: [aten.arange, aten.add, aten.index_select, aten.copy_]
            stream0 = get_raw_stream(0)
            triton_poi_fused_add_arange_copy__index_select_2.run(buf1, arg102_1, arg103_1, 24576, stream=stream0)
            del arg102_1
            del arg103_1
            # Topologically Sorted Source Nodes: [sub_25, index_select_51, squeeze_25], Original ATen: [aten.sub, aten.index_select, aten.squeeze, aten.copy_]
            stream0 = get_raw_stream(0)
            triton_poi_fused_copy__index_select_squeeze_sub_3.run(buf1, arg105_1, arg104_1, 524288, stream=stream0)
            del arg104_1
            del arg105_1
            # Topologically Sorted Source Nodes: [arange_26, window_26, index_select_52], Original ATen: [aten.arange, aten.add, aten.index_select, aten.copy_]
            stream0 = get_raw_stream(0)
            triton_poi_fused_add_arange_copy__index_select_2.run(buf1, arg106_1, arg107_1, 24576, stream=stream0)
            del arg106_1
            del arg107_1
            # Topologically Sorted Source Nodes: [sub_26, index_select_53, squeeze_26], Original ATen: [aten.sub, aten.index_select, aten.squeeze, aten.copy_]
            stream0 = get_raw_stream(0)
            triton_poi_fused_copy__index_select_squeeze_sub_3.run(buf1, arg109_1, arg108_1, 524288, stream=stream0)
            del arg108_1
            del arg109_1
            # Topologically Sorted Source Nodes: [arange_27, window_27, index_select_54], Original ATen: [aten.arange, aten.add, aten.index_select, aten.copy_]
            stream0 = get_raw_stream(0)
            triton_poi_fused_add_arange_copy__index_select_2.run(buf1, arg110_1, arg111_1, 24576, stream=stream0)
            del arg110_1
            del arg111_1
            # Topologically Sorted Source Nodes: [sub_27, index_select_55, squeeze_27], Original ATen: [aten.sub, aten.index_select, aten.squeeze, aten.copy_]
            stream0 = get_raw_stream(0)
            triton_poi_fused_copy__index_select_squeeze_sub_3.run(buf1, arg113_1, arg112_1, 524288, stream=stream0)
            del arg112_1
            del arg113_1
            # Topologically Sorted Source Nodes: [arange_28, window_28, index_select_56], Original ATen: [aten.arange, aten.add, aten.index_select, aten.copy_]
            stream0 = get_raw_stream(0)
            triton_poi_fused_add_arange_copy__index_select_2.run(buf1, arg114_1, arg115_1, 24576, stream=stream0)
            del arg114_1
            del arg115_1
            # Topologically Sorted Source Nodes: [sub_28, index_select_57, squeeze_28], Original ATen: [aten.sub, aten.index_select, aten.squeeze, aten.copy_]
            stream0 = get_raw_stream(0)
            triton_poi_fused_copy__index_select_squeeze_sub_3.run(buf1, arg117_1, arg116_1, 524288, stream=stream0)
            del arg116_1
            del arg117_1
            # Topologically Sorted Source Nodes: [arange_29, window_29, index_select_58], Original ATen: [aten.arange, aten.add, aten.index_select, aten.copy_]
            stream0 = get_raw_stream(0)
            triton_poi_fused_add_arange_copy__index_select_2.run(buf1, arg118_1, arg119_1, 24576, stream=stream0)
            del arg118_1
            del arg119_1
            # Topologically Sorted Source Nodes: [sub_29, index_select_59, squeeze_29], Original ATen: [aten.sub, aten.index_select, aten.squeeze, aten.copy_]
            stream0 = get_raw_stream(0)
            triton_poi_fused_copy__index_select_squeeze_sub_3.run(buf1, arg121_1, arg120_1, 524288, stream=stream0)
            del arg120_1
            del arg121_1
        return (buf1, )

runner = Runner(partitions=[])
call = runner.call
recursively_apply_fns = runner.recursively_apply_fns


def get_args():
    from torch._dynamo.testing import rand_strided
    arg0_1 = rand_strided((1, 4), (4, 1), device='cuda:0', dtype=torch.int64)
    arg1_1 = rand_strided((1, 4), (4, 1), device='cuda:0', dtype=torch.int64)
    arg2_1 = rand_strided((1, 8192, 7), (57344, 7, 1), device='cuda:0', dtype=torch.bfloat16)
    arg3_1 = rand_strided((1, 8192, 3), (24576, 3, 1), device='cuda:0', dtype=torch.bfloat16)
    arg4_1 = rand_strided((1, 32, 128, 128), (524288, 16384, 128, 1), device='cuda:0', dtype=torch.float32)
    arg5_1 = rand_strided((4, 1, 32, 128, 128), (524288, 524288, 16384, 128, 1), device='cuda:0', dtype=torch.float32)
    arg6_1 = rand_strided((1, 8192, 7), (57344, 7, 1), device='cuda:0', dtype=torch.bfloat16)
    arg7_1 = rand_strided((1, 8192, 3), (24576, 3, 1), device='cuda:0', dtype=torch.bfloat16)
    arg8_1 = rand_strided((1, 32, 128, 128), (524288, 16384, 128, 1), device='cuda:0', dtype=torch.float32)
    arg9_1 = rand_strided((4, 1, 32, 128, 128), (524288, 524288, 16384, 128, 1), device='cuda:0', dtype=torch.float32)
    arg10_1 = rand_strided((1, 8192, 7), (57344, 7, 1), device='cuda:0', dtype=torch.bfloat16)
    arg11_1 = rand_strided((1, 8192, 3), (24576, 3, 1), device='cuda:0', dtype=torch.bfloat16)
    arg12_1 = rand_strided((1, 32, 128, 128), (524288, 16384, 128, 1), device='cuda:0', dtype=torch.float32)
    arg13_1 = rand_strided((4, 1, 32, 128, 128), (524288, 524288, 16384, 128, 1), device='cuda:0', dtype=torch.float32)
    arg14_1 = rand_strided((1, 8192, 7), (57344, 7, 1), device='cuda:0', dtype=torch.bfloat16)
    arg15_1 = rand_strided((1, 8192, 3), (24576, 3, 1), device='cuda:0', dtype=torch.bfloat16)
    arg16_1 = rand_strided((1, 32, 128, 128), (524288, 16384, 128, 1), device='cuda:0', dtype=torch.float32)
    arg17_1 = rand_strided((4, 1, 32, 128, 128), (524288, 524288, 16384, 128, 1), device='cuda:0', dtype=torch.float32)
    arg18_1 = rand_strided((1, 8192, 7), (57344, 7, 1), device='cuda:0', dtype=torch.bfloat16)
    arg19_1 = rand_strided((1, 8192, 3), (24576, 3, 1), device='cuda:0', dtype=torch.bfloat16)
    arg20_1 = rand_strided((1, 32, 128, 128), (524288, 16384, 128, 1), device='cuda:0', dtype=torch.float32)
    arg21_1 = rand_strided((4, 1, 32, 128, 128), (524288, 524288, 16384, 128, 1), device='cuda:0', dtype=torch.float32)
    arg22_1 = rand_strided((1, 8192, 7), (57344, 7, 1), device='cuda:0', dtype=torch.bfloat16)
    arg23_1 = rand_strided((1, 8192, 3), (24576, 3, 1), device='cuda:0', dtype=torch.bfloat16)
    arg24_1 = rand_strided((1, 32, 128, 128), (524288, 16384, 128, 1), device='cuda:0', dtype=torch.float32)
    arg25_1 = rand_strided((4, 1, 32, 128, 128), (524288, 524288, 16384, 128, 1), device='cuda:0', dtype=torch.float32)
    arg26_1 = rand_strided((1, 8192, 7), (57344, 7, 1), device='cuda:0', dtype=torch.bfloat16)
    arg27_1 = rand_strided((1, 8192, 3), (24576, 3, 1), device='cuda:0', dtype=torch.bfloat16)
    arg28_1 = rand_strided((1, 32, 128, 128), (524288, 16384, 128, 1), device='cuda:0', dtype=torch.float32)
    arg29_1 = rand_strided((4, 1, 32, 128, 128), (524288, 524288, 16384, 128, 1), device='cuda:0', dtype=torch.float32)
    arg30_1 = rand_strided((1, 8192, 7), (57344, 7, 1), device='cuda:0', dtype=torch.bfloat16)
    arg31_1 = rand_strided((1, 8192, 3), (24576, 3, 1), device='cuda:0', dtype=torch.bfloat16)
    arg32_1 = rand_strided((1, 32, 128, 128), (524288, 16384, 128, 1), device='cuda:0', dtype=torch.float32)
    arg33_1 = rand_strided((4, 1, 32, 128, 128), (524288, 524288, 16384, 128, 1), device='cuda:0', dtype=torch.float32)
    arg34_1 = rand_strided((1, 8192, 7), (57344, 7, 1), device='cuda:0', dtype=torch.bfloat16)
    arg35_1 = rand_strided((1, 8192, 3), (24576, 3, 1), device='cuda:0', dtype=torch.bfloat16)
    arg36_1 = rand_strided((1, 32, 128, 128), (524288, 16384, 128, 1), device='cuda:0', dtype=torch.float32)
    arg37_1 = rand_strided((4, 1, 32, 128, 128), (524288, 524288, 16384, 128, 1), device='cuda:0', dtype=torch.float32)
    arg38_1 = rand_strided((1, 8192, 7), (57344, 7, 1), device='cuda:0', dtype=torch.bfloat16)
    arg39_1 = rand_strided((1, 8192, 3), (24576, 3, 1), device='cuda:0', dtype=torch.bfloat16)
    arg40_1 = rand_strided((1, 32, 128, 128), (524288, 16384, 128, 1), device='cuda:0', dtype=torch.float32)
    arg41_1 = rand_strided((4, 1, 32, 128, 128), (524288, 524288, 16384, 128, 1), device='cuda:0', dtype=torch.float32)
    arg42_1 = rand_strided((1, 8192, 7), (57344, 7, 1), device='cuda:0', dtype=torch.bfloat16)
    arg43_1 = rand_strided((1, 8192, 3), (24576, 3, 1), device='cuda:0', dtype=torch.bfloat16)
    arg44_1 = rand_strided((1, 32, 128, 128), (524288, 16384, 128, 1), device='cuda:0', dtype=torch.float32)
    arg45_1 = rand_strided((4, 1, 32, 128, 128), (524288, 524288, 16384, 128, 1), device='cuda:0', dtype=torch.float32)
    arg46_1 = rand_strided((1, 8192, 7), (57344, 7, 1), device='cuda:0', dtype=torch.bfloat16)
    arg47_1 = rand_strided((1, 8192, 3), (24576, 3, 1), device='cuda:0', dtype=torch.bfloat16)
    arg48_1 = rand_strided((1, 32, 128, 128), (524288, 16384, 128, 1), device='cuda:0', dtype=torch.float32)
    arg49_1 = rand_strided((4, 1, 32, 128, 128), (524288, 524288, 16384, 128, 1), device='cuda:0', dtype=torch.float32)
    arg50_1 = rand_strided((1, 8192, 7), (57344, 7, 1), device='cuda:0', dtype=torch.bfloat16)
    arg51_1 = rand_strided((1, 8192, 3), (24576, 3, 1), device='cuda:0', dtype=torch.bfloat16)
    arg52_1 = rand_strided((1, 32, 128, 128), (524288, 16384, 128, 1), device='cuda:0', dtype=torch.float32)
    arg53_1 = rand_strided((4, 1, 32, 128, 128), (524288, 524288, 16384, 128, 1), device='cuda:0', dtype=torch.float32)
    arg54_1 = rand_strided((1, 8192, 7), (57344, 7, 1), device='cuda:0', dtype=torch.bfloat16)
    arg55_1 = rand_strided((1, 8192, 3), (24576, 3, 1), device='cuda:0', dtype=torch.bfloat16)
    arg56_1 = rand_strided((1, 32, 128, 128), (524288, 16384, 128, 1), device='cuda:0', dtype=torch.float32)
    arg57_1 = rand_strided((4, 1, 32, 128, 128), (524288, 524288, 16384, 128, 1), device='cuda:0', dtype=torch.float32)
    arg58_1 = rand_strided((1, 8192, 7), (57344, 7, 1), device='cuda:0', dtype=torch.bfloat16)
    arg59_1 = rand_strided((1, 8192, 3), (24576, 3, 1), device='cuda:0', dtype=torch.bfloat16)
    arg60_1 = rand_strided((1, 32, 128, 128), (524288, 16384, 128, 1), device='cuda:0', dtype=torch.float32)
    arg61_1 = rand_strided((4, 1, 32, 128, 128), (524288, 524288, 16384, 128, 1), device='cuda:0', dtype=torch.float32)
    arg62_1 = rand_strided((1, 8192, 7), (57344, 7, 1), device='cuda:0', dtype=torch.bfloat16)
    arg63_1 = rand_strided((1, 8192, 3), (24576, 3, 1), device='cuda:0', dtype=torch.bfloat16)
    arg64_1 = rand_strided((1, 32, 128, 128), (524288, 16384, 128, 1), device='cuda:0', dtype=torch.float32)
    arg65_1 = rand_strided((4, 1, 32, 128, 128), (524288, 524288, 16384, 128, 1), device='cuda:0', dtype=torch.float32)
    arg66_1 = rand_strided((1, 8192, 7), (57344, 7, 1), device='cuda:0', dtype=torch.bfloat16)
    arg67_1 = rand_strided((1, 8192, 3), (24576, 3, 1), device='cuda:0', dtype=torch.bfloat16)
    arg68_1 = rand_strided((1, 32, 128, 128), (524288, 16384, 128, 1), device='cuda:0', dtype=torch.float32)
    arg69_1 = rand_strided((4, 1, 32, 128, 128), (524288, 524288, 16384, 128, 1), device='cuda:0', dtype=torch.float32)
    arg70_1 = rand_strided((1, 8192, 7), (57344, 7, 1), device='cuda:0', dtype=torch.bfloat16)
    arg71_1 = rand_strided((1, 8192, 3), (24576, 3, 1), device='cuda:0', dtype=torch.bfloat16)
    arg72_1 = rand_strided((1, 32, 128, 128), (524288, 16384, 128, 1), device='cuda:0', dtype=torch.float32)
    arg73_1 = rand_strided((4, 1, 32, 128, 128), (524288, 524288, 16384, 128, 1), device='cuda:0', dtype=torch.float32)
    arg74_1 = rand_strided((1, 8192, 7), (57344, 7, 1), device='cuda:0', dtype=torch.bfloat16)
    arg75_1 = rand_strided((1, 8192, 3), (24576, 3, 1), device='cuda:0', dtype=torch.bfloat16)
    arg76_1 = rand_strided((1, 32, 128, 128), (524288, 16384, 128, 1), device='cuda:0', dtype=torch.float32)
    arg77_1 = rand_strided((4, 1, 32, 128, 128), (524288, 524288, 16384, 128, 1), device='cuda:0', dtype=torch.float32)
    arg78_1 = rand_strided((1, 8192, 7), (57344, 7, 1), device='cuda:0', dtype=torch.bfloat16)
    arg79_1 = rand_strided((1, 8192, 3), (24576, 3, 1), device='cuda:0', dtype=torch.bfloat16)
    arg80_1 = rand_strided((1, 32, 128, 128), (524288, 16384, 128, 1), device='cuda:0', dtype=torch.float32)
    arg81_1 = rand_strided((4, 1, 32, 128, 128), (524288, 524288, 16384, 128, 1), device='cuda:0', dtype=torch.float32)
    arg82_1 = rand_strided((1, 8192, 7), (57344, 7, 1), device='cuda:0', dtype=torch.bfloat16)
    arg83_1 = rand_strided((1, 8192, 3), (24576, 3, 1), device='cuda:0', dtype=torch.bfloat16)
    arg84_1 = rand_strided((1, 32, 128, 128), (524288, 16384, 128, 1), device='cuda:0', dtype=torch.float32)
    arg85_1 = rand_strided((4, 1, 32, 128, 128), (524288, 524288, 16384, 128, 1), device='cuda:0', dtype=torch.float32)
    arg86_1 = rand_strided((1, 8192, 7), (57344, 7, 1), device='cuda:0', dtype=torch.bfloat16)
    arg87_1 = rand_strided((1, 8192, 3), (24576, 3, 1), device='cuda:0', dtype=torch.bfloat16)
    arg88_1 = rand_strided((1, 32, 128, 128), (524288, 16384, 128, 1), device='cuda:0', dtype=torch.float32)
    arg89_1 = rand_strided((4, 1, 32, 128, 128), (524288, 524288, 16384, 128, 1), device='cuda:0', dtype=torch.float32)
    arg90_1 = rand_strided((1, 8192, 7), (57344, 7, 1), device='cuda:0', dtype=torch.bfloat16)
    arg91_1 = rand_strided((1, 8192, 3), (24576, 3, 1), device='cuda:0', dtype=torch.bfloat16)
    arg92_1 = rand_strided((1, 32, 128, 128), (524288, 16384, 128, 1), device='cuda:0', dtype=torch.float32)
    arg93_1 = rand_strided((4, 1, 32, 128, 128), (524288, 524288, 16384, 128, 1), device='cuda:0', dtype=torch.float32)
    arg94_1 = rand_strided((1, 8192, 7), (57344, 7, 1), device='cuda:0', dtype=torch.bfloat16)
    arg95_1 = rand_strided((1, 8192, 3), (24576, 3, 1), device='cuda:0', dtype=torch.bfloat16)
    arg96_1 = rand_strided((1, 32, 128, 128), (524288, 16384, 128, 1), device='cuda:0', dtype=torch.float32)
    arg97_1 = rand_strided((4, 1, 32, 128, 128), (524288, 524288, 16384, 128, 1), device='cuda:0', dtype=torch.float32)
    arg98_1 = rand_strided((1, 8192, 7), (57344, 7, 1), device='cuda:0', dtype=torch.bfloat16)
    arg99_1 = rand_strided((1, 8192, 3), (24576, 3, 1), device='cuda:0', dtype=torch.bfloat16)
    arg100_1 = rand_strided((1, 32, 128, 128), (524288, 16384, 128, 1), device='cuda:0', dtype=torch.float32)
    arg101_1 = rand_strided((4, 1, 32, 128, 128), (524288, 524288, 16384, 128, 1), device='cuda:0', dtype=torch.float32)
    arg102_1 = rand_strided((1, 8192, 7), (57344, 7, 1), device='cuda:0', dtype=torch.bfloat16)
    arg103_1 = rand_strided((1, 8192, 3), (24576, 3, 1), device='cuda:0', dtype=torch.bfloat16)
    arg104_1 = rand_strided((1, 32, 128, 128), (524288, 16384, 128, 1), device='cuda:0', dtype=torch.float32)
    arg105_1 = rand_strided((4, 1, 32, 128, 128), (524288, 524288, 16384, 128, 1), device='cuda:0', dtype=torch.float32)
    arg106_1 = rand_strided((1, 8192, 7), (57344, 7, 1), device='cuda:0', dtype=torch.bfloat16)
    arg107_1 = rand_strided((1, 8192, 3), (24576, 3, 1), device='cuda:0', dtype=torch.bfloat16)
    arg108_1 = rand_strided((1, 32, 128, 128), (524288, 16384, 128, 1), device='cuda:0', dtype=torch.float32)
    arg109_1 = rand_strided((4, 1, 32, 128, 128), (524288, 524288, 16384, 128, 1), device='cuda:0', dtype=torch.float32)
    arg110_1 = rand_strided((1, 8192, 7), (57344, 7, 1), device='cuda:0', dtype=torch.bfloat16)
    arg111_1 = rand_strided((1, 8192, 3), (24576, 3, 1), device='cuda:0', dtype=torch.bfloat16)
    arg112_1 = rand_strided((1, 32, 128, 128), (524288, 16384, 128, 1), device='cuda:0', dtype=torch.float32)
    arg113_1 = rand_strided((4, 1, 32, 128, 128), (524288, 524288, 16384, 128, 1), device='cuda:0', dtype=torch.float32)
    arg114_1 = rand_strided((1, 8192, 7), (57344, 7, 1), device='cuda:0', dtype=torch.bfloat16)
    arg115_1 = rand_strided((1, 8192, 3), (24576, 3, 1), device='cuda:0', dtype=torch.bfloat16)
    arg116_1 = rand_strided((1, 32, 128, 128), (524288, 16384, 128, 1), device='cuda:0', dtype=torch.float32)
    arg117_1 = rand_strided((4, 1, 32, 128, 128), (524288, 524288, 16384, 128, 1), device='cuda:0', dtype=torch.float32)
    arg118_1 = rand_strided((1, 8192, 7), (57344, 7, 1), device='cuda:0', dtype=torch.bfloat16)
    arg119_1 = rand_strided((1, 8192, 3), (24576, 3, 1), device='cuda:0', dtype=torch.bfloat16)
    arg120_1 = rand_strided((1, 32, 128, 128), (524288, 16384, 128, 1), device='cuda:0', dtype=torch.float32)
    arg121_1 = rand_strided((4, 1, 32, 128, 128), (524288, 524288, 16384, 128, 1), device='cuda:0', dtype=torch.float32)
    arg122_1 = rand_strided((1, ), (1, ), device='cuda:0', dtype=torch.int64)
    return [arg0_1, arg1_1, arg2_1, arg3_1, arg4_1, arg5_1, arg6_1, arg7_1, arg8_1, arg9_1, arg10_1, arg11_1, arg12_1, arg13_1, arg14_1, arg15_1, arg16_1, arg17_1, arg18_1, arg19_1, arg20_1, arg21_1, arg22_1, arg23_1, arg24_1, arg25_1, arg26_1, arg27_1, arg28_1, arg29_1, arg30_1, arg31_1, arg32_1, arg33_1, arg34_1, arg35_1, arg36_1, arg37_1, arg38_1, arg39_1, arg40_1, arg41_1, arg42_1, arg43_1, arg44_1, arg45_1, arg46_1, arg47_1, arg48_1, arg49_1, arg50_1, arg51_1, arg52_1, arg53_1, arg54_1, arg55_1, arg56_1, arg57_1, arg58_1, arg59_1, arg60_1, arg61_1, arg62_1, arg63_1, arg64_1, arg65_1, arg66_1, arg67_1, arg68_1, arg69_1, arg70_1, arg71_1, arg72_1, arg73_1, arg74_1, arg75_1, arg76_1, arg77_1, arg78_1, arg79_1, arg80_1, arg81_1, arg82_1, arg83_1, arg84_1, arg85_1, arg86_1, arg87_1, arg88_1, arg89_1, arg90_1, arg91_1, arg92_1, arg93_1, arg94_1, arg95_1, arg96_1, arg97_1, arg98_1, arg99_1, arg100_1, arg101_1, arg102_1, arg103_1, arg104_1, arg105_1, arg106_1, arg107_1, arg108_1, arg109_1, arg110_1, arg111_1, arg112_1, arg113_1, arg114_1, arg115_1, arg116_1, arg117_1, arg118_1, arg119_1, arg120_1, arg121_1, arg122_1]


def benchmark_compiled_module(args, times=10, repeat=10):
    from torch._inductor.utils import print_performance
    fn = lambda: call(list(args))
    return print_performance(fn, times=times, repeat=repeat)


if __name__ == "__main__":
    from torch._inductor.wrapper_benchmark import compiled_module_main
    args = get_args()
    compiled_module_main('None', lambda times, repeat: benchmark_compiled_module(args, times=times, repeat=repeat))
