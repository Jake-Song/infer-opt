
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.persistent_reduction(
    size_hints={'x': 1, 'r0_': 2048},
    reduction_hint=ReductionHint.INNER,
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*i64', 'in_ptr1': '*i64', 'in_ptr2': '*i64', 'in_ptr3': '*fp32', 'in_ptr4': '*fp32', 'in_ptr5': '*bf16', 'in_ptr6': '*bf16', 'out_ptr0': '*i64', 'out_ptr1': '*i64', 'out_ptr2': '*i64', 'out_ptr4': '*i64', 'out_ptr6': '*bf16', 'xnumel': 'constexpr', 'r0_numel': 'i32', 'XBLOCK': 'constexpr'}, 'device': DeviceProperties(type='cuda', index=0, multi_processor_count=108, cc=80, major=8, regs_per_multiprocessor=65536, max_threads_per_multi_processor=2048, max_threads_per_block=1024, warp_size=32), 'constants': {'xnumel': 1}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]], (3,): [['tt.divisibility', 16]], (4,): [['tt.divisibility', 16]], (5,): [['tt.divisibility', 16]], (6,): [['tt.divisibility', 16]], (7,): [['tt.divisibility', 16]], (8,): [['tt.divisibility', 16]], (9,): [['tt.divisibility', 16]], (10,): [['tt.divisibility', 16]], (11,): [['tt.divisibility', 16]], (13,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'autotune_hints': set(), 'kernel_name': 'triton_per_fused__to_copy_add_copy__index_select_mean_mul_pow_rsqrt_sub_sum_view_41', 'mutated_arg_names': ['in_ptr2', 'out_ptr4'], 'optimize_mem': True, 'no_x_dim': None, 'atomic_add_found': False, 'num_load': 7, 'num_store': 5, 'num_reduction': 1, 'backend_hash': 'F7205DDDCE8E401A1728E5D602D369DE155D3FCCD3ACF038A9886E6E0DD93A54', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'max_autotune': True, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': False, 'are_deterministic_algorithms_enabled': False, 'coordinate_descent_tuning': True, 'coordinate_descent_search_radius': 1, 'coordinate_descent_check_all_directions': False, 'tiling_scores': {'r0_': 16384}}
)
@triton.jit
def triton_per_fused__to_copy_add_copy__index_select_mean_mul_pow_rsqrt_sub_sum_view_41(in_ptr0, in_ptr1, in_ptr2, in_ptr3, in_ptr4, in_ptr5, in_ptr6, out_ptr0, out_ptr1, out_ptr2, out_ptr4, out_ptr6, xnumel, r0_numel, XBLOCK : tl.constexpr):
    xnumel = 1
    r0_numel = 2048
    R0_BLOCK: tl.constexpr = 2048
    rnumel = r0_numel
    RBLOCK: tl.constexpr = R0_BLOCK
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:, None]
    xmask = tl.full([XBLOCK], True, tl.int1)[:, None]
    r0_index = tl.arange(0, R0_BLOCK)[None, :]
    r0_offset = 0
    r0_mask = tl.full([R0_BLOCK], True, tl.int1)[None, :]
    roffset = r0_offset
    rindex = r0_index
    r0_0 = r0_index
    tmp0 = tl.load(in_ptr0 + (0))
    tmp1 = tl.broadcast_to(tmp0, [1, 1])
    tmp2 = tl.load(in_ptr0 + (1))
    tmp3 = tl.broadcast_to(tmp2, [1, 1])
    tmp5 = tl.load(in_ptr0 + (2))
    tmp6 = tl.broadcast_to(tmp5, [1, 1])
    tmp10 = tl.load(in_ptr1 + (0))
    tmp11 = tl.broadcast_to(tmp10, [1, 1])
    tmp14 = tl.load(in_ptr2 + (0))
    tmp15 = tl.broadcast_to(tmp14, [1, 1])
    tmp31 = tl.load(in_ptr5 + (r0_0), None).to(tl.float32)
    tmp46 = tl.load(in_ptr6 + (r0_0), None).to(tl.float32)
    tmp4 = tmp1 + tmp3
    tmp7 = tmp4 + tmp6
    tmp8 = tl.full([1, 1], 1, tl.int64)
    tmp9 = tmp7 + tmp8
    tmp12 = tmp11 + tmp9
    tmp13 = tmp12 + tmp8
    tmp16 = tmp15 + tmp9
    tmp17 = tmp9 - tmp8
    tmp18 = tl.full([1, 1], 4, tl.int32)
    tmp19 = tmp17 + tmp18
    tmp20 = tmp17 < 0
    tmp21 = tl.where(tmp20, tmp19, tmp17)
    tl.device_assert((0 <= tmp21) & (tmp21 < 4), "index out of bounds: 0 <= tmp21 < 4")
    tmp23 = tl.load(in_ptr3 + (r0_0 + 2048*tmp21), None)
    tmp24 = tl.load(in_ptr4 + (tmp21), None, eviction_policy='evict_last')
    tmp25 = tl.full([1, 1], 2048.0, tl.float32)
    tmp26 = (tmp24 / tmp25)
    tmp27 = tl.full([1, 1], 1e-06, tl.float32)
    tmp28 = tmp26 + tmp27
    tmp29 = libdevice.rsqrt(tmp28)
    tmp30 = tmp23 * tmp29
    tmp32 = tmp31.to(tl.float32)
    tmp33 = tl.full([1, 1], 1.0, tl.float32)
    tmp34 = tmp32 + tmp33
    tmp35 = tmp30 * tmp34
    tmp36 = tmp35.to(tl.float32)
    tmp37 = tmp36.to(tl.float32)
    tmp38 = tmp37 * tmp37
    tmp39 = tl.broadcast_to(tmp38, [XBLOCK, R0_BLOCK])
    tmp41 = tl.sum(tmp39, 1)[:, None].to(tl.float32)
    tmp42 = (tmp41 / tmp25)
    tmp43 = tmp42 + tmp27
    tmp44 = libdevice.rsqrt(tmp43)
    tmp45 = tmp37 * tmp44
    tmp47 = tmp46.to(tl.float32)
    tmp48 = tmp47 + tmp33
    tmp49 = tmp45 * tmp48
    tmp50 = tmp49.to(tl.float32)
    tl.store(out_ptr0 + (tl.full([1, 1], 0, tl.int32)), tmp9, None)
    tl.store(out_ptr1 + (tl.full([1, 1], 0, tl.int32)), tmp12, None)
    tl.store(out_ptr2 + (tl.full([1, 1], 0, tl.int32)), tmp13, None)
    tl.store(out_ptr4 + (tl.full([1, 1], 0, tl.int32)), tmp16, None)
    tl.store(out_ptr6 + (tl.broadcast_to(r0_0, [XBLOCK, R0_BLOCK])), tmp50, None)
