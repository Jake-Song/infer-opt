
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.pointwise(
    size_hints={'x': 32}, 
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*i64', 'in_ptr1': '*bf16', 'out_ptr0': '*fp32', 'out_ptr1': '*fp32', 'xnumel': 'i32', 'XBLOCK': 'constexpr'}, 'device': DeviceProperties(type='cuda', index=0, multi_processor_count=108, cc=80, major=8, regs_per_multiprocessor=65536, max_threads_per_multi_processor=2048, max_threads_per_block=1024, warp_size=32), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]], (3,): [['tt.divisibility', 16]], (4,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'autotune_hints': set(), 'kernel_name': 'triton_poi_fused__to_copy_add_arange_cos_expand_mul_select_sin_slice_unsqueeze_view_4', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 8, 'num_store': 2, 'num_reduction': 0, 'backend_hash': 'F7205DDDCE8E401A1728E5D602D369DE155D3FCCD3ACF038A9886E6E0DD93A54', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'max_autotune': True, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': False, 'are_deterministic_algorithms_enabled': False, 'coordinate_descent_tuning': True, 'coordinate_descent_search_radius': 1, 'coordinate_descent_check_all_directions': False, 'tiling_scores': {'x': 704}},
    min_elem_per_thread=0
)
@triton.jit
def triton_poi_fused__to_copy_add_arange_cos_expand_mul_select_sin_slice_unsqueeze_view_4(in_ptr0, in_ptr1, out_ptr0, out_ptr1, xnumel, XBLOCK : tl.constexpr):
    xnumel = 32
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:]
    xmask = xindex < xnumel
    x0 = xindex
    tmp64 = tl.load(in_ptr0 + (0))
    tmp65 = tl.broadcast_to(tmp64, [XBLOCK])
    tmp68 = tl.load(in_ptr1 + (x0), xmask).to(tl.float32)
    tmp0 = x0
    tmp1 = tl.full([1], 2, tl.int64)
    tmp2 = tmp0 >= tmp1
    tmp3 = tl.full([1], 30, tl.int64)
    tmp4 = tmp0 < tmp3
    tmp5 = (((-2) + x0) % 3)
    tmp6 = tl.full([1], 0, tl.int64)
    tmp7 = tmp5 == tmp6
    tmp8 = tmp2 & tmp4
    tmp9 = tmp8 & tmp7
    tmp10 = tl.full([1], 2, tl.int32)
    tmp11 = tl.full([1], 0, tl.int32)
    tmp12 = tmp10 == tmp11
    tmp13 = 2 + 3*(triton_helpers.div_floor_integer((-2) + x0,  3))
    tmp14 = tl.full([1], 1, tl.int64)
    tmp15 = tmp13 >= tmp14
    tmp16 = tl.full([1], 0, tl.int64)
    tmp17 = tmp14 == tmp16
    tmp18 = tmp15 & tmp17
    tmp19 = tmp18 & tmp9
    tmp20 = tl.load(in_ptr0 + (0))
    tmp21 = tl.broadcast_to(tmp20, [XBLOCK])
    tmp22 = tl.where(tmp19, tmp21, 0)
    tmp23 = tl.full([1], 0, tl.int64)
    tmp24 = tmp23 + tmp22
    tmp25 = tmp24.to(tl.float32)
    tmp26 = tl.load(in_ptr1 + (1 + 3*(triton_helpers.div_floor_integer((-2) + x0,  3))), tmp19 & xmask, eviction_policy='evict_last', other=0.0).to(tl.float32)
    tmp27 = tmp26.to(tl.float32)
    tmp28 = tmp25 * tmp27
    tmp29 = tl_math.cos(tmp28)
    tmp30 = tl.full(tmp29.shape, 0.0, tmp29.dtype)
    tmp31 = tl.where(tmp19, tmp29, tmp30)
    tmp32 = tl.load(in_ptr0 + (0))
    tmp33 = tl.broadcast_to(tmp32, [XBLOCK])
    tmp34 = tl.where(tmp9, tmp33, 0)
    tmp35 = tmp16 + tmp34
    tmp36 = tmp35.to(tl.float32)
    tmp37 = tl.load(in_ptr1 + (2 + 3*(triton_helpers.div_floor_integer((-2) + x0,  3))), tmp9 & xmask, eviction_policy='evict_last', other=0.0).to(tl.float32)
    tmp38 = tmp37.to(tl.float32)
    tmp39 = tmp36 * tmp38
    tmp40 = tl_math.cos(tmp39)
    tmp41 = tl.where(tmp18, tmp31, tmp40)
    tmp42 = tl.where(tmp12, tmp41, tmp40)
    tmp43 = tl.full(tmp42.shape, 0.0, tmp42.dtype)
    tmp44 = tl.where(tmp9, tmp42, tmp43)
    tmp45 = tl.full([1], 0, tl.int32)
    tmp46 = tmp45 == tmp45
    tmp47 = tl.full([1], 1, tl.int64)
    tmp48 = tmp0 >= tmp47
    tmp49 = (((-1) + x0) % 3)
    tmp50 = tmp49 == tmp6
    tmp51 = tmp48 & tmp50
    tmp52 = tl.load(in_ptr0 + (0))
    tmp53 = tl.broadcast_to(tmp52, [XBLOCK])
    tmp54 = tl.where(tmp51, tmp53, 0)
    tmp55 = tl.full([1], 0, tl.int64)
    tmp56 = tmp55 + tmp54
    tmp57 = tmp56.to(tl.float32)
    tmp58 = tl.load(in_ptr1 + (1 + 3*(triton_helpers.div_floor_integer((-1) + x0,  3))), tmp51 & xmask, eviction_policy='evict_last', other=0.0).to(tl.float32)
    tmp59 = tmp58.to(tl.float32)
    tmp60 = tmp57 * tmp59
    tmp61 = tl_math.cos(tmp60)
    tmp62 = tl.full(tmp61.shape, 0.0, tmp61.dtype)
    tmp63 = tl.where(tmp51, tmp61, tmp62)
    tmp66 = tmp6 + tmp65
    tmp67 = tmp66.to(tl.float32)
    tmp69 = tmp68.to(tl.float32)
    tmp70 = tmp67 * tmp69
    tmp71 = tl_math.cos(tmp70)
    tmp72 = tl.where(tmp51, tmp63, tmp71)
    tmp73 = tl.where(tmp46, tmp72, tmp71)
    tmp74 = tl.where(tmp9, tmp44, tmp73)
    tmp75 = tl_math.sin(tmp28)
    tmp76 = tl.full(tmp75.shape, 0.0, tmp75.dtype)
    tmp77 = tl.where(tmp19, tmp75, tmp76)
    tmp78 = tl_math.sin(tmp39)
    tmp79 = tl.where(tmp18, tmp77, tmp78)
    tmp80 = tl.where(tmp12, tmp79, tmp78)
    tmp81 = tl.full(tmp80.shape, 0.0, tmp80.dtype)
    tmp82 = tl.where(tmp9, tmp80, tmp81)
    tmp83 = tl_math.sin(tmp60)
    tmp84 = tl.full(tmp83.shape, 0.0, tmp83.dtype)
    tmp85 = tl.where(tmp51, tmp83, tmp84)
    tmp86 = tl_math.sin(tmp70)
    tmp87 = tl.where(tmp51, tmp85, tmp86)
    tmp88 = tl.where(tmp46, tmp87, tmp86)
    tmp89 = tl.where(tmp9, tmp82, tmp88)
    tl.store(out_ptr0 + (x0), tmp74, xmask)
    tl.store(out_ptr1 + (x0), tmp89, xmask)
