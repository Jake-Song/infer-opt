
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.pointwise(
    size_hints={'x': 32}, 
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*i64', 'in_ptr1': '*i64', 'in_ptr2': '*bf16', 'out_ptr0': '*fp32', 'out_ptr1': '*fp32', 'out_ptr2': '*fp32', 'out_ptr3': '*fp32', 'xnumel': 'i32', 'XBLOCK': 'constexpr'}, 'device': DeviceProperties(type='cuda', index=0, multi_processor_count=108, cc=80, major=8, regs_per_multiprocessor=65536, max_threads_per_multi_processor=2048, max_threads_per_block=1024, warp_size=32), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]], (3,): [['tt.divisibility', 16]], (4,): [['tt.divisibility', 16]], (5,): [['tt.divisibility', 16]], (6,): [['tt.divisibility', 16]], (7,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'autotune_hints': set(), 'kernel_name': 'triton_poi_fused__to_copy_add_arange_cos_expand_mul_select_sin_slice_unsqueeze_view_45', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 12, 'num_store': 4, 'num_reduction': 0, 'backend_hash': 'F7205DDDCE8E401A1728E5D602D369DE155D3FCCD3ACF038A9886E6E0DD93A54', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'max_autotune': True, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': False, 'are_deterministic_algorithms_enabled': False, 'coordinate_descent_tuning': True, 'coordinate_descent_search_radius': 1, 'coordinate_descent_check_all_directions': False, 'tiling_scores': {'x': 1216}},
    min_elem_per_thread=0
)
@triton.jit
def triton_poi_fused__to_copy_add_arange_cos_expand_mul_select_sin_slice_unsqueeze_view_45(in_ptr0, in_ptr1, in_ptr2, out_ptr0, out_ptr1, out_ptr2, out_ptr3, xnumel, XBLOCK : tl.constexpr):
    xnumel = 32
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:]
    xmask = xindex < xnumel
    x0 = xindex
    tmp76 = tl.load(in_ptr0 + (0))
    tmp77 = tl.broadcast_to(tmp76, [XBLOCK])
    tmp78 = tl.load(in_ptr1 + (0))
    tmp79 = tl.broadcast_to(tmp78, [XBLOCK])
    tmp83 = tl.load(in_ptr2 + (x0), xmask).to(tl.float32)
    tmp0 = x0
    tmp1 = tl.full([1], 2, tl.int64)
    tmp2 = tmp0 >= tmp1
    tmp3 = tl.full([1], 30, tl.int64)
    tmp4 = tmp0 < tmp3
    tmp5 = (((-2) + x0) % 3)
    tmp6 = tl.full([1], 0, tl.int64)
    tmp7 = tmp5 == tmp6
    tmp8 = tmp2 & tmp4
    tmp9 = tmp8 & tmp7
    tmp10 = tl.full([1], 2, tl.int32)
    tmp11 = tl.full([1], 0, tl.int32)
    tmp12 = tmp10 == tmp11
    tmp13 = 2 + 3*(triton_helpers.div_floor_integer((-2) + x0,  3))
    tmp14 = tl.full([1], 1, tl.int64)
    tmp15 = tmp13 >= tmp14
    tmp16 = tl.full([1], 0, tl.int64)
    tmp17 = tmp14 == tmp16
    tmp18 = tmp15 & tmp17
    tmp19 = tmp18 & tmp9
    tmp20 = tl.load(in_ptr0 + (0))
    tmp21 = tl.broadcast_to(tmp20, [XBLOCK])
    tmp22 = tl.where(tmp19, tmp21, 0)
    tmp23 = tl.load(in_ptr1 + (0))
    tmp24 = tl.broadcast_to(tmp23, [XBLOCK])
    tmp25 = tl.where(tmp19, tmp24, 0)
    tmp26 = tmp22 + tmp25
    tmp27 = tl.full([1], 0, tl.int64)
    tmp28 = tmp27 + tmp26
    tmp29 = tmp28.to(tl.float32)
    tmp30 = tl.load(in_ptr2 + (1 + 3*(triton_helpers.div_floor_integer((-2) + x0,  3))), tmp19 & xmask, eviction_policy='evict_last', other=0.0).to(tl.float32)
    tmp31 = tmp30.to(tl.float32)
    tmp32 = tmp29 * tmp31
    tmp33 = tl_math.cos(tmp32)
    tmp34 = tl.full(tmp33.shape, 0.0, tmp33.dtype)
    tmp35 = tl.where(tmp19, tmp33, tmp34)
    tmp36 = tl.load(in_ptr0 + (0))
    tmp37 = tl.broadcast_to(tmp36, [XBLOCK])
    tmp38 = tl.where(tmp9, tmp37, 0)
    tmp39 = tl.load(in_ptr1 + (0))
    tmp40 = tl.broadcast_to(tmp39, [XBLOCK])
    tmp41 = tl.where(tmp9, tmp40, 0)
    tmp42 = tmp38 + tmp41
    tmp43 = tmp16 + tmp42
    tmp44 = tmp43.to(tl.float32)
    tmp45 = tl.load(in_ptr2 + (2 + 3*(triton_helpers.div_floor_integer((-2) + x0,  3))), tmp9 & xmask, eviction_policy='evict_last', other=0.0).to(tl.float32)
    tmp46 = tmp45.to(tl.float32)
    tmp47 = tmp44 * tmp46
    tmp48 = tl_math.cos(tmp47)
    tmp49 = tl.where(tmp18, tmp35, tmp48)
    tmp50 = tl.where(tmp12, tmp49, tmp48)
    tmp51 = tl.full(tmp50.shape, 0.0, tmp50.dtype)
    tmp52 = tl.where(tmp9, tmp50, tmp51)
    tmp53 = tl.full([1], 0, tl.int32)
    tmp54 = tmp53 == tmp53
    tmp55 = tl.full([1], 1, tl.int64)
    tmp56 = tmp0 >= tmp55
    tmp57 = (((-1) + x0) % 3)
    tmp58 = tmp57 == tmp6
    tmp59 = tmp56 & tmp58
    tmp60 = tl.load(in_ptr0 + (0))
    tmp61 = tl.broadcast_to(tmp60, [XBLOCK])
    tmp62 = tl.where(tmp59, tmp61, 0)
    tmp63 = tl.load(in_ptr1 + (0))
    tmp64 = tl.broadcast_to(tmp63, [XBLOCK])
    tmp65 = tl.where(tmp59, tmp64, 0)
    tmp66 = tmp62 + tmp65
    tmp67 = tl.full([1], 0, tl.int64)
    tmp68 = tmp67 + tmp66
    tmp69 = tmp68.to(tl.float32)
    tmp70 = tl.load(in_ptr2 + (1 + 3*(triton_helpers.div_floor_integer((-1) + x0,  3))), tmp59 & xmask, eviction_policy='evict_last', other=0.0).to(tl.float32)
    tmp71 = tmp70.to(tl.float32)
    tmp72 = tmp69 * tmp71
    tmp73 = tl_math.cos(tmp72)
    tmp74 = tl.full(tmp73.shape, 0.0, tmp73.dtype)
    tmp75 = tl.where(tmp59, tmp73, tmp74)
    tmp80 = tmp77 + tmp79
    tmp81 = tmp6 + tmp80
    tmp82 = tmp81.to(tl.float32)
    tmp84 = tmp83.to(tl.float32)
    tmp85 = tmp82 * tmp84
    tmp86 = tl_math.cos(tmp85)
    tmp87 = tl.where(tmp59, tmp75, tmp86)
    tmp88 = tl.where(tmp54, tmp87, tmp86)
    tmp89 = tl.where(tmp9, tmp52, tmp88)
    tmp90 = tl_math.sin(tmp32)
    tmp91 = tl.full(tmp90.shape, 0.0, tmp90.dtype)
    tmp92 = tl.where(tmp19, tmp90, tmp91)
    tmp93 = tl_math.sin(tmp47)
    tmp94 = tl.where(tmp18, tmp92, tmp93)
    tmp95 = tl.where(tmp12, tmp94, tmp93)
    tmp96 = tl.full(tmp95.shape, 0.0, tmp95.dtype)
    tmp97 = tl.where(tmp9, tmp95, tmp96)
    tmp98 = tl_math.sin(tmp72)
    tmp99 = tl.full(tmp98.shape, 0.0, tmp98.dtype)
    tmp100 = tl.where(tmp59, tmp98, tmp99)
    tmp101 = tl_math.sin(tmp85)
    tmp102 = tl.where(tmp59, tmp100, tmp101)
    tmp103 = tl.where(tmp54, tmp102, tmp101)
    tmp104 = tl.where(tmp9, tmp97, tmp103)
    tmp105 = tl.full([1], 1, tl.int64)
    tmp106 = tmp26 + tmp105
    tmp107 = tmp27 + tmp106
    tmp108 = tmp107.to(tl.float32)
    tmp109 = tmp108 * tmp31
    tmp110 = tl_math.cos(tmp109)
    tmp111 = tl.full(tmp110.shape, 0.0, tmp110.dtype)
    tmp112 = tl.where(tmp19, tmp110, tmp111)
    tmp113 = tmp42 + tmp14
    tmp114 = tmp16 + tmp113
    tmp115 = tmp114.to(tl.float32)
    tmp116 = tmp115 * tmp46
    tmp117 = tl_math.cos(tmp116)
    tmp118 = tl.where(tmp18, tmp112, tmp117)
    tmp119 = tl.where(tmp12, tmp118, tmp117)
    tmp120 = tl.full(tmp119.shape, 0.0, tmp119.dtype)
    tmp121 = tl.where(tmp9, tmp119, tmp120)
    tmp122 = tl.full([1], 1, tl.int64)
    tmp123 = tmp66 + tmp122
    tmp124 = tmp67 + tmp123
    tmp125 = tmp124.to(tl.float32)
    tmp126 = tmp125 * tmp71
    tmp127 = tl_math.cos(tmp126)
    tmp128 = tl.full(tmp127.shape, 0.0, tmp127.dtype)
    tmp129 = tl.where(tmp59, tmp127, tmp128)
    tmp130 = tmp80 + tmp55
    tmp131 = tmp6 + tmp130
    tmp132 = tmp131.to(tl.float32)
    tmp133 = tmp132 * tmp84
    tmp134 = tl_math.cos(tmp133)
    tmp135 = tl.where(tmp59, tmp129, tmp134)
    tmp136 = tl.where(tmp54, tmp135, tmp134)
    tmp137 = tl.where(tmp9, tmp121, tmp136)
    tmp138 = tl_math.sin(tmp109)
    tmp139 = tl.full(tmp138.shape, 0.0, tmp138.dtype)
    tmp140 = tl.where(tmp19, tmp138, tmp139)
    tmp141 = tl_math.sin(tmp116)
    tmp142 = tl.where(tmp18, tmp140, tmp141)
    tmp143 = tl.where(tmp12, tmp142, tmp141)
    tmp144 = tl.full(tmp143.shape, 0.0, tmp143.dtype)
    tmp145 = tl.where(tmp9, tmp143, tmp144)
    tmp146 = tl_math.sin(tmp126)
    tmp147 = tl.full(tmp146.shape, 0.0, tmp146.dtype)
    tmp148 = tl.where(tmp59, tmp146, tmp147)
    tmp149 = tl_math.sin(tmp133)
    tmp150 = tl.where(tmp59, tmp148, tmp149)
    tmp151 = tl.where(tmp54, tmp150, tmp149)
    tmp152 = tl.where(tmp9, tmp145, tmp151)
    tl.store(out_ptr0 + (x0), tmp89, xmask)
    tl.store(out_ptr1 + (x0), tmp104, xmask)
    tl.store(out_ptr2 + (x0), tmp137, xmask)
    tl.store(out_ptr3 + (x0), tmp152, xmask)
