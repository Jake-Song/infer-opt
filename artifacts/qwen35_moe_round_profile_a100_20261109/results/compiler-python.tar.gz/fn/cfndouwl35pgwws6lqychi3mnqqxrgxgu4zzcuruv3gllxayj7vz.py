

import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties

@triton_heuristics.user_autotune(
    configs=[{'num_warps': 4, 'num_stages': 3}],
    inductor_meta={'grid_type': 'FixedGrid', 'fixed_grid': ['_grid_0', '_grid_1', '_grid_2'], 'extra_launcher_args': ['_grid_0', '_grid_1', '_grid_2'], 'kernel_name': '_decode_attention_kernel_9', 'backend_hash': 'F7205DDDCE8E401A1728E5D602D369DE155D3FCCD3ACF038A9886E6E0DD93A54', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'max_autotune': True, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': False, 'are_deterministic_algorithms_enabled': False, 'coordinate_descent_tuning': True, 'coordinate_descent_search_radius': 1, 'coordinate_descent_check_all_directions': False},
    triton_meta={'signature': {'q_ptr': '*bf16', 'k_ptr': '*bf16', 'v_ptr': '*bf16', 'pos_ptr': '*i64', 'm_ptr': '*fp32', 'l_ptr': '*fp32', 'o_ptr': '*fp32', 'L': 'i32', 'scale': 'fp64', 'G': 'constexpr', 'G_PAD': 'constexpr', 'T': 'constexpr', 'D': 'constexpr', 'CHUNK': 'constexpr'}, 'device': DeviceProperties(type='cuda', index=0, multi_processor_count=108, cc=80, major=8, regs_per_multiprocessor=65536, max_threads_per_multi_processor=2048, max_threads_per_block=1024, warp_size=32), 'constants': {'G': 8, 'G_PAD': 16, 'T': 1, 'D': 256, 'CHUNK': 64}, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]], (3,): [['tt.divisibility', 16]], (4,): [['tt.divisibility', 16]], (5,): [['tt.divisibility', 16]], (6,): [['tt.divisibility', 16]], (7,): [['tt.divisibility', 16]]}]},
    filename=__file__,
    custom_kernel=True,
)
@triton.jit
def _decode_attention_kernel(q_ptr, k_ptr, v_ptr, pos_ptr, m_ptr, l_ptr, o_ptr, L, scale,
                             G: tl.constexpr, G_PAD: tl.constexpr, T: tl.constexpr, D: tl.constexpr,
                             CHUNK: tl.constexpr):
    head = tl.program_id(0)  # batch * KV heads
    split = tl.program_id(1)
    n_split = tl.num_programs(1)
    g = tl.arange(0, G_PAD)
    d = tl.arange(0, D)
    keys = split * CHUNK + tl.arange(0, CHUNK)
    position = tl.load(pos_ptr)
    part = (head * n_split + split) * G + g  # row of this (head, split, query head) in the partial buffers
    g_ok = g < G
    if split * CHUNK > position + T - 1:  # nothing filled in this slice
        tl.store(m_ptr + part, tl.full((G_PAD,), float("-inf"), tl.float32), mask=g_ok)
        tl.store(l_ptr + part, tl.zeros((G_PAD,), tl.float32), mask=g_ok)
        tl.store(o_ptr + part[:, None] * D + d[None, :], tl.zeros((G_PAD, D), tl.float32), mask=g_ok[:, None])
        return
    q = tl.load(q_ptr + (head * G + g)[:, None] * D + d[None, :], mask=g_ok[:, None], other=0.0)
    kv_ok = (keys < L)[:, None]
    kv_off = (head.to(tl.int64) * L + keys)[:, None] * D + d[None, :]
    k = tl.load(k_ptr + kv_off, mask=kv_ok, other=0.0)
    scores = tl.dot(q, tl.trans(k)) * scale  # [G_PAD, CHUNK], fp32
    if T == 1:
        scores = tl.where((keys <= position)[None, :], scores, float("-inf"))
        m = tl.max(scores, axis=1)
        p = tl.exp(scores - m[:, None])
    else:
        scores = tl.where(keys[None, :] <= (position + g % T)[:, None], scores, float("-inf"))
        m = tl.max(scores, axis=1)
        p = tl.exp(scores - tl.where(m == float("-inf"), 0.0, m)[:, None])  # rows with no key here: p = 0
    v = tl.load(v_ptr + kv_off, mask=kv_ok, other=0.0)
    o = tl.dot(p.to(v.dtype), v)  # [G_PAD, D], fp32
    tl.store(m_ptr + part, m, mask=g_ok)
    tl.store(l_ptr + part, tl.sum(p, axis=1), mask=g_ok)
    tl.store(o_ptr + part[:, None] * D + d[None, :], o, mask=g_ok[:, None])
