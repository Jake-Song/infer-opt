
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.pointwise(
    size_hints={'x': 32}, 
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*i64', 'in_ptr1': '*bf16', 'out_ptr0': '*fp32', 'out_ptr1': '*fp32', 'xnumel': 'i32', 'XBLOCK': 'constexpr'}, 'device': DeviceProperties(type='cuda', index=0, multi_processor_count=108, cc=80, major=8, regs_per_multiprocessor=65536, max_threads_per_multi_processor=2048, max_threads_per_block=1024, warp_size=32), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]], (3,): [['tt.divisibility', 16]], (4,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'autotune_hints': set(), 'kernel_name': 'triton_poi_fused__to_copy_cos_expand_mul_select_sin_slice_unsqueeze_view_0', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 8, 'num_store': 2, 'num_reduction': 0, 'backend_hash': 'F7205DDDCE8E401A1728E5D602D369DE155D3FCCD3ACF038A9886E6E0DD93A54', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'max_autotune': True, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': False, 'are_deterministic_algorithms_enabled': False, 'coordinate_descent_tuning': True, 'coordinate_descent_search_radius': 1, 'coordinate_descent_check_all_directions': False, 'tiling_scores': {'x': 704}},
    min_elem_per_thread=0
)
@triton.jit
def triton_poi_fused__to_copy_cos_expand_mul_select_sin_slice_unsqueeze_view_0(in_ptr0, in_ptr1, out_ptr0, out_ptr1, xnumel, XBLOCK : tl.constexpr):
    xnumel = 32
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:]
    xmask = xindex < xnumel
    x0 = xindex
    tmp59 = tl.load(in_ptr0 + (0))
    tmp60 = tl.broadcast_to(tmp59, [XBLOCK])
    tmp62 = tl.load(in_ptr1 + (x0), xmask).to(tl.float32)
    tmp0 = x0
    tmp1 = tl.full([1], 2, tl.int64)
    tmp2 = tmp0 >= tmp1
    tmp3 = tl.full([1], 30, tl.int64)
    tmp4 = tmp0 < tmp3
    tmp5 = (((-2) + x0) % 3)
    tmp6 = tl.full([1], 0, tl.int64)
    tmp7 = tmp5 == tmp6
    tmp8 = tmp2 & tmp4
    tmp9 = tmp8 & tmp7
    tmp10 = tl.full([1], 2, tl.int32)
    tmp11 = tl.full([1], 0, tl.int32)
    tmp12 = tmp10 == tmp11
    tmp13 = 2 + 3*(triton_helpers.div_floor_integer((-2) + x0,  3))
    tmp14 = tl.full([1], 1, tl.int64)
    tmp15 = tmp13 >= tmp14
    tmp16 = tl.full([1], 0, tl.int64)
    tmp17 = tmp14 == tmp16
    tmp18 = tmp15 & tmp17
    tmp19 = tmp18 & tmp9
    tmp20 = tl.load(in_ptr0 + (0))
    tmp21 = tl.broadcast_to(tmp20, [XBLOCK])
    tmp22 = tl.where(tmp19, tmp21, 0)
    tmp23 = tmp22.to(tl.float32)
    tmp24 = tl.load(in_ptr1 + (1 + 3*(triton_helpers.div_floor_integer((-2) + x0,  3))), tmp19 & xmask, eviction_policy='evict_last', other=0.0).to(tl.float32)
    tmp25 = tmp24.to(tl.float32)
    tmp26 = tmp23 * tmp25
    tmp27 = tl_math.cos(tmp26)
    tmp28 = tl.full(tmp27.shape, 0.0, tmp27.dtype)
    tmp29 = tl.where(tmp19, tmp27, tmp28)
    tmp30 = tl.load(in_ptr0 + (0))
    tmp31 = tl.broadcast_to(tmp30, [XBLOCK])
    tmp32 = tl.where(tmp9, tmp31, 0)
    tmp33 = tmp32.to(tl.float32)
    tmp34 = tl.load(in_ptr1 + (2 + 3*(triton_helpers.div_floor_integer((-2) + x0,  3))), tmp9 & xmask, eviction_policy='evict_last', other=0.0).to(tl.float32)
    tmp35 = tmp34.to(tl.float32)
    tmp36 = tmp33 * tmp35
    tmp37 = tl_math.cos(tmp36)
    tmp38 = tl.where(tmp18, tmp29, tmp37)
    tmp39 = tl.where(tmp12, tmp38, tmp37)
    tmp40 = tl.full(tmp39.shape, 0.0, tmp39.dtype)
    tmp41 = tl.where(tmp9, tmp39, tmp40)
    tmp42 = tl.full([1], 0, tl.int32)
    tmp43 = tmp42 == tmp42
    tmp44 = tl.full([1], 1, tl.int64)
    tmp45 = tmp0 >= tmp44
    tmp46 = (((-1) + x0) % 3)
    tmp47 = tmp46 == tmp6
    tmp48 = tmp45 & tmp47
    tmp49 = tl.load(in_ptr0 + (0))
    tmp50 = tl.broadcast_to(tmp49, [XBLOCK])
    tmp51 = tl.where(tmp48, tmp50, 0)
    tmp52 = tmp51.to(tl.float32)
    tmp53 = tl.load(in_ptr1 + (1 + 3*(triton_helpers.div_floor_integer((-1) + x0,  3))), tmp48 & xmask, eviction_policy='evict_last', other=0.0).to(tl.float32)
    tmp54 = tmp53.to(tl.float32)
    tmp55 = tmp52 * tmp54
    tmp56 = tl_math.cos(tmp55)
    tmp57 = tl.full(tmp56.shape, 0.0, tmp56.dtype)
    tmp58 = tl.where(tmp48, tmp56, tmp57)
    tmp61 = tmp60.to(tl.float32)
    tmp63 = tmp62.to(tl.float32)
    tmp64 = tmp61 * tmp63
    tmp65 = tl_math.cos(tmp64)
    tmp66 = tl.where(tmp48, tmp58, tmp65)
    tmp67 = tl.where(tmp43, tmp66, tmp65)
    tmp68 = tl.where(tmp9, tmp41, tmp67)
    tmp69 = tl_math.sin(tmp26)
    tmp70 = tl.full(tmp69.shape, 0.0, tmp69.dtype)
    tmp71 = tl.where(tmp19, tmp69, tmp70)
    tmp72 = tl_math.sin(tmp36)
    tmp73 = tl.where(tmp18, tmp71, tmp72)
    tmp74 = tl.where(tmp12, tmp73, tmp72)
    tmp75 = tl.full(tmp74.shape, 0.0, tmp74.dtype)
    tmp76 = tl.where(tmp9, tmp74, tmp75)
    tmp77 = tl_math.sin(tmp55)
    tmp78 = tl.full(tmp77.shape, 0.0, tmp77.dtype)
    tmp79 = tl.where(tmp48, tmp77, tmp78)
    tmp80 = tl_math.sin(tmp64)
    tmp81 = tl.where(tmp48, tmp79, tmp80)
    tmp82 = tl.where(tmp43, tmp81, tmp80)
    tmp83 = tl.where(tmp9, tmp76, tmp82)
    tl.store(out_ptr0 + (x0), tmp68, xmask)
    tl.store(out_ptr1 + (x0), tmp83, xmask)
