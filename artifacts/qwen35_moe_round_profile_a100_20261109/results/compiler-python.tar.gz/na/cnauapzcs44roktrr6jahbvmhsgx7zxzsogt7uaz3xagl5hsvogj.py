
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.pointwise(
    size_hints={'x': 32768}, 
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*bf16', 'in_ptr1': '*bf16', 'in_ptr2': '*bf16', 'out_ptr0': '*fp32', 'xnumel': 'i32', 'XBLOCK': 'constexpr'}, 'device': DeviceProperties(type='cuda', index=0, multi_processor_count=108, cc=80, major=8, regs_per_multiprocessor=65536, max_threads_per_multi_processor=2048, max_threads_per_block=1024, warp_size=32), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]], (3,): [['tt.divisibility', 16]], (4,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'autotune_hints': set(), 'kernel_name': 'triton_poi_fused__to_copy_cat_mul_split_with_sizes_squeeze_sum_transpose_unfold_unsqueeze_1', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 12, 'num_store': 1, 'num_reduction': 0, 'backend_hash': 'F7205DDDCE8E401A1728E5D602D369DE155D3FCCD3ACF038A9886E6E0DD93A54', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'max_autotune': True, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': False, 'are_deterministic_algorithms_enabled': False, 'coordinate_descent_tuning': True, 'coordinate_descent_search_radius': 1, 'coordinate_descent_check_all_directions': False, 'tiling_scores': {'x': 458752}},
    min_elem_per_thread=0
)
@triton.jit
def triton_poi_fused__to_copy_cat_mul_split_with_sizes_squeeze_sum_transpose_unfold_unsqueeze_1(in_ptr0, in_ptr1, in_ptr2, out_ptr0, xnumel, XBLOCK : tl.constexpr):
    xnumel = 32768
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:]
    xmask = tl.full([XBLOCK], True, tl.int1)[:]
    x0 = (xindex % 4)
    x1 = xindex // 4
    x2 = xindex
    tmp12 = tl.load(in_ptr2 + (4*x1), None, eviction_policy='evict_last').to(tl.float32)
    tmp24 = tl.load(in_ptr2 + (1 + 4*x1), None, eviction_policy='evict_last').to(tl.float32)
    tmp37 = tl.load(in_ptr2 + (2 + 4*x1), None, eviction_policy='evict_last').to(tl.float32)
    tmp50 = tl.load(in_ptr2 + (3 + 4*x1), None, eviction_policy='evict_last').to(tl.float32)
    tmp0 = x0
    tmp1 = tl.full([1], 0, tl.int64)
    tmp2 = tmp0 >= tmp1
    tmp3 = tl.full([1], 3, tl.int64)
    tmp4 = tmp0 < tmp3
    tmp5 = tl.load(in_ptr0 + (3*x1 + (x0)), tmp4, eviction_policy='evict_last', other=0.0).to(tl.float32)
    tmp6 = tmp0 >= tmp3
    tmp7 = tl.full([1], 7, tl.int64)
    tmp8 = tmp0 < tmp7
    tmp9 = tl.load(in_ptr1 + (x1 + 12288*((-3) + x0)), tmp6, eviction_policy='evict_last', other=0.0).to(tl.float32)
    tmp10 = tl.where(tmp4, tmp5, tmp9)
    tmp11 = tmp10.to(tl.float32)
    tmp13 = tmp12.to(tl.float32)
    tmp14 = tmp11 * tmp13
    tmp15 = 1 + x0
    tmp16 = tmp15 >= tmp1
    tmp17 = tmp15 < tmp3
    tmp18 = tl.load(in_ptr0 + (3*x1 + (1 + x0)), tmp17, eviction_policy='evict_last', other=0.0).to(tl.float32)
    tmp19 = tmp15 >= tmp3
    tmp20 = tmp15 < tmp7
    tmp21 = tl.load(in_ptr1 + (x1 + 12288*((-2) + x0)), tmp19, eviction_policy='evict_last', other=0.0).to(tl.float32)
    tmp22 = tl.where(tmp17, tmp18, tmp21)
    tmp23 = tmp22.to(tl.float32)
    tmp25 = tmp24.to(tl.float32)
    tmp26 = tmp23 * tmp25
    tmp27 = tmp14 + tmp26
    tmp28 = 2 + x0
    tmp29 = tmp28 >= tmp1
    tmp30 = tmp28 < tmp3
    tmp31 = tl.load(in_ptr0 + (3*x1 + (2 + x0)), tmp30, eviction_policy='evict_last', other=0.0).to(tl.float32)
    tmp32 = tmp28 >= tmp3
    tmp33 = tmp28 < tmp7
    tmp34 = tl.load(in_ptr1 + (x1 + 12288*((-1) + x0)), tmp32, eviction_policy='evict_last', other=0.0).to(tl.float32)
    tmp35 = tl.where(tmp30, tmp31, tmp34)
    tmp36 = tmp35.to(tl.float32)
    tmp38 = tmp37.to(tl.float32)
    tmp39 = tmp36 * tmp38
    tmp40 = tmp27 + tmp39
    tmp41 = 3 + x0
    tmp42 = tmp41 >= tmp1
    tmp43 = tmp41 < tmp3
    tmp44 = tl.load(in_ptr0 + (3*x1 + (3 + x0)), tmp43, eviction_policy='evict_last', other=0.0).to(tl.float32)
    tmp45 = tmp41 >= tmp3
    tmp46 = tmp41 < tmp7
    tmp47 = tl.load(in_ptr1 + (x1 + 12288*(x0)), tmp45, eviction_policy='evict_last', other=0.0).to(tl.float32)
    tmp48 = tl.where(tmp43, tmp44, tmp47)
    tmp49 = tmp48.to(tl.float32)
    tmp51 = tmp50.to(tl.float32)
    tmp52 = tmp49 * tmp51
    tmp53 = tmp40 + tmp52
    tl.store(out_ptr0 + (x2), tmp53, None)
