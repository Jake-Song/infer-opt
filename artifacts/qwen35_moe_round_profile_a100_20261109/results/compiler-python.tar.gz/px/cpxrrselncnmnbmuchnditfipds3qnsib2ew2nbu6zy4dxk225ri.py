
import triton
import triton.language as tl

from torch._inductor.runtime import triton_helpers, triton_heuristics
from torch._inductor.runtime.triton_helpers import libdevice, math as tl_math
from torch._inductor.runtime.hints import AutotuneHint, ReductionHint, TileHint, DeviceProperties
triton_helpers.set_driver_to_gpu()

@triton_heuristics.pointwise(
    size_hints={'x': 128}, 
    filename=__file__,
    triton_meta={'signature': {'in_ptr0': '*fp32', 'in_ptr1': '*i64', 'in_ptr2': '*i64', 'in_ptr3': '*bf16', 'in_ptr4': '*fp32', 'in_ptr5': '*fp32', 'in_ptr6': '*fp32', 'out_ptr0': '*fp32', 'out_ptr1': '*fp32', 'out_ptr2': '*fp32', 'out_ptr3': '*fp32', 'xnumel': 'i32', 'XBLOCK': 'constexpr'}, 'device': DeviceProperties(type='cuda', index=0, multi_processor_count=108, cc=80, major=8, regs_per_multiprocessor=65536, max_threads_per_multi_processor=2048, max_threads_per_block=1024, warp_size=32), 'constants': {}, 'native_matmul': False, 'enable_fp_fusion': True, 'launch_pdl': False, 'disable_ftz': False, 'configs': [{(0,): [['tt.divisibility', 16]], (1,): [['tt.divisibility', 16]], (2,): [['tt.divisibility', 16]], (3,): [['tt.divisibility', 16]], (4,): [['tt.divisibility', 16]], (5,): [['tt.divisibility', 16]], (6,): [['tt.divisibility', 16]], (7,): [['tt.divisibility', 16]], (8,): [['tt.divisibility', 16]], (9,): [['tt.divisibility', 16]], (10,): [['tt.divisibility', 16]], (11,): [['tt.divisibility', 16]]}]},
    inductor_meta={'grid_type': 'Grid1D', 'autotune_hints': set(), 'kernel_name': 'triton_poi_fused__to_copy_add_arange_cos_expand_mul_select_sin_slice_unsqueeze_view_46', 'mutated_arg_names': [], 'optimize_mem': True, 'no_x_dim': False, 'atomic_add_found': False, 'num_load': 10, 'num_store': 4, 'num_reduction': 0, 'backend_hash': 'F7205DDDCE8E401A1728E5D602D369DE155D3FCCD3ACF038A9886E6E0DD93A54', 'assert_indirect_indexing': True, 'autotune_local_cache': True, 'autotune_pointwise': True, 'autotune_remote_cache': None, 'force_disable_caches': False, 'dynamic_scale_rblock': True, 'max_autotune': True, 'max_autotune_pointwise': False, 'min_split_scan_rblock': 256, 'spill_threshold': 16, 'store_cubin': False, 'deterministic': False, 'force_filter_reduction_configs': False, 'mix_order_reduction_allow_multi_stages': False, 'are_deterministic_algorithms_enabled': False, 'coordinate_descent_tuning': True, 'coordinate_descent_search_radius': 1, 'coordinate_descent_check_all_directions': False, 'tiling_scores': {'x': 3648}},
    min_elem_per_thread=0
)
@triton.jit
def triton_poi_fused__to_copy_add_arange_cos_expand_mul_select_sin_slice_unsqueeze_view_46(in_ptr0, in_ptr1, in_ptr2, in_ptr3, in_ptr4, in_ptr5, in_ptr6, out_ptr0, out_ptr1, out_ptr2, out_ptr3, xnumel, XBLOCK : tl.constexpr):
    xnumel = 96
    xoffset = tl.program_id(0) * XBLOCK
    xindex = xoffset + tl.arange(0, XBLOCK)[:]
    xmask = xindex < xnumel
    x1 = xindex // 32
    x0 = (xindex % 32)
    x2 = xindex
    tmp3 = tl.load(in_ptr0 + (x0), xmask, eviction_policy='evict_last')
    tmp27 = tl.load(in_ptr1 + (0))
    tmp28 = tl.broadcast_to(tmp27, [XBLOCK])
    tmp29 = tl.load(in_ptr2 + (0))
    tmp30 = tl.broadcast_to(tmp29, [XBLOCK])
    tmp34 = tl.load(in_ptr3 + (x0), xmask, eviction_policy='evict_last').to(tl.float32)
    tmp41 = tl.load(in_ptr4 + (x0), xmask, eviction_policy='evict_last')
    tmp49 = tl.load(in_ptr5 + (x0), xmask, eviction_policy='evict_last')
    tmp66 = tl.load(in_ptr6 + (x0), xmask, eviction_policy='evict_last')
    tmp0 = x1
    tmp1 = tl.full([1], 0, tl.int32)
    tmp2 = tmp0 == tmp1
    tmp4 = x0
    tmp5 = tl.full([1], 1, tl.int64)
    tmp6 = tmp4 >= tmp5
    tmp7 = (((-1) + x0) % 3)
    tmp8 = tl.full([1], 0, tl.int64)
    tmp9 = tmp7 == tmp8
    tmp10 = tmp6 & tmp9
    tmp11 = tl.load(in_ptr1 + (0))
    tmp12 = tl.broadcast_to(tmp11, [XBLOCK])
    tmp13 = tl.where(tmp10, tmp12, 0)
    tmp14 = tl.load(in_ptr2 + (0))
    tmp15 = tl.broadcast_to(tmp14, [XBLOCK])
    tmp16 = tl.where(tmp10, tmp15, 0)
    tmp17 = tmp13 + tmp16
    tmp18 = tl.full([1], 0, tl.int64)
    tmp19 = tmp18 + tmp17
    tmp20 = tmp19.to(tl.float32)
    tmp21 = tl.load(in_ptr3 + (1 + 3*(triton_helpers.div_floor_integer((-1) + x0,  3))), tmp10 & xmask, eviction_policy='evict_last', other=0.0).to(tl.float32)
    tmp22 = tmp21.to(tl.float32)
    tmp23 = tmp20 * tmp22
    tmp24 = tl_math.cos(tmp23)
    tmp25 = tl.full(tmp24.shape, 0.0, tmp24.dtype)
    tmp26 = tl.where(tmp10, tmp24, tmp25)
    tmp31 = tmp28 + tmp30
    tmp32 = tmp8 + tmp31
    tmp33 = tmp32.to(tl.float32)
    tmp35 = tmp34.to(tl.float32)
    tmp36 = tmp33 * tmp35
    tmp37 = tl_math.cos(tmp36)
    tmp38 = tl.where(tmp10, tmp26, tmp37)
    tmp39 = tl.where(tmp2, tmp38, tmp37)
    tmp40 = tl.where(tmp2, tmp3, tmp39)
    tmp42 = tl_math.sin(tmp23)
    tmp43 = tl.full(tmp42.shape, 0.0, tmp42.dtype)
    tmp44 = tl.where(tmp10, tmp42, tmp43)
    tmp45 = tl_math.sin(tmp36)
    tmp46 = tl.where(tmp10, tmp44, tmp45)
    tmp47 = tl.where(tmp2, tmp46, tmp45)
    tmp48 = tl.where(tmp2, tmp41, tmp47)
    tmp50 = tl.full([1], 1, tl.int64)
    tmp51 = tmp17 + tmp50
    tmp52 = tmp18 + tmp51
    tmp53 = tmp52.to(tl.float32)
    tmp54 = tmp53 * tmp22
    tmp55 = tl_math.cos(tmp54)
    tmp56 = tl.full(tmp55.shape, 0.0, tmp55.dtype)
    tmp57 = tl.where(tmp10, tmp55, tmp56)
    tmp58 = tmp31 + tmp5
    tmp59 = tmp8 + tmp58
    tmp60 = tmp59.to(tl.float32)
    tmp61 = tmp60 * tmp35
    tmp62 = tl_math.cos(tmp61)
    tmp63 = tl.where(tmp10, tmp57, tmp62)
    tmp64 = tl.where(tmp2, tmp63, tmp62)
    tmp65 = tl.where(tmp2, tmp49, tmp64)
    tmp67 = tl_math.sin(tmp54)
    tmp68 = tl.full(tmp67.shape, 0.0, tmp67.dtype)
    tmp69 = tl.where(tmp10, tmp67, tmp68)
    tmp70 = tl_math.sin(tmp61)
    tmp71 = tl.where(tmp10, tmp69, tmp70)
    tmp72 = tl.where(tmp2, tmp71, tmp70)
    tmp73 = tl.where(tmp2, tmp66, tmp72)
    tl.store(out_ptr0 + (x2), tmp40, xmask)
    tl.store(out_ptr1 + (x2), tmp48, xmask)
    tl.store(out_ptr2 + (x2), tmp65, xmask)
    tl.store(out_ptr3 + (x2), tmp73, xmask)
