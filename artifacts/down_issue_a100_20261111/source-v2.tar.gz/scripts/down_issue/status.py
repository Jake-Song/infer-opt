"""Print worker progress and archive the current results for recovery."""
import hashlib
import json
from pathlib import Path
import tarfile

root=Path('/tmp/down-issue-a100-20261111')
for name in ['progress.json','worker-error.json','worker-complete.json','timing/complete.json']:
    path=root/name
    if path.exists(): print(name+' '+path.read_text(),flush=True)
for name in ['worker.stdout','worker.stderr','timing.stdout','timing.stderr']:
    path=root/name
    if path.exists(): print(name+'\n'+path.read_text()[-2500:],flush=True)
archive=Path('/tmp/down-issue-results.tar.gz')
with tarfile.open(archive,'w:gz') as tar:
    tar.add(root,arcname='results')
data=archive.read_bytes()
print('ARCHIVE '+json.dumps({'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()}),flush=True)
